# Projet final — LP Citroën Utilitaires Pro (v4)

Paquet prêt à déployer : **tracking URL corrigé** + **formulaire optimisé en 3 étapes** (nombre de véhicules, neuf/occasion, type de carburant), toutes les données transmises au **CRM HelloLead** et au **Google Sheet**.

## Structure

```
.
├── index.html              ← LP (formulaire en 3 étapes : véhicule · projet · coordonnées)
├── style.css               ← styles (pastilles de critères, progression en 3 étapes)
├── script.js               ← tracking corrigé + validation + payloads Sheet/CRM
├── cookie-consent.js       ← CMP + notification de consentement
├── img/                    ← vos visuels (à conserver tels quels)
├── apercu/
│   └── apercu-formulaire-v4.html    ← aperçu visuel du formulaire, ouvrable dans un navigateur
├── docs/
│   ├── LISEZ-MOI-DEPLOIEMENT.md     ← à lire en premier : installation + vérifications
│   ├── CHANGELOG-v4.md              ← détail des changements et colonnes CRM ajoutées
│   ├── AUDIT-TRACKING.md            ← rapport d'audit du bug de tracking corrigé
│   └── PREUVE-TESTS.txt             ← trace des 26 contrôles automatisés (avant/après)
└── tests/
    ├── self-test.js                 ← autotest rejouable (18 contrôles)
    ├── README.md                    ← mode d'emploi de l'autotest
    └── resultats-autotest.txt       ← dernière trace d'exécution
```

## Démarrage rapide

1. Lire `docs/LISEZ-MOI-DEPLOIEMENT.md`.
2. Déployer `index.html`, `style.css`, `script.js`, `cookie-consent.js` (conserver `img/`).
3. Reproduire l'autotest si besoin :
   ```bash
   cd tests && npm i jsdom && node self-test.js
   ```

## Nouveaux champs du formulaire

| Champ | Options | Transmis au CRM sous |
|---|---|---|
| Nombre de véhicules | 1 · 2 · 3-5 · 6-10 · 10+ | `nb_vehicules` + `nb_vehicules_libelle` + `question_2`/`reponse_2` |
| Neuf ou occasion | Neuf · Occasion · Peu importe | `etat_vehicule` + `etat_vehicule_libelle` + `question_3`/`reponse_3` |
| Type de carburant | Électrique · Diesel · Hybride · Peu importe | `carburant` + `carburant_libelle` + `question_4`/`reponse_4` |

Modèle et carburant (étape 1), nombre de véhicules et état (étape 2) sont **obligatoires** : on ne passe à l'étape suivante que lorsque l'étape en cours est complète.

## Parcours en 3 étapes

Le formulaire (`form#lead-form`, dans la carte `#offre` du hero) est découpé en 3 écrans courts, avec une barre de progression « Étape X sur 3 » :

| Étape | Titre | Champs |
|---|---|---|
| 1 | Votre véhicule | Modèle d'intérêt, type de carburant |
| 2 | Votre projet | Nombre de véhicules, neuf ou occasion, société, code postal |
| 3 | Vos coordonnées | Civilité, prénom, nom, e-mail pro, téléphone, consentement → **Obtenir mon offre** |

- Chaque étape est validée avant de passer à la suivante ; le bouton **Retour** permet de corriger sans perdre les réponses.
- Rien ne change côté données : mêmes noms de champs, mêmes validations, même honeypot, mêmes payloads Google Sheet / CRM et mêmes événements `dataLayer` (aucun nouvel événement de tracking).
- Les étapes sont des `<fieldset class="form-step" data-step="1|2|3">` dans `index.html`. La logique est dans la partie « formulaire » de `script.js` (`TOTAL_STEPS`, `STEP_FIELDS`) : pour déplacer un champ d'une étape à l'autre, modifier son `fieldset` **et** `STEP_FIELDS`.
- Finitions mobile : cartes de modèle sur 2 colonnes jusqu'à 340 px, pastilles plus compactes, carburant en grille 2×2, en-tête allégé aux étapes 2 et 3. Ce sont 4 petits blocs `@media` indépendants et facultatifs (repère « FORMULAIRE EN 3 ÉTAPES — finitions mobile » dans `style.css`, avec la consigne pour revenir au rendu d'origine).
- ⚠ Si votre dépôt contient `tests/self-test.js` (non fourni dans cette archive), il suppose un formulaire en 2 étapes : mettez-le à jour (`[data-next]` existe désormais aux étapes 1 et 2, et `[data-submit]` se trouve à l'étape 3).

## Points à confirmer côté CRM (non bloquants)

1. Déclarer les nouvelles colonnes dans le contrat du `formId` (`ADW_LP_CITROEN_VU`).
2. `domaine` envoyé en dur : `ubepro.com` alors que la LP est en `www.ubepro.fr`.
3. Endpoint CRM : basculer `leadApiUrl` de `helloleadpreprod.fr` vers `mc.hellolead.pro` en production (`script.js`, ligne ~27).
