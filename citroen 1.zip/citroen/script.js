/* ============================================================
   LP CITROËN UTILITAIRES PRO — script.js (v3 — correctif tracking URL)
   Hérite de la stack des LP Ubepro (AGV/AMR) adaptée à la campagne :
   1. Configuration (endpoints Google Sheet + CRM HelloLead)
   2. Tracking (utm/ltm/gclid/gbraid…) — CONDITIONNÉ AU CONSENTEMENT CMP,
      mais CAPTURÉ À TOUTE MOMENT À PARTIR DE L'URL D'ENTRÉE (voir §2.1)
   3. Menu mobile
   4. Sélecteur métier → recommandation + pré-remplissage du modèle
   5. Formulaire 3 étapes (véhicule → projet → coordonnées) : validation par
      étape, envoi double (Sheet + CRM),
      événements dataLayer (dont "formulaire_lead" exigé par GTM)
   6. Barre CTA collante (mobile, consciente de la bannière cookies)
   7. Révélations au scroll + lien de navigation actif
   ============================================================ */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* === 1. CONFIGURATION ========================================
     Surchargable AVANT ce script via window.UBEPRO_CONFIG. */
  var domaine = "ubepro.com";
  var config = Object.assign({
    googleScriptUrl: "https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec",
    /* ── ENV : PRODUCTION ──
       (ou surcharger sans toucher au fichier :
        window.UBEPRO_CONFIG = { leadApiUrl: "https://mc.hellolead.pro/mon_compte/api/webflow/get_information.php" }) */
    leadApiUrl: "https://mc.hellolead.pro/mon_compte/api/webflow/get_information.php",
    leadApiMode: "nocors",          // nocors | cors | off
    leadApiCredentials: "omit",     // omit | include
    formId: "ADW_LP_CITROEN_VU",    // ⚠ identifiant campagne à confirmer par le CRM
    crmStrictContract: false,
    debug: false
  }, window.UBEPRO_CONFIG || {});

  var debugLog = function () {
    if (config.debug && window.console) console.log.apply(console, ["[ubepro]"].concat([].slice.call(arguments)));
  };

  var MODELE_LABELS = {
    "e-c3": "Citroën ë-C3 Van (électrique)",
    "berlingo": "Citroën Berlingo Van",
    "jumpy": "Citroën Jumpy",
    "jumper": "Citroën Jumper",
    "a-definir": "Je ne sais pas encore (à conseiller)"
  };

  /* === Critères de besoin (v4) =================================
     Valeurs techniques (envoyées telles quelles au Sheet et au CRM)
     + libellés lisibles (colonnes *_libelle et réponses questionnaire),
     sur le même modèle que « modele » / « modele_libelle ». */
  var NB_VEHICULES_LABELS = {
    "1": "1 véhicule",
    "2": "2 véhicules",
    "3-5": "3 à 5 véhicules",
    "6-10": "6 à 10 véhicules",
    "10+": "Plus de 10 véhicules"
  };
  var ETAT_LABELS = {
    "neuf": "Neuf",
    "occasion": "Occasion",
    "peu-importe": "Peu importe (à conseiller)"
  };
  var CARBURANT_LABELS = {
    "electrique": "Électrique",
    "diesel": "Diesel",
    "hybride": "Hybride",
    "peu-importe": "Peu importe (à conseiller)"
  };
  /* Question posée dans la LP → nom de la question transmise au CRM. */
  var QUESTIONS = [
    { field: "modele",        question: "Modèle d'intérêt",   labels: MODELE_LABELS },
    { field: "nb_vehicules",  question: "Nombre de véhicules", labels: NB_VEHICULES_LABELS },
    { field: "etat_vehicule", question: "Neuf ou occasion",    labels: ETAT_LABELS },
    { field: "carburant",     question: "Type de carburant",   labels: CARBURANT_LABELS }
  ];

  /* === 2. TRACKING (consent-aware) =============================
     Mêmes règles que cookie-consent.js : analytics → utm/ltm,
     marketing → gclid/msclkid/fbclid. Stockage : sessionStorage.
     ALIAS identiques à la stack UbePro d'origine : les clés du
     contrat CRM (source / categorie / user) sont alimentées aussi
     depuis utm_* / ltm_* — sinon le CRM reçoit des colonnes vides
     alors que le Sheet affiche les utm_* (bug corrigé en V5). */
  /* === 2.1 CORRECTIF TRACKING URL (v3) ==========================
     Ce qui empêchait l'attribution d'arriver au CRM :
     a) trackedValues/pageUrl étaient calculés UNE SEULE FOIS à l'exécution du
        script (defer), donc AVANT que le visiteur ait répondu à la bannière
        cookies. Sur un clic pub (1re visite = pas encore de cookie), toutes
        les préférences valent « refusé » → absorb() sortait immédiatement et
        plus rien n'était jamais capturé.
     b) Aucun écouteur ne réagissait au changement de consentement : l'événement
        « cookie_preferences_updated » poussé par cookie-consent.js n'était lu
        par personne.
     c) Aucune relecture de l'URL au moment de l'envoi du lead.

     Correctif : un point d'entrée unique syncTracking(), idempotent, appelé
     au chargement, à chaque changement de consentement (événement DOM, repli
     dataLayer, repli cookie lu directement), sur hashchange/pageshow, au
     premier contact avec le formulaire, et SYSTÉMATIQUEMENT avant de
     construire les payloads Sheet/CRM. L'URL d'entrée reste en mémoire
     (window.__UBEPRO_ENTRY_URL__) : rien n'est écrit en sessionStorage tant
     que le consentement n'est pas donné, mais plus aucune donnée n'est perdue.
     =============================================================== */
  var TRACKING_STORAGE_KEY = "ubepro_tracking_v1";
  var TRACKING_PAGE_KEY = "ubepro_tracking_page_url_v1";
  var CONSENT_COOKIE_NAME = "user_cookie_preferences";
  var MARKETING_KEYS = { gclid: true, msclkid: true, fbclid: true, gbraid: true, wbraid: true, dclid: true };
  /* Clés ajoutées au contrat CRM UNIQUEMENT si elles portent une valeur
     (on n'ajoute pas de colonnes vides à HelloLead pour un nouveau champ). */
  var EXTRA_MARKETING_KEYS = { gbraid: true, wbraid: true, dclid: true };

  var TRACK_ALIASES = [
    { key: "source",       aliases: ["source", "utm_source", "ltm_source"] },
    { key: "categorie",    aliases: ["categorie", "utm_category", "ltm_category", "category"] },
    { key: "user",         aliases: ["user", "utm_user", "ltm_user"] },
    { key: "utm_source",   aliases: ["utm_source", "ltm_source", "source"] },
    { key: "utm_medium",   aliases: ["utm_medium", "medium"] },
    { key: "utm_campaign", aliases: ["utm_campaign", "campaign"] },
    { key: "utm_content",  aliases: ["utm_content", "content"] },
    { key: "utm_term",     aliases: ["utm_term", "term"] },
    { key: "utm_id",       aliases: ["utm_id", "campaign_id"] },
    { key: "utm_category", aliases: ["utm_category", "ltm_category", "categorie", "category"] },
    { key: "utm_user",     aliases: ["utm_user", "ltm_user", "user"] },
    { key: "ltm_source",   aliases: ["ltm_source", "utm_source", "source"] },
    { key: "ltm_category", aliases: ["ltm_category", "utm_category", "categorie", "category"] },
    { key: "ltm_typ",      aliases: ["ltm_typ", "utm_typ", "typ"] },
    { key: "ltm_user",     aliases: ["ltm_user", "utm_user", "user"] },
    { key: "gclid",        aliases: ["gclid"] },
    { key: "msclkid",      aliases: ["msclkid"] },
    { key: "fbclid",       aliases: ["fbclid"] },
    { key: "gbraid",       aliases: ["gbraid"] },
    { key: "wbraid",       aliases: ["wbraid"] },
    { key: "dclid",        aliases: ["dclid"] }
  ];
  var TRACK_KEYS = TRACK_ALIASES.map(function (t) { return t.key; });

  /* Consentement effectif = le PLUS PERMISSIF des deux sources disponibles.
     Le global __UBEPRO_COOKIE_PREFERENCES__ peut être écrasé selon l'ordre
     d'exécution des scripts (bootstrap <head>, CMP en defer, script.js en
     defer) ; le cookie écrit par la CMP reste la source de vérité du choix
     visiteur. On lit les deux pour ne plus dépendre de l'ordre. */
  function prefsFromGlobal() {
    var g = window.__UBEPRO_COOKIE_PREFERENCES__;
    return (g && typeof g === "object" && !Array.isArray(g)) ? g : null;
  }
  function prefsFromCookie() {
    try {
      var prefix = CONSENT_COOKIE_NAME + "=";
      var entry = document.cookie.split(";").map(function (part) { return part.trim(); })
        .find(function (part) { return part.indexOf(prefix) === 0; });
      if (!entry) return null;
      var parsed = JSON.parse(decodeURIComponent(entry.slice(prefix.length)));
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
      return parsed;
    } catch (e) { return null; }
  }
  function prefs() {
    var g = prefsFromGlobal() || {};
    var c = prefsFromCookie() || {};
    return {
      essential: true,
      analytics: g.analytics === true || c.analytics === true,
      marketing: g.marketing === true || c.marketing === true
    };
  }
  function analyticsGranted() { return prefs().analytics === true; }
  function marketingGranted() { return prefs().marketing === true; }
  function trackingGranted() { return analyticsGranted() || marketingGranted(); }
  function keyGranted(key) { return MARKETING_KEYS[key] ? marketingGranted() : analyticsGranted(); }

  function sanitize(value, max) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim().slice(0, max || 300).replace(/[<>]/g, "");
  }

  function parseParams(str) {
    var out = {};
    try {
      new URLSearchParams(str || "").forEach(function (v, k) {
        var key = String(k).trim().toLowerCase();
        var val = sanitize(v, 300);
        if (key && val) out[key] = val;
      });
    } catch (e) {}
    return out;
  }

  function urlParams(url) {
    try {
      var u = new URL(url, window.location.href);
      var hash = u.hash.slice(1);
      var qIndex = hash.indexOf("?");
      var fromHash = qIndex !== -1 ? hash.slice(qIndex + 1) : (hash.indexOf("=") !== -1 && hash.charAt(0) !== "/" ? hash : "");
      return Object.assign(parseParams(fromHash), parseParams(u.search));
    } catch (e) { return {}; }
  }

  /* État vivant (et non plus photo figée au chargement). */
  var trackedValues = {};
  var pageUrl = "";
  var storedTrackingLoaded = false;

  function entryUrl() {
    return (typeof window.__UBEPRO_ENTRY_URL__ === "string" && window.__UBEPRO_ENTRY_URL__)
      ? window.__UBEPRO_ENTRY_URL__
      : window.location.href;
  }

  /* Relit une éventuelle capture de la même session (page vue précédente). */
  function loadStoredTracking() {
    if (storedTrackingLoaded) return;
    storedTrackingLoaded = true;
    if (!trackingGranted()) return;
    try {
      var raw = JSON.parse(window.sessionStorage.getItem(TRACKING_STORAGE_KEY) || "{}");
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) return;
      TRACK_KEYS.forEach(function (k) {
        if (trackedValues[k] || !keyGranted(k) || typeof raw[k] !== "string") return;
        var v = sanitize(raw[k]);
        if (v) trackedValues[k] = v;
      });
    } catch (e) {}
  }

  function persistTracking() {
    if (!trackingGranted()) return;
    try {
      window.sessionStorage.setItem(TRACKING_STORAGE_KEY, JSON.stringify(trackedValues));
      if (pageUrl) window.sessionStorage.setItem(TRACKING_PAGE_KEY, pageUrl);
    } catch (e) {}
  }

  /* Absorption AVEC ALIAS (comportement de la stack d'origine) :
     "source" est alimenté par source OU utm_source OU ltm_source, etc. */
  function absorb(url) {
    if (!trackingGranted()) return {};
    var incoming = urlParams(url || window.location.href);
    var found = {};
    TRACK_ALIASES.forEach(function (t) {
      if (!keyGranted(t.key)) return;
      for (var i = 0; i < t.aliases.length; i++) {
        var alias = t.aliases[i];
        if (incoming[alias]) { found[t.key] = incoming[alias]; break; }
      }
    });
    if (Object.keys(found).length) Object.assign(trackedValues, found);
    return found;
  }

  /* POINT D'ENTRÉE UNIQUE DU TRACKING — idempotent, appelable à tout moment.
     Rejoue : stockage de session → URL d'entrée → URL courante.
     Sans consentement : ne capture rien, n'écrit rien (même politique que la CMP). */
  function syncTracking() {
    if (!trackingGranted()) { pageUrl = ""; return trackedValues; }
    loadStoredTracking();
    absorb(entryUrl());
    absorb(window.location.href);
    if (analyticsGranted()) {
      var savedPage = "";
      try { savedPage = window.sessionStorage.getItem(TRACKING_PAGE_KEY) || ""; } catch (e) {}
      pageUrl = sanitize(savedPage || entryUrl(), 1000);
    } else {
      pageUrl = "";
    }
    persistTracking();
    return trackedValues;
  }

  function trackingSnapshot() {
    syncTracking();
    var out = {};
    TRACK_KEYS.forEach(function (k) {
      out[k] = keyGranted(k) ? sanitize(trackedValues[k]) : "";
    });
    return out;
  }

  function currentPageUrl() {
    syncTracking();
    return analyticsGranted() ? sanitize(pageUrl, 1000) : "";
  }

  /* Resynchronisation à chaque signal disponible (l'ordre d'exécution et GTM
     ne sont plus critiques : le submit resynchronise de toute façon). */
  window.addEventListener("ubepro:cookie-preferences", function () { syncTracking(); }); // émis par cookie-consent.js v2
  window.addEventListener("hashchange", function () { syncTracking(); });                 // #?utm_source=…
  window.addEventListener("pageshow", function () { syncTracking(); });
  try {
    var dataLayerRef = window.dataLayer = window.dataLayer || [];
    var nativePush = dataLayerRef.push;
    dataLayerRef.push = function () {
      var result = nativePush.apply(this, arguments);
      try {
        for (var i = 0; i < arguments.length; i++) {
          var item = arguments[i];
          if (item && item.event === "cookie_preferences_updated") { syncTracking(); break; }
        }
      } catch (e) {}
      return result;
    };
  } catch (e) {}
  document.addEventListener("focusin", function (e) {                    // 1er contact avec le formulaire
    var form = e.target && e.target.closest ? e.target.closest("[data-lead-form]") : null;
    if (form) syncTracking();
  }, true);

  syncTracking();

  window.ubeproTracking = Object.freeze({
    inspect: function () {
      return {
        entry_url: sanitize(entryUrl(), 1000),
        current_url: window.location.href,
        page_url: currentPageUrl(),
        consent: prefs(),
        values: trackingSnapshot()
      };
    }
  });

  /* === Helpers partagés === */
  function formatPhoneFR(value) {
    var digits = String(value || "").replace(/[^\d+]/g, "");
    if (/^\+?00/.test(digits)) digits = "+" + digits.replace(/^\+?00/, "");
    if (digits.indexOf("+33") === 0) digits = "0" + digits.slice(3);
    if (digits.indexOf("33") === 0 && digits.length === 11) digits = "0" + digits.slice(2);
    if (/^0\d+$/.test(digits)) return digits.replace(/(\d{2})(?=\d)/g, "$1 ").trim();
    return digits;
  }
  function normalizePhone(value) { return formatPhoneFR(value).replace(/\s/g, ""); }
  function phoneValid(value) {
    var n = normalizePhone(value);
    return /^0[1-9]\d{8}$/.test(n) || /^\+[1-9]\d{7,14}$/.test(n);
  }
  function emailValid(value) { return /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(String(value || "").trim()); }
  function newLeadId() {
    try { if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID(); } catch (e) {}
    return "xxxxxxxx-xxxx-4xxx".replace(/[x]/g, function () { return (Math.random() * 16 | 0).toString(16); }) + "-" + Date.now();
  }

  /* === 3. MENU MOBILE === */
  (function mobileNav() {
    var toggle = document.querySelector(".nav-toggle");
    var nav = document.querySelector(".site-nav");
    if (!toggle || !nav) return;
    function setOpen(open) {
      nav.classList.toggle("is-open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
    }
    toggle.addEventListener("click", function () { setOpen(!nav.classList.contains("is-open")); });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) setOpen(false); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") setOpen(false); });
  })();

  /* === Pré-remplissage du modèle d'intérêt === */
  function preselectModele(modele) {
    if (!modele) return;
    var input = document.querySelector('input[name="modele"][value="' + modele + '"]');
    if (!input) return;
    input.checked = true;
    var err = document.querySelector('[data-error-for="modele"]');
    if (err) err.hidden = true;
    /* Formulaire en 3 étapes : le modèle se choisit à l'étape 1. On y ramène le
       visiteur pour que sa sélection soit visible (ses autres réponses sont conservées). */
    document.dispatchEvent(new CustomEvent("ubepro:modele-preselected"));
  }

  /* === 4. SÉLECTEUR MÉTIER === */
  (function metierSelector() {
    var widget = document.querySelector("[data-metier]");
    if (!widget) return;

    var buttons = [].slice.call(widget.querySelectorAll("[data-metier-choice]"));
    var result = widget.querySelector("[data-metier-result]");
    var els = {
      img: widget.querySelector("[data-metier-img]"),
      tag: widget.querySelector("[data-metier-tag]"),
      name: widget.querySelector("[data-metier-name]"),
      why: widget.querySelector("[data-metier-why]"),
      price: widget.querySelector("[data-metier-price]"),
      cta: widget.querySelector("[data-metier-cta]")
    };

    var RECOS = {
      livraison: {
        tag: "Recommandé pour la livraison urbaine",
        name: "Citroën ë-C3 Van",
        why: "100% électrique, boîte automatique et Crit'Air 0 : il entre dans toutes les ZFE sans calendrier à surveiller, et sa Prime CertiNergy de 4 900 € déduite ramène le loyer à 129 € HT/mois.",
        price: 'dès <strong>129&nbsp;€&nbsp;HT/mois</strong> <small>1<sup>er</sup> loyer 4&nbsp;591&nbsp;€&nbsp;HT, prime déduite<sup>(1)</sup></small>',
        img: "img/metier-livraison-ville.jpg",
        alt: "Livreur remettant un colis à un commerçant en centre-ville, son petit utilitaire électrique blanc garé juste derrière",
        label: "Obtenir une offre ë-C3 Van",
        modele: "e-c3"
      },
      artisan: {
        tag: "Recommandé pour l'artisanat",
        name: "Citroën Berlingo Van",
        why: "Compact dehors, généreux dedans : le format pensé pour charger l'outillage le matin et se garer devant le chantier sans y passer 10 minutes. Diesel 100 ch sobre pour les journées multi-clients.",
        price: 'dès <strong>159&nbsp;€&nbsp;HT/mois</strong> <small>1<sup>er</sup> loyer 4&nbsp;095&nbsp;€&nbsp;HT<sup>(2)</sup></small>',
        img: "img/metier-artisan-chantier.jpg",
        alt: "Électricien sortant sa caisse à outils de son utilitaire compact blanc devant un chantier de rénovation",
        label: "Obtenir une offre Berlingo Van",
        modele: "berlingo"
      },
      pme: {
        tag: "Recommandé pour les PME nomades",
        name: "Citroën Jumpy",
        why: "Le format intermédiaire de la gamme : assez de place pour le matériel et les missions à forte capacité, un diesel 120 ch à l'aise sur autoroute, et le confort de conduite qui fait la réputation des Citroën utilitaires.",
        price: 'dès <strong>179&nbsp;€&nbsp;HT/mois</strong> <small>1<sup>er</sup> loyer 5&nbsp;475&nbsp;€&nbsp;HT<sup>(3)</sup></small>',
        img: "img/metier-pme-route.jpg",
        alt: "Technicien itinérant avec sa sacoche d'ordinateur rejoignant son utilitaire blanc sur une aire d'autoroute",
        label: "Obtenir une offre Jumpy",
        modele: "jumpy"
      },
      transport: {
        tag: "Recommandé pour le gros volume",
        name: "Citroën Jumper",
        why: "Le grand tôlé 3,0 t de la gamme : pensé pour les chargements sérieux, la messagerie et les équipements volumineux. C'est le véhicule des journées où « ça ne rentrera jamais » n'est pas une option.",
        price: 'dès <strong>209&nbsp;€&nbsp;HT/mois</strong> <small>1<sup>er</sup> loyer 7&nbsp;215&nbsp;€&nbsp;HT<sup>(4)</sup></small>',
        img: "img/metier-transport-volumes.jpg",
        alt: "Cariste chargeant des palettes dans un grand fourgon blanc ouvert à quai en zone logistique",
        label: "Obtenir une offre Jumper",
        modele: "jumper"
      }
    };

    function select(key) {
      var data = RECOS[key];
      if (!data) return;
      buttons.forEach(function (b) {
        var active = b.getAttribute("data-metier-choice") === key;
        b.classList.toggle("is-active", active);
        b.setAttribute("aria-pressed", String(active));
      });
      els.tag.textContent = data.tag;
      els.name.textContent = data.name;
      els.why.textContent = data.why;
      els.price.innerHTML = data.price;
      els.img.setAttribute("src", data.img);
      els.img.setAttribute("alt", data.alt);
      els.cta.textContent = data.label;
      els.cta.setAttribute("data-modele", data.modele);
      if (!reduceMotion) {
        result.classList.remove("is-switching");
        void result.offsetWidth;
        result.classList.add("is-switching");
      }
    }

    buttons.forEach(function (b) {
      b.addEventListener("click", function () { select(b.getAttribute("data-metier-choice")); });
    });
    els.cta.addEventListener("click", function () {
      preselectModele(els.cta.getAttribute("data-modele"));
    });
  })();

  /* CTA des fiches véhicules → pré-sélection du modèle dans le formulaire */
  document.querySelectorAll("[data-modele]").forEach(function (el) {
    if (el.hasAttribute("data-metier-cta")) return;
    el.addEventListener("click", function () { preselectModele(el.getAttribute("data-modele")); });
  });

  /* === 5. FORMULAIRE LEAD (Sheet + CRM + dataLayer) === */
  (function leadForm() {
    var form = document.querySelector("[data-lead-form]");
    if (!form) return;

    var card = form.closest("[data-form-card]") || form.parentElement;
    var steps = [].slice.call(form.querySelectorAll("[data-step]"));
    var TOTAL_STEPS = steps.length;                         // 3
    var stepLabel = document.querySelector("[data-step-label]");
    var progressSegs = [].slice.call(document.querySelectorAll("[data-progress-seg]"));
    var submitBtn = form.querySelector("[data-submit]");
    var successPanel = form.querySelector("[data-success]");
    var stepLabels = {
      1: "Étape 1 sur 3 — votre véhicule",
      2: "Étape 2 sur 3 — votre projet",
      3: "Étape 3 sur 3 — vos coordonnées"
    };
    var currentStep = 1;
    var isSubmitting = false;

    /* Valeur du bouton radio coché d'un groupe ("" si aucun). */
    function radioValue(name) {
      var checked = form.querySelector('input[name="' + name + '"]:checked');
      return checked ? checked.value : "";
    }

    var validators = {
      modele: function () { return !!radioValue("modele"); },
      nb_vehicules: function () { return !!radioValue("nb_vehicules"); },
      etat_vehicule: function () { return !!radioValue("etat_vehicule"); },
      carburant: function () { return !!radioValue("carburant"); },
      code_postal: function () { return /^\d{5}$/.test(form.code_postal.value.trim()); },
      civilite: function () { return !!radioValue("civilite"); },
      prenom: function () { return form.prenom.value.trim().length >= 2; },
      nom: function () { return form.nom.value.trim().length >= 2; },
      societe: function () { return form.societe.value.trim().length >= 2; },
      email: function () { return emailValid(form.email.value); },
      telephone: function () { return phoneValid(form.telephone.value); },
      consentement: function () { return form.consentement.checked; }
    };
    /* Champs contrôlés à chaque étape, dans l'ordre d'affichage
       (le premier champ en erreur reçoit le focus). */
    var STEP_FIELDS = {
      1: ["modele", "carburant"],
      2: ["nb_vehicules", "etat_vehicule", "societe", "code_postal"],
      3: ["civilite", "prenom", "nom", "email", "telephone", "consentement"]
    };

    /* Gère tous les groupes de radios (modele, civilite, nb_vehicules,
       etat_vehicule, carburant) : form.elements[name] renvoie alors une
       RadioNodeList, pas un élément. */
    function firstControlOf(name) {
      var el = form.elements[name];
      if (el && typeof el.length === "number") return el[0];
      return el;
    }
    function fieldOf(name) {
      if (name === "modele") return form.querySelector(".radio-cards");
      if (name === "civilite") return form.querySelector(".radio-inline");
      var first = firstControlOf(name);
      if (first && first.closest) {
        var group = first.closest(".radio-pills");
        if (group) return group;
        return first.closest(".field") || first;
      }
      return first;
    }
    function focusableOf(name) { return firstControlOf(name); }

    function setError(name, invalid) {
      var err = form.querySelector('[data-error-for="' + name + '"]');
      if (err) err.hidden = !invalid;
      var field = fieldOf(name);
      if (field && field.classList) field.classList.toggle("is-invalid", invalid);
      var input = focusableOf(name);
      if (input && input.setAttribute) input.setAttribute("aria-invalid", String(invalid));
    }

    function activeStepSummary() {
      return steps[currentStep - 1].querySelector("[data-form-error]");
    }

    function validateStep(step) {
      var names = STEP_FIELDS[step];
      var invalids = [];
      names.forEach(function (name) {
        var ok = validators[name]();
        setError(name, !ok);
        if (!ok) invalids.push(name);
      });
      var summary = activeStepSummary();
      if (summary) {
        summary.hidden = invalids.length === 0;
        if (invalids.length) {
          summary.textContent = invalids.length === 1
            ? "Un champ est à corriger dans cette étape."
            : invalids.length + " champs sont à corriger dans cette étape.";
        }
      }
      if (invalids.length) {
        var focusable = focusableOf(invalids[0]);
        if (focusable && focusable.focus) {
          focusable.focus({ preventScroll: true });
          /* scrollIntoView n'est pas garanti par tous les moteurs embarqués :
             sans ce garde-fou, le clic sur « Continuer » s'interrompait. */
          if (typeof focusable.scrollIntoView === "function") {
            focusable.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "center" });
          }
        }
      }
      return invalids.length === 0;
    }

    /* Efface l'erreur dès la correction */
    form.addEventListener("input", function (e) {
      var name = e.target.name;
      if (name && validators[name]) setError(name, !validators[name]());
    });
    form.addEventListener("change", function (e) {
      var name = e.target.name;
      if (name && validators[name]) setError(name, !validators[name]());
    });

    /* Formatage en direct : téléphone groupé, code postal chiffres seuls */
    if (form.telephone) {
      form.telephone.addEventListener("input", function () {
        var formatted = formatPhoneFR(form.telephone.value);
        if (form.telephone.value !== formatted) form.telephone.value = formatted;
      });
    }
    if (form.code_postal) {
      form.code_postal.addEventListener("input", function () {
        form.code_postal.value = String(form.code_postal.value || "").replace(/\D/g, "").slice(0, 5);
      });
    }

    /* Barre de progression à 3 segments + libellé « Étape X sur 3 ». */
    function setProgress(step, done) {
      if (stepLabel) stepLabel.textContent = done ? "Demande envoyée" : stepLabels[step];
      if (card) card.setAttribute("data-current-step", done ? "done" : String(step));   // pilote le CSS mobile
      progressSegs.forEach(function (seg, i) {
        var n = i + 1;
        seg.classList.toggle("is-done", !!done || n < step);
        seg.classList.toggle("is-current", !done && n === step);
      });
    }

    /* Ramène le haut de la carte à l'écran seulement si elle en est sortie
       (mobile : le visiteur vient de cliquer en bas d'une étape). Sur desktop,
       où la carte reste visible, la page ne bouge pas. */
    function revealCard() {
      if (!card || typeof card.getBoundingClientRect !== "function") return;
      var header = document.querySelector(".site-header");
      var offset = (header ? header.offsetHeight : 68) + 8;
      if (card.getBoundingClientRect().top < offset && typeof card.scrollIntoView === "function") {
        card.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
      }
    }

    function goTo(step, options) {
      options = options || {};
      step = Math.max(1, Math.min(TOTAL_STEPS, step));
      var forward = step >= currentStep;
      currentStep = step;
      steps.forEach(function (s) {
        var current = s.getAttribute("data-step") === String(step);
        s.hidden = !current;
        s.classList.toggle("is-current", current);
        s.classList.remove("is-entering");
        if (current && !options.silent && !reduceMotion) {
          s.style.setProperty("--step-shift", forward ? "14px" : "-14px");
          void s.offsetWidth;                     // relance l'animation d'entrée
          s.classList.add("is-entering");
        }
      });
      var summary = activeStepSummary();
      if (summary) summary.hidden = true;
      setProgress(step, false);
      if (options.silent) return;
      revealCard();
      /* Focus sur l'étape elle-même (pas sur un champ : le clavier mobile ne doit pas
         s'ouvrir tout seul). Les lecteurs d'écran annoncent « Étape 2 sur 3 : … ». */
      try { steps[step - 1].focus({ preventScroll: true }); } catch (e) {}
    }

    /* N° de la première étape (avant `last`) dont un champ obligatoire est invalide, sinon 0. */
    function firstInvalidStepBefore(last) {
      for (var n = 1; n < last; n++) {
        var bad = STEP_FIELDS[n].some(function (name) { return !validators[name](); });
        if (bad) return n;
      }
      return 0;
    }

    [].forEach.call(form.querySelectorAll("[data-next]"), function (btn) {
      btn.addEventListener("click", function () {
        if (validateStep(currentStep)) goTo(currentStep + 1);
      });
    });
    [].forEach.call(form.querySelectorAll("[data-prev]"), function (btn) {
      btn.addEventListener("click", function () { goTo(currentStep - 1); });
    });

    /* Un CTA « modèle » (fiche véhicule, sélecteur métier) vient de pré-cocher le modèle :
       on revient à l'étape 1 pour que la sélection soit visible. Sans effet une fois la
       demande envoyée. */
    document.addEventListener("ubepro:modele-preselected", function () {
      if (successPanel && !successPanel.hidden) return;
      setError("modele", false);
      if (currentStep !== 1) goTo(1, { silent: true });
    });

    /* --- Construction des charges utiles (contrats Sheet & CRM identiques aux autres LP) --- */
    function buildPayloads() {
      var data = Object.fromEntries(new FormData(form));
      var modeleValue = data.modele || "";
      var modeleLabel = MODELE_LABELS[modeleValue] || modeleValue;

      /* Critères de besoin : valeur technique + libellé lisible, pour les deux
         destinations (Sheet et CRM). */
      var besoins = {};
      QUESTIONS.forEach(function (q) {
        var value = sanitize(data[q.field]);
        besoins[q.field] = value;
        besoins[q.field + "_libelle"] = q.labels[value] || "";
      });

      var coordonnees = {
        nom: sanitize(data.nom),
        prenom: sanitize(data.prenom),
        mail: sanitize((data.email || data.mail || "")).toLowerCase(),
        telephone: normalizePhone(data.telephone),
        societe: sanitize(data.societe),
        code_postal: sanitize(data.code_postal),
        civilite: sanitize(data.civilite),
        ville: sanitize(data.ville)
      };
      /* questionnaire_N / reponse_N : une question par critère collecté. */
      var questionnaires = {};
      QUESTIONS.forEach(function (q, i) {
        var value = sanitize(data[q.field]);
        questionnaires["question_" + (i + 1)] = q.question;
        questionnaires["reponse_" + (i + 1)] = q.labels[value] || value;
      });
      var tracking = trackingSnapshot();

      var sheetData = Object.assign(
        {}, coordonnees,
        { modele: modeleValue, modele_libelle: modeleLabel },
        besoins, questionnaires, tracking,
        { page_referrer: domaine }
      );
      var crmData = Object.assign(
        {}, coordonnees,
        { modele: modeleValue, modele_libelle: modeleLabel },
        besoins,
        { domaine: domaine, source: tracking.source, categorie: tracking.categorie, user: tracking.user,
          gclid: tracking.gclid, msclkid: tracking.msclkid },
        questionnaires
      );

      if (!config.crmStrictContract) {
        if (analyticsGranted()) {
          Object.assign(crmData, {
            utm_source: tracking.utm_source, utm_medium: tracking.utm_medium,
            utm_campaign: tracking.utm_campaign, utm_content: tracking.utm_content,
            utm_term: tracking.utm_term, utm_id: tracking.utm_id,
            utm_category: tracking.utm_category, utm_user: tracking.utm_user,
            ltm_source: tracking.ltm_source, ltm_category: tracking.ltm_category,
            ltm_typ: tracking.ltm_typ, ltm_user: tracking.ltm_user,
            page_url: currentPageUrl(),
            page_referrer: sanitize(document.referrer, 1000),
            user_agent: sanitize(navigator.userAgent, 300),
            langue: sanitize(navigator.language || "", 20)
          });
        }
        if (marketingGranted()) {
          var marketingIds = { gclid: tracking.gclid, msclkid: tracking.msclkid, fbclid: tracking.fbclid };
          Object.keys(EXTRA_MARKETING_KEYS).forEach(function (k) {
            if (tracking[k]) marketingIds[k] = tracking[k];
          });
          Object.assign(crmData, marketingIds);
        }
      }
      return {
        sheetData: sheetData, crmData: crmData,
        modeleValue: modeleValue, modeleLabel: modeleLabel,
        besoins: besoins, questionnaires: questionnaires
      };
    }

    /* --- Envoi Google Sheet (Apps Script) --- */
    function sendToSheet(params) {
      var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
      var timer = controller ? setTimeout(function () { controller.abort(); }, 6000) : null;
      return fetch(config.googleScriptUrl, {
        method: "POST",
        mode: "cors",
        cache: "no-store",
        headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
        body: params,
        keepalive: true,
        signal: controller ? controller.signal : undefined
      }).then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.text().then(function (text) {
          var json = null;
          try { json = JSON.parse(text); } catch (e) { json = null; }
          if (!json || json.status !== "ok") throw new Error((json && json.message) || "Réponse inattendue du script Google.");
          return { target: "sheet", state: "ok", response: json };
        });
      }).catch(function (err) {
        console.error("[ubepro] Google Sheet en échec :", err);
        return { target: "sheet", state: "error", error: err };
      }).finally(function () { if (timer) clearTimeout(timer); });
    }

    /* --- Envoi CRM HelloLead (beacon → no-cors, ou cors si configuré) --- */
    function sendToCrm(data, formId, leadId) {
      if (config.leadApiMode === "off" || !config.leadApiUrl) {
        return Promise.resolve({ target: "crm", state: "off" });
      }
      var body = JSON.stringify({ payload: { formId: formId, id: leadId, data: data } });

      if (config.leadApiMode === "cors") {
        var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
        var timer = controller ? setTimeout(function () { controller.abort(); }, 5000) : null;
        return fetch(config.leadApiUrl, {
          method: "POST", mode: "cors",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: body,
          signal: controller ? controller.signal : undefined
        }).then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return { target: "crm", state: "ok", response: res };
        }).catch(function (err) {
          console.error("[ubepro] CRM en échec (cors) :", err);
          return { target: "crm", state: "error", error: err };
        }).finally(function () { if (timer) clearTimeout(timer); });
      }

      try {
        if (typeof navigator.sendBeacon === "function" &&
            navigator.sendBeacon(config.leadApiUrl, new Blob([body], { type: "text/plain;charset=UTF-8" }))) {
          return Promise.resolve({ target: "crm", state: "unverified", via: "beacon" });
        }
      } catch (e) {
        console.warn("[ubepro] sendBeacon CRM échoué, repli fetch :", e);
      }
      var ctrl2 = typeof AbortController !== "undefined" ? new AbortController() : null;
      var timer2 = ctrl2 ? setTimeout(function () { ctrl2.abort(); }, 5000) : null;
      return fetch(config.leadApiUrl, {
        method: "POST", mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=UTF-8" },
        body: body, keepalive: true,
        credentials: config.leadApiCredentials === "include" ? "include" : "omit",
        signal: ctrl2 ? ctrl2.signal : undefined
      }).then(function () {
        return { target: "crm", state: "unverified", via: "fetch" };
      }).catch(function (err) {
        console.error("[ubepro] CRM : fetch no-cors en échec :", err);
        return { target: "crm", state: "error", error: err };
      }).finally(function () { if (timer2) clearTimeout(timer2); });
    }

    function setLoading(loading) {
      if (!submitBtn) return;
      submitBtn.disabled = loading;
      submitBtn.setAttribute("aria-busy", String(loading));
      submitBtn.classList.toggle("is-loading", loading);
      submitBtn.textContent = loading ? "Envoi en cours…" : "Obtenir mon offre";
    }

    function showSuccess() {
      steps.forEach(function (s) { s.hidden = true; });
      setProgress(TOTAL_STEPS, true);
      if (successPanel) {
        successPanel.hidden = false;
        successPanel.focus();
      }
      if (card && card.scrollIntoView) {
        card.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "center" });
      }
    }

    function showSendError(message) {
      var summary = activeStepSummary();
      if (summary) {
        summary.textContent = message;
        summary.hidden = false;
      }
      setLoading(false);
      if (submitBtn) submitBtn.textContent = "Réessayer l'envoi";
      isSubmitting = false;
    }

    /* --- Soumission --- */
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (isSubmitting) return;

      /* « Entrée » au clavier sur une étape intermédiaire = « Continuer ». */
      if (currentStep < TOTAL_STEPS) {
        if (validateStep(currentStep)) goTo(currentStep + 1);
        return;
      }
      if (!validateStep(TOTAL_STEPS)) return;
      /* Filet de sécurité : aucune étape précédente ne doit être incomplète à l'envoi. */
      var incomplete = firstInvalidStepBefore(TOTAL_STEPS);
      if (incomplete) { goTo(incomplete); validateStep(incomplete); return; }

      /* Honeypot : envoi simulé pour les bots, rien ne part. */
      if (form.website && String(form.website.value).trim() !== "") {
        debugLog("Honeypot rempli, envoi ignoré.");
        showSuccess();
        return;
      }

      isSubmitting = true;
      setLoading(true);

      var payloads = buildPayloads();
      var formId = config.formId;
      var leadId = newLeadId();

      var params = new URLSearchParams();
      Object.keys(payloads.sheetData).forEach(function (k) { params.set(k, payloads.sheetData[k]); });
      params.set("form_id", formId);
      params.set("id_lead", leadId);
      if (analyticsGranted()) {
        params.set("page_url", currentPageUrl());
        params.set("user_agent", sanitize(navigator.userAgent, 300));
        params.set("langue", sanitize(navigator.language || "", 20));
      }
      debugLog("Sheet payload :", Object.fromEntries(params.entries()));
      debugLog("CRM payload :", { payload: { formId: formId, id: leadId, data: payloads.crmData } });

      var results = [];
      var anyOk = false;
      var record = function (result) {
        results.push(result);
        debugLog("Résultat :", result);
        if (!anyOk && (result.state === "ok" || result.state === "unverified")) {
          anyOk = true;
          onLeadConfirmed();
        }
      };

      function onLeadConfirmed() {
        showSuccess();
        /* Exigence GTM client : déclenché à chaque validation du formulaire.
           "generate_lead" (contexte campagne) reste conditionné au consentement
           analytics/marketing, cohérent avec les autres LP UbePro. */
        try {
          window.dataLayer = window.dataLayer || [];
          if (trackingGranted()) {
            window.dataLayer.push({
              event: "generate_lead",
              form_id: formId,
              modele: payloads.modeleValue,
              modele_libelle: payloads.modeleLabel,
              /* Critères de besoin : exploitables directement dans GTM/GA4. */
              nb_vehicules: payloads.besoins.nb_vehicules,
              etat_vehicule: payloads.besoins.etat_vehicule,
              carburant: payloads.besoins.carburant
            });
            if (typeof window.gtag === "function") {
              window.gtag("event", "generate_lead", { form_id: formId });
            }
          }
          window.dataLayer.push({ "event": "formulaire_lead" });
        } catch (err) {}
        setLoading(false);
        isSubmitting = false;
      }

      var finishedAll = Promise.all([
        sendToSheet(params).then(record),
        sendToCrm(payloads.crmData, formId, leadId).then(record)
      ]);

      var slowTimer = setTimeout(function () {
        if (!anyOk && submitBtn) submitBtn.textContent = "Enregistrement en cours…";
      }, 2500);

      finishedAll.then(function () {
        clearTimeout(slowTimer);
        if (!anyOk) {
          var sheetFailed = results.some(function (r) { return r.target === "sheet" && r.state === "error"; });
          var crmFailed = results.some(function (r) { return r.target === "crm" && r.state === "error"; });
          console.warn("[ubepro] Aucune destination confirmée — Sheet :", sheetFailed, "| CRM :", crmFailed);
          showSendError("Nous n'avons pas pu enregistrer votre demande. Vérifiez votre connexion puis réessayez, ou appelez le 07 56 98 60 82.");
        }
      });
    });

    /* Débogage / inspection (équivalent de window.ubeproLead des autres LP) */
    window.ubeproLead = {
      config: {
        googleScriptUrl: config.googleScriptUrl,
        leadApiUrl: config.leadApiUrl,
        leadApiMode: config.leadApiMode,
        formId: config.formId
      },
      preview: function () {
        var p = buildPayloads();
        return { crm: { payload: { formId: config.formId, id: "(généré à la soumission)", data: p.crmData } }, sheet: p.sheetData };
      },
      tracking: trackingSnapshot
    };
  })();

  /* === 6. STICKY CTA (mobile) + conscience de la bannière cookies === */
  (function stickyCta() {
    var bar = document.querySelector("[data-sticky-cta]");
    var target = document.getElementById("offre");
    if (!bar) return;
    bar.hidden = false;

    /* La bannière cookies a la priorité visuelle : on masque le CTA collant
       tant qu'elle est affichée. */
    var cookieBanner = document.getElementById("content-cookie");
    if (cookieBanner && window.MutationObserver) {
      var syncBannerClass = function () {
        document.body.classList.toggle("has-cookie-banner", !cookieBanner.hidden);
      };
      new MutationObserver(syncBannerClass).observe(cookieBanner, { attributes: true, attributeFilter: ["hidden"] });
      syncBannerClass();
    }

    if (!target || !("IntersectionObserver" in window)) { bar.classList.add("is-visible"); return; }

    var mobile = window.matchMedia("(max-width: 899px)");
    new IntersectionObserver(function (entries) {
      var entry = entries[0];
      var show = mobile.matches && !entry.isIntersecting && entry.boundingClientRect.top < 0;
      bar.classList.toggle("is-visible", show);
      document.body.classList.toggle("has-sticky", show);
    }, { threshold: 0.05 }).observe(target);

    bar.addEventListener("click", function () {
      setTimeout(function () {
        /* 3 étapes : on cible le 1er choix de l'étape affichée (toujours un bouton radio,
           donc pas de clavier mobile qui s'ouvre tout seul). */
        var first = document.querySelector('#lead-form .form-step:not([hidden]) input[type="radio"]');
        if (first) first.focus({ preventScroll: true });
      }, reduceMotion ? 0 : 420);
    });
  })();

  /* === 7. RÉVÉLATIONS AU SCROLL + LIEN ACTIF === */
  (function scrollFx() {
    var reveals = document.querySelectorAll(".reveal");
    if (reduceMotion || !("IntersectionObserver" in window)) {
      reveals.forEach(function (el) { el.classList.add("is-revealed"); });
    } else {
      var revObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-revealed");
            revObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
      reveals.forEach(function (el) { revObserver.observe(el); });
    }

    var links = [].slice.call(document.querySelectorAll('.nav-list a[href^="#"]'));
    if (!("IntersectionObserver" in window) || !links.length) return;
    var map = {};
    links.forEach(function (l) { map[l.getAttribute("href").slice(1)] = l; });
    var navObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting && map[entry.target.id]) {
          links.forEach(function (l) { l.classList.remove("is-current"); });
          map[entry.target.id].classList.add("is-current");
        }
      });
    }, { rootMargin: "-40% 0px -55% 0px" });
    Object.keys(map).forEach(function (id) {
      var section = document.getElementById(id);
      if (section) navObserver.observe(section);
    });
  })();
})();
