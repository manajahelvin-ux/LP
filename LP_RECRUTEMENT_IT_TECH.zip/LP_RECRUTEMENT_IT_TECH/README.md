# Recrutement IT & Tech — HTML/CSS adaptés au JS fourni

## Engagement respecté

**`script.js` est strictement identique au fichier joint par l’utilisateur.** Sa copie a été vérifiée octet pour octet et par empreinte SHA-256 :

```text
e6ae6897669eed0083358435f1494d7dbaef112ce2be81c3512a399982afcdcb
```

- Aucun JavaScript exécutable ajouté dans le HTML.
- Aucun gestionnaire inline `onclick`, `onsubmit`, etc.
- Un seul chargement du fichier `script.js`, avec `defer`.
- Les deux blocs JSON-LD existants sont conservés à l’identique : ce sont des métadonnées, pas du code d’interaction.
- L’URL Google Apps Script et les traitements du JS sont inchangés.

## Installation

1. Sauvegardez vos fichiers actuels.
2. Remplacez **uniquement `index.html` et `style.css`** dans le dossier du site.
3. Gardez votre `script.js` : celui inclus dans cette archive est exactement le même.
4. **Conservez votre dossier `img/`.** Il n’était pas joint et n’est donc pas inclus. Les chemins des photos et icônes existants ont été conservés.
5. Rechargez avec **Ctrl + F5**. Les liens vers la CSS et le JS dans le HTML sont versionnés pour limiter les problèmes de cache.

```text
votre-site/
├── index.html
├── style.css
├── script.js   ← inchangé
└── img/       ← vos fichiers existants
```

Aucune modification de `code.gs` n’est nécessaire pour cette adaptation HTML/CSS. L’enregistrement réel dépend toujours de votre déploiement Google actuellement configuré.

## 1. Formulaire compatible

Le HTML d’origine utilisait `#lead-form`, alors que le JS sélectionne uniquement `#study-form`. Le formulaire n’était donc pas pris en charge par ce script.

Le HTML utilise maintenant :

- un formulaire unique **`#study-form.form-wrap`** ;
- exactement deux **`.form-step`**, comme attendu par le JS ;
- **étape 1 : votre recrutement**, avec le profil obligatoire et un complément de contexte facultatif ;
- **étape 2 : vos coordonnées**, avec les six champs de contact existants, toujours obligatoires ;
- `.form-next`, `.form-back`, `.form-progress`, `.form-error`, `.form-success` et `.privacy-note` ;
- un champ honeypot `website`, masqué aux utilisateurs ;
- les 18 champs de tracking reconnus par le JS.

Les anciens messages par champ `err-nom`, `err-profil`, etc. ont été remplacés par le message global que le JS sait mettre à jour. Les labels des champs restent visibles, au lieu de dépendre seulement des placeholders.

### Correspondance des données

| Information | Champ transmis |
|---|---|
| Identifiant de la landing | `form_id = ADW_LP_RECRUTEMENT_IT_TECH` |
| Profil recherché | **`solution`**, également recopié dans `reponse_2` |
| Précisions facultatives : stack, délai, contexte… | `enjeu`, également recopié dans `reponse_3` |
| Nom / prénom | `nom` / `prenom` |
| E-mail professionnel | `mail` |
| Téléphone | `telephone` |
| Code postal | `code_postal` |
| Société | `societe` |
| Attribution marketing | `source`, `categorie`, `user`, `utm_*`, `ltm_*`, `gclid`, `msclkid`, `fbclid` |

**Important :** le JS ne lit pas un champ nommé `profil`. Le sélecteur garde donc son ID HTML `profil`, mais son attribut `name` devient `solution`. Les neuf choix existants sont conservés ; leur valeur est désormais le libellé lisible, par exemple `DevOps / SRE / Platform Engineer`, plutôt que le code `devops`.

Le `form_id` explicite empêche l’utilisation du `DEFAULT_FORM_ID` AGV présent dans le JS. Les champs non affichés, comme `site`, `civilite` et `ville`, restent vides ; aucune valeur n’est inventée.

### Limites conservées pour ne pas modifier le JS

Les questions techniques restent celles codées dans le fichier :

```text
question_1 = Type de site
question_2 = Solution envisagée
question_3 = Enjeu principal
```

Ainsi, le profil sélectionné se retrouve sous `solution` / `reponse_2`, mais le libellé `question_2` reste « Solution envisagée ». Un simple champ HTML `question_2` ne permettrait pas de le changer, puisque le JS le reconstruit explicitement.

Le téléphone suit la validation existante : numéro français ou international avec indicatif. Le code postal conserve la règle existante de cinq chiffres.

### Confirmation après envoi

La note `.privacy-note` se trouve hors des étapes, pour rester visible après le succès. Le message final confirme l’enregistrement de la demande.

La promesse d’envoi automatique d’un SMS a été retirée : **le JS fourni ne déclenche aucun SMS**. Un éventuel système SMS séparé n’a pas été présumé.

## 2. Comparateur raccordé au JS

Le script gère déjà les éléments `[data-tab]` et `[data-panel]`. Ces attributs ont été ajoutés aux deux boutons et aux deux panneaux existants.

- `data-tab="job"` → `data-panel="job"` ;
- `data-tab="cab"` → `data-panel="cab"`.

Les IDs, `aria-controls`, `aria-labelledby`, textes et apparence sont conservés. Le script met à jour `aria-selected`, `is-active` et `hidden`.

Les deux boutons sont accessibles par **Tab**, puis activables par **Entrée ou Espace**. Aucune gestion supplémentaire des touches fléchées n’a été ajoutée, car elle demanderait du JavaScript.

## 3. Menu mobile et bouton fixe

Un bouton `.menu-toggle` et une navigation `#mobile-nav` utilisent directement le gestionnaire déjà présent dans le JS. Le menu se ferme après un clic sur ses liens.

Le bouton fixe « Trouver mon cabinet » est désormais visible sur mobile par **CSS uniquement**. Il n’attend plus le retrait d’un attribut `hidden` que le JS ne pilotait pas. Sa visibilité n’est pas liée à un seuil de défilement : il est disponible dès le chargement sur petit écran. Une marge basse évite qu’il masque la fin de la page.

## 4. Information candidat sans nouveau JavaScript

Sur les navigateurs compatibles, le message candidat utilise un **popover HTML natif** :

- ouverture par `popovertarget` ;
- fermeture par les boutons natifs ou Échap ;
- pas de gestionnaire JS ajouté ;
- pas de déclaration `aria-modal="true"`, car il ne s’agit pas d’une fenêtre modale avec verrouillage du reste de la page.

Si le navigateur ne prend pas en charge ce mécanisme, la CSS affiche un lien vers l’encart **`#candidats`** dans le pied de page. Sur petit écran, cette information reste accessible dans le menu mobile.

La FAQ conserve ses éléments natifs `<details>` / `<summary>`.

## 5. CSS alignée sur les états du script

Le JS utilise l’attribut `hidden` pour masquer les étapes, messages, panneaux et menu. La CSS le respecte explicitement :

```css
[hidden],
input[type="hidden"] {
  display: none !important;
}
```

Pour les animations, le JS utilise `animationPlayState`, pas la classe `is-visible`. Les éléments `.reveal` utilisent donc des keyframes. Le contenu apparaît aussi sans `IntersectionObserver` ; les animations sont désactivées si l’utilisateur demande une réduction des mouvements.

Les grilles du formulaire utilisent des colonnes pouvant rétrécir, et les champs ont une largeur compatible avec les petits écrans.

## Test du tracking

Utilisez une nouvelle session privée pour ne pas reprendre des paramètres de tests précédents :

```text
http://localhost:8000/?source=landing&categorie=recrutement_it_tech&user=adw&ltm_source=landing&ltm_category=recrutement_it_tech&ltm_typ=lead&ltm_user=adw
```

Dans la console, le diagnostic déjà présent dans votre JS reste disponible :

```js
console.table(window.ubeproTracking.inspect().values);
```

Vous devez notamment retrouver `source=landing`, `categorie=recrutement_it_tech`, `user=adw` et `ltm_typ=lead`. Les correspondances UTM/LTM sont celles du JS inchangé. Les paramètres absents de l’URL et de la mémoire de session restent vides.

Après un envoi manuel, contrôlez **Réseau → POST vers `/exec` → Payload**, puis le Sheet. Le profil doit apparaître dans `solution`, avec le bon `form_id`.

## Vérifications effectuées

**27 vérifications réussies dans Chromium**, couvrant notamment :

- identité du JS, absence de JS additionnel, JSON-LD conservés ;
- structure HTML, IDs, ancres et noms de champs ;
- navigation, validation, retour, succès et messages d’erreur ;
- POST simulé : recrutement, profil, contexte, coordonnées, tracking ;
- comparateur au clic et au clavier ;
- menu mobile, bouton fixe et soumission sur mobile ;
- message candidat natif, y compris avec JavaScript désactivé ;
- FAQ, animations, absence d’IntersectionObserver, mouvement réduit ;
- stockage bloqué et nettoyage de l’URL après chargement ;
- UTM et identifiants publicitaires ;
- formulaire sans débordement testé à 320, 390, 768, 1024 et 1365 px.

**Tous les appels réseau des tests ont été interceptés : aucun lead n’a été envoyé à votre déploiement Google et aucune ligne n’a été ajoutée à votre Sheet.** Les images non jointes ont été remplacées uniquement dans les tests par une image de contrôle, et les polices externes par les polices de repli. Aucun de ces remplacements n’est inclus dans le site livré.
