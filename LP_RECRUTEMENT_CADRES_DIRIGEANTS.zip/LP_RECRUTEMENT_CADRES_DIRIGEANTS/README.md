# Cadres & dirigeants — HTML/CSS adaptés, JavaScript inchangé

## Installation

1. Sauvegardez votre version actuelle.
2. **Remplacez uniquement `index.html` et `style.css`.**
3. Conservez votre `script.js` : la copie fournie dans cette archive est strictement identique au fichier joint.
4. **Gardez votre dossier `img/` existant.** Les deux images n’étaient pas jointes ; leurs chemins ont été conservés et aucun remplacement n’est livré.
5. Rechargez avec **Ctrl + F5**. Les liens de chargement CSS/JS dans le HTML sont versionnés pour limiter les problèmes de cache.

```text
votre-site/
├── index.html
├── style.css
├── script.js   ← inchangé
└── img/
    ├── hero-direction-recrutement.png
    └── atelier-brief-recrutement.png
```

### Intégrité du JS

Comparaison binaire et empreinte SHA-256 identiques entre le JS fourni et le JS livré :

```text
e6ae6897669eed0083358435f1494d7dbaef112ce2be81c3512a399982afcdcb
```

Un seul script exécutable est chargé. Aucun JS inline, aucun gestionnaire `onclick` / `onsubmit`, aucune bibliothèque supplémentaire. Les styles dans `<noscript>` sont uniquement du CSS de repli.

## 1. Un formulaire compatible en deux étapes

Le JS fourni attend `#study-form`, deux `.form-step`, `.form-next` et `.form-back`. La maquette initiale utilisait un autre formulaire, trois étapes et des attributs non gérés par ce script.

Le parcours devient :

1. **Votre besoin et votre contexte** : enjeu, fonction et secteur.
2. **Contact** : nom complet, entreprise, email et accord obligatoire.

La barre utilise les éléments `<i>` / `<b>` générés par le JS. Un seul `.form-error` est placé hors des étapes, pour rester visible à n’importe quel moment. Le succès est à l’intérieur du formulaire, et `.privacy-note` reste hors des étapes masquées.

Le honeypot `website` et les 18 champs cachés de tracking sont présents. Les anciens attributs `data-next`, `data-back`, `data-reset`, etc. non reconnus ont été retirés.

### Priorité et précisions réunies dans `enjeu`

Le script transmet seulement trois champs métier : `site`, `solution` et `enjeu`. Il ne transmet pas séparément `priority` et `context`, et ne sait pas les concaténer.

Pour ne pas conserver un champ de contexte qui serait ignoré, ces deux questions sont **regroupées dans un champ unique `enjeu`** :

- les trois priorités d’origine sont proposées par un `<datalist>` natif ;
- le visiteur peut choisir une suggestion ou saisir son propre texte ;
- il peut compléter **ce même champ** avec ses précisions ;
- la saisie est limitée à 500 caractères, conformément au plafond du JS ;
- une valeur composée uniquement d’espaces est refusée.

Exemple :

```text
Conduire une transformation — créer une nouvelle activité dans une filiale.
```

Il n’y a **pas de fusion automatique de deux saisies distinctes** : le texte est rédigé directement dans le champ qui sera envoyé. Si un navigateur n’affiche pas les suggestions natives, le champ reste utilisable en saisie libre.

### Correspondance avec le Sheet

| Information | Clé envoyée |
|---|---|
| Identifiant de la landing | `form_id = ADW_LP_RECRUTEMENT_CADRES_DIRIGEANTS` |
| Priorité et précisions | `enjeu`, aussi recopié dans `reponse_3` |
| Fonction recherchée | `solution`, aussi recopiée dans `reponse_2` |
| Secteur | `site`, aussi recopié dans `reponse_1` |
| Nom complet | `nom` |
| Entreprise | `societe` |
| Email | `mail` |
| Tracking | `source`, `categorie`, `user`, UTM, LTM et click IDs |

Le champ « Nom et prénom » reste un champ unique, comme dans votre maquette. Sa valeur complète est envoyée dans `nom` ; aucune séparation automatique n’est faite et `prenom` reste vide.

Aucun téléphone ou code postal n’a été ajouté : le JS ne les valide que si ces champs existent. Votre formulaire conserve un contact par email. Les champs non affichés restent vides.

### Limites du JS inchangé

- La case d’accord est obligatoire dans l’interface, mais **`consent` n’est pas copié dans le payload du JS**. Il n’y a donc pas d’archivage de cette case dans le Sheet ni de preuve de consentement enregistrée par cette adaptation.
- Les intitulés techniques restent codés en dur : `question_1 = Type de site`, `question_2 = Solution envisagée`, `question_3 = Enjeu principal`. Les réponses contiennent bien secteur, fonction et enjeu.
- Le `form_id` explicite de cette page évite l’utilisation du `DEFAULT_FORM_ID` AGV présent dans le JS.

## 2. Trois scénarios pilotés par le JS existant

La maquette utilisait un seul panneau dont le texte devait être remplacé par un autre script. Le JS fourni sait uniquement afficher/masquer des panneaux existants.

Les trois scénarios sont donc maintenant de vrais contenus HTML :

- `data-tab="grow"` → `data-panel="grow"` ;
- `data-tab="change"` → `data-panel="change"` ;
- `data-tab="replace"` → `data-panel="replace"`.

Le contenu du premier scénario est conservé. Deux textes de cadrage ont été ajoutés en HTML pour la transformation et le passage de relais, à partir des thèmes de la page.

Les IDs, `aria-controls`, `aria-labelledby`, `aria-selected` et états `hidden` sont cohérents. Les boutons sont accessibles avec **Tab**, puis **Entrée ou Espace**. Aucune gestion supplémentaire des flèches du clavier n’a été ajoutée.

Les liens des scénarios conduisent au brief ; ils ne préremplissent pas le champ d’enjeu.

## 3. FAQ native et menu mobile

Les quatre questions utilisent `<details>` / `<summary>` : elles s’ouvrent au clic et au clavier sans JavaScript supplémentaire.

Le menu mobile a été renommé `#mobile-nav`, avec le bon `aria-controls`. Le JS existant peut ainsi l’ouvrir et le refermer. La CSS respecte explicitement les états `hidden` :

```css
[hidden], input[type="hidden"] {
  display: none !important;
}
```

Cela masque également les étapes après succès, même si la dernière conserve sa classe `is-active`.

La barre supérieure est fixe au défilement par CSS, sans attendre une classe ajoutée par un script absent. Les grilles, champs et images sont adaptés aux petits écrans ; la seconde image utilise le chargement différé natif.

## 4. Recommencer et fonctionnement sans JS

Le bouton de reset non géré a été remplacé par un **lien natif qui recharge la page**. Cela recrée l’état initial du script et revient à la première étape. La query string `?source=…` est conservée ; le fragment d’ancre est retiré. Ce comportement a été testé dans Chromium.

Sans JavaScript :

- le formulaire est masqué avec une explication, pour ne pas proposer un faux envoi ;
- les trois scénarios sont affichés en lecture ;
- la FAQ reste utilisable ;
- le menu mobile devient une navigation statique.

## 5. La page n’affirme plus que l’envoi est simulé

Les mentions « aucune donnée transmise », « démo front-end » et les confirmations fictives ont été remplacées.

**Une soumission valide sur votre site utilisera réellement l’endpoint Google Apps Script déjà configuré dans le JS.** Le succès n’est affiché qu’après sa réponse JSON `status: "ok"`.

Cette adaptation ne crée ni synthèse automatique, ni rendez-vous, ni email client automatique. Elle transmet les champs pour leur traitement. Le code serveur et l’URL du déploiement sont inchangés.

Les liens légaux du domaine Ubepro ont été repris de vos pages précédentes. Leur contenu et leur adéquation à cette collecte restent à vérifier avant publication ; cette adaptation technique ne constitue pas une validation juridique.

## 6. Tester chez vous

Ouvrez l’URL dans une nouvelle session privée :

```text
http://localhost:8000/?source=landing&categorie=cadres_dirigeants&user=adw&ltm_source=landing&ltm_category=cadres_dirigeants&ltm_typ=lead&ltm_user=adw
```

Dans la console, le diagnostic déjà présent dans votre JS reste disponible :

```js
console.table(window.ubeproTracking.inspect().values);
```

Résultats attendus : `source=landing`, `categorie=cadres_dirigeants`, `user=adw`, `ltm_typ=lead`, avec les correspondances UTM/LTM du script. Les paramètres absents de l’URL et de la mémoire de session restent vides.

Pour une vérification réelle, soumettez un lead de test et contrôlez **Réseau → POST vers `/exec` → Payload**, puis le Sheet. Vérifiez en particulier l’identifiant de landing, `enjeu`, `solution` et `site`.

## Vérifications effectuées

**28 vérifications locales réussies dans Chromium**, dont :

- identité binaire du JS, absence de code additionnel, IDs/ancres/labels valides ;
- deux étapes, trois suggestions natives, saisie libre et champs obligatoires ;
- retour, POST simulé complet, email seul, accord obligatoire et email invalide ;
- succès, anti-double-envoi, erreur JSON et honeypot ;
- trois scénarios au clic/clavier, quatre FAQ natives et menu mobile ;
- parcours complet sur mobile et rechargement pour recommencer ;
- repli sans JS, stockage bloqué, URL nettoyée, UTM/click IDs et visite directe ;
- absence de débordement testée à 320, 390, 560, 768, 900, 1024 et 1365 px.

**Tous les envois de test ont été interceptés : aucun appel n’a atteint votre déploiement Google et aucune ligne n’a été ajoutée à votre Sheet.** Les deux images non jointes ont été remplacées uniquement pendant les tests par une image de contrôle, non incluse dans les fichiers livrés.
