<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-53SH7D7F');</script>
<!-- End Google Tag Manager -->
<!-- Modification du formulaire de la LP -->
<script>
 /* Paste in Webflow Page Settings > Custom Code > Inside <head> */
(function () {
  'use strict';

  var FORM_SELECTOR = '#wf-form-Assurance-TNS-Pro-Form';
  var EXPECTED_OLD_STEP_COUNT = 10;
  var alreadyPatched = false;

  function esc(value) {
    return String(value).replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
    });
  }

  function hidden(name, value) {
    return '<input type="hidden" name="' + esc(name) + '" data-name="' + esc(name) + '" value="' + esc(value) + '">';
  }

  function checkbox(name, id, label, extraAttrs) {
    var libName = name.replace(/^reponse_/, 'reponse_lib_');
    return '<label class="w-checkbox reponse-choix-multiple">' +
      '<input class="w-checkbox-input rcm-check" type="checkbox" id="' + esc(id) + '" name="' + esc(name) + '" data-name="' + esc(name) + '" ' + (extraAttrs || '') + '>' +
      '<span class="rcm-text radio-button-label-117 w-form-label" for="' + esc(id) + '">' + esc(label) + '</span>' +
      '</label>' + hidden(libName, label);
  }

  function radio(name, id, label, value, extraAttrs, labelClass) {
    return '<label class="radio-btn iard-mobile w-radio">' +
      '<input class="w-form-formradioinput w-radio-input" type="radio" id="' + esc(id) + '" name="' + esc(name) + '" data-name="' + esc(name) + '" value="' + esc(value) + '" ' + (extraAttrs || '') + '>' +
      '<span class="' + (labelClass || 'radio-button-label-36') + ' w-form-label" for="' + esc(id) + '">' + esc(label) + '</span>' +
      '</label>';
  }

  function nav(stepNumber, isLast) {
    var back = stepNumber > 1
      ? '<a class="bouton-precedent rc-pro w-button" data-form="back-btn" href="#">Précédent</a>'
      : '';
    var next = isLast
      ? '<input class="bouton-valider rc-pro w-button" data-form="submit-btn" data-wait="Patienter..." type="submit" value="Valider">'
      : '<a class="' + (stepNumber === 1 ? 'button-83' : 'bouton-suivant') + ' rc-pro w-button" data-form="next-btn" href="#">Suivant</a>';
    return '<div class="etape-bouton assurance-iard">' + back + next + '</div>';
  }

  function step(stepNumber, content, isLast) {
    var answer = stepNumber === 1 ? '' : 'step-' + stepNumber;
    var next = isLast ? '' : ' data-go-to="step-' + (stepNumber + 1) + '"';
    var first = stepNumber === 1 ? ' data-checkbox="1"' : '';
    var className = stepNumber === 1 ? 'etape-2 form-blobale style-iard' : 'etape-2 form-blobale';
    return '<div class="' + className + '" data-form="step">' +
      '<div class="etape-content form-blobale" data-answer="' + answer + '"' + next + first + '>' +
      content + nav(stepNumber, isLast) + '</div></div>';
  }

  function buildMarkup() {
    var rcTypes = [
      checkbox('reponse_1_1', 'reponse_1_1', 'Responsabilité Civile Professionnelle (RC Pro)', 'data-assurance="rc-pro"'),
      checkbox('reponse_1_2', 'reponse_1_2', 'Multirisque professionnelle', 'data-assurance="multirisque"'),
      checkbox('reponse_1_3', 'reponse_1_3', 'Protection sociale individuelle', 'data-assurance="sociale-individuelle"'),
      checkbox('reponse_1_4', 'reponse_1_4', 'Protection sociale collective', 'data-assurance="sociale-collective"')
    ].join('');

    var mrpOptions = [
      'Cyber-risques et protection des données',
      'Dommages au matériel informatique',
      'Perte d’exploitation',
      'Vol et vandalisme',
      'Incendie et dégâts des eaux',
      'Responsabilité civile exploitation (RCE)',
      'Protection juridique',
      'Autre'
    ].map(function (label, index) {
      var n = index + 1;
      return checkbox('reponse_2_' + n, 'reponse_2_' + n, label,
        n === 8 ? 'data-autre-mrp="true"' : '');
    }).join('');

    var psiOptions = [
      'Complémentaire santé', 'Prévoyance', 'Épargne retraite'
    ].map(function (label, index) {
      var n = index + 1;
      return checkbox('reponse_5_' + n, 'reponse_5_' + n, label, '');
    }).join('');

    var pscOptions = [
      'Complémentaire santé', 'Prévoyance', 'Complémentaire retraite'
    ].map(function (label, index) {
      var n = index + 1;
      return checkbox('reponse_6_' + n, 'reponse_6_' + n, label, '');
    }).join('');

    var effectifs = [
      ['0 à 1 personne', 'data-effectif="0-1" required'],
      ['2 à 5 salariés', 'required'],
      ['6 à 10 salariés', 'required'],
      ['11 à 20 salariés', 'required'],
      ['21 à 50 salariés', 'required'],
      ['Plus de 50 salariés', 'required']
    ].map(function (row, index) {
      var id = 'effectif-' + (index + 1);
      return radio('reponse_4', id, row[0], row[0], row[1], 'radio-button-label-36');
    }).join('');

    var statuts = [
      ['Dirigeant salarié', 'Dirigeant salarié'],
      ['Dirigeant non salarié (TNS)', 'Dirigeant non salarié (TNS)']
    ].map(function (row, index) {
      return radio('reponse_7', 'statut-dirigeant-' + (index + 1), row[0], row[1],
        'data-statut-dirigeant="true" required', 'radio-button-label-36');
    }).join('');

    var autoChoices = [
      ['Oui', 'Oui'], ['Non', 'Non']
    ].map(function (row, index) {
      return radio('reponse_3', 'auto-entrepreneur-' + (index + 1), row[0], row[1],
        'required', 'radio-button-label-36');
    }).join('');

    var existsChoices = [
      ['Société existante', 'Société existante'],
      ['Société en cours de création', 'Société en cours de création']
    ].map(function (row, index) {
      return radio('reponse_8', 'societe-existante-' + (index + 1), row[0], row[1],
        'required', 'radio-button-label-99');
    }).join('');

    var step1 =
      hidden('question_1', 'Quels types d’assurances professionnelles recherchez-vous ?') +
      '<div class="text-block-251 titre-assurance-iard">Quels types d’assurances professionnelles recherchez-vous ?</div>' +
      '<p class="rcm-text">Plusieurs réponses possibles.</p>' + rcTypes +
      '<div data-condition-group="mrp" hidden style="display:none">' +
        hidden('question_2', 'Quelles garanties recherchez-vous ?') +
        '<div class="titre-assurance-iard">Quelles garanties recherchez-vous ?</div>' +
        '<p class="rcm-text">Plusieurs réponses possibles.</p>' + mrpOptions +
        '<div data-condition-group="mrp-autre" hidden style="display:none">' +
          hidden('reponse_champ_lib_2_8', 'Autre — précisez') +
          '<input class="w-input" maxlength="256" name="reponse_champ_2_8" data-name="reponse_champ_2_8" type="text" placeholder="Précisez votre autre garantie">' +
        '</div>' +
      '</div>' +
      '<div data-condition-group="psi" hidden style="display:none">' +
        hidden('question_5', 'Protection sociale individuelle — Quels types de protection recherchez-vous ?') +
        '<div class="titre-assurance-iard">Quels types de protection recherchez-vous ?</div>' +
        '<p class="rcm-text">Protection sociale individuelle — plusieurs réponses possibles.</p>' + psiOptions +
      '</div>' +
      '<div data-condition-group="psc" hidden style="display:none">' +
        hidden('question_6', 'Protection sociale collective — Quels types de protection recherchez-vous ?') +
        '<div class="titre-assurance-iard">Quels types de protection recherchez-vous ?</div>' +
        '<p class="rcm-text">Protection sociale collective — plusieurs réponses possibles.</p>' + pscOptions +
      '</div>';

    var step2 =
      hidden('question_4', 'Quel est l’effectif de votre structure ?') +
      '<div class="titre-assurance-iard">Quel est l’effectif de votre structure ?</div>' +
      '<p class="rcm-text">Une seule réponse possible.</p>' + effectifs +
      '<div data-condition-group="statut-dirigeant" hidden style="display:none">' +
        hidden('question_7', 'Quel est votre statut ?') +
        '<div class="titre-assurance-iard">Quel est votre statut ?</div>' +
        '<p class="rcm-text">Une seule réponse possible.</p>' + statuts +
        '<div data-condition-group="auto-entrepreneur" hidden style="display:none">' +
          hidden('question_3', "Êtes-vous auto-entrepreneur ?") +
          '<div class="titre-assurance-iard">Êtes-vous auto-entrepreneur ?</div>' +
          '<p class="rcm-text">Une seule réponse possible.</p>' + autoChoices +
        '</div>' +
      '</div>';

    var step3 = hidden('question_8', 'Votre société existe-t-elle déjà ?') +
      '<div class="titre-assurance-iard">Votre société existe-t-elle déjà ?</div>' + existsChoices;

    var step4 = '<div class="titre-assurance-iard">Vos coordonnées</div>' +
      '<div class="civilite-email-tel">' +
        '<input class="name iard w-input" data-name="prenom" maxlength="256" name="prenom" placeholder="Prénom" required type="text">' +
        '<input class="name iard w-input" data-name="nom" maxlength="256" name="nom" placeholder="Nom" required type="text">' +
      '</div>';

    var step5 = '<div class="titre-assurance-iard">Sur quelle adresse mail souhaitez-vous recevoir vos devis ?</div>' +
      '<input class="email w-input" data-name="mail" maxlength="256" name="mail" placeholder="Adresse e-mail" required type="email">';

    var step6 = '<div class="titre-assurance-iard">Quelle est la société concernée par cette demande ?</div>' +
      '<div class="coordonnees-societe">' +
        '<input class="nom-societe w-input" data-name="societe" maxlength="256" name="societe" placeholder="Nom de la société" required type="text">' +
        '<input class="code-postale-webflow w-input" data-min-character="5" data-name="code_postal" data-phone-autoformat="xxxxx" maxlength="256" name="code_postal" placeholder="Code postal" required type="tel">' +
      '</div>';

    var step7 = '<div class="titre-assurance-iard">Et enfin, votre numéro de téléphone mobile ?</div>' +
      '<div class="information-acheteur">' +
        '<input class="phone-webflow w-input" data-min-character="14" data-name="telephone" data-phone-autoformat="xx xx xx xx xx" maxlength="256" name="telephone" placeholder="Téléphone" required type="tel">' +
      '</div>' +
      '<div class="titre-consentement">En soumettant ce formulaire, j’accepte que les informations saisies soient exploitées dans le cadre de la relation commerciale qui peut en découler.</div>' +
      '<div class="consentement-1">' +
        '<label class="consentement-2 w-radio"><input class="w-form-formradioinput w-radio-input" data-name="consentement" id="oui" name="consentement" required type="radio" value="oui"><span class="radio-button-label-44 w-form-label" for="oui">J’accepte</span></label>' +
        '<label class="w-radio"><input class="w-form-formradioinput w-radio-input" data-name="consentement" id="non" name="consentement" type="radio" value="non"><span class="radio-button-label-45 w-form-label" for="non">Je n’accepte pas</span></label>' +
      '</div>';

    return [
      step(1, step1, false),
      step(2, step2, false),
      step(3, step3, false),
      step(4, step4, false),
      step(5, step5, false),
      step(6, step6, false),
      step(7, step7, true)
    ].join('');
  }

  function patch(form) {
    if (alreadyPatched) return;
    alreadyPatched = true;

    var trackingInputs = Array.prototype.slice.call(
      form.querySelectorAll('input[type="hidden"]')
    ).filter(function (input) {
      return !/^(question_\d+|reponse_lib_|reponse_champ_lib_)/.test(input.name);
    });

    var hiddenBox = document.createElement('div');
    hiddenBox.className = 'champ-masque w-embed';
    trackingInputs.forEach(function (input) { hiddenBox.appendChild(input); });

    form.replaceChildren(hiddenBox);
    form.insertAdjacentHTML('beforeend', buildMarkup());

    var requiredInitial = new WeakMap();
    form.querySelectorAll('input, select, textarea').forEach(function (field) {
      requiredInitial.set(field, field.required);
    });

    function checked(selector) {
      return !!form.querySelector(selector + ':checked');
    }

    function toggle(groupName, visible) {
      var group = form.querySelector('[data-condition-group="' + groupName + '"]');
      if (!group) return;
      group.hidden = !visible;
      group.setAttribute('aria-hidden', visible ? 'false' : 'true');
      if (visible) group.style.removeProperty('display');
      else group.style.display = 'none';

      group.querySelectorAll('input, select, textarea').forEach(function (field) {
        if (visible) {
          field.disabled = false;
          field.required = requiredInitial.get(field) === true;
        } else {
          if (field.type === 'checkbox' || field.type === 'radio') field.checked = false;
          else if (field.type !== 'hidden') field.value = '';
          field.required = false;
          field.disabled = true;
        }
      });
    }

    function sync() {
      var mrp = checked('[data-assurance="multirisque"]');
      var zeroOne = checked('[data-effectif="0-1"]');
      var statut = checked('[data-statut-dirigeant]');
      var autre = checked('[data-autre-mrp]');

      toggle('mrp', mrp);
      toggle('psi', checked('[data-assurance="sociale-individuelle"]'));
      toggle('psc', checked('[data-assurance="sociale-collective"]'));
      toggle('mrp-autre', mrp && autre);
      toggle('statut-dirigeant', zeroOne);
      toggle('auto-entrepreneur', zeroOne && statut);
    }

    form.addEventListener('change', sync);
    sync();
    console.info('[LP assurance] formulaire injecté. Vérifiez l’ordre des étapes et le récapitulatif CRM en préproduction.');
  }

  function tryPatch() {
    if (alreadyPatched) return true;
    var form = document.querySelector(FORM_SELECTOR);
    if (!form) return false;
    var steps = form.querySelectorAll(':scope > [data-form="step"]');
    var phone = form.querySelector('input[name="telephone"]');
    if (steps.length < EXPECTED_OLD_STEP_COUNT || !phone) return false;

    // Le script doit intervenir AVANT l’initialisation de Formly/multi-step.js.
    if (typeof window.updateStep === 'function') {
      console.error('[LP assurance] patch annulé : Formly est déjà initialisé. Placez ce code dans le Head de la page, avant les scripts multi-step.');
      return true;
    }

    patch(form);
    return true;
  }

  var observer = new MutationObserver(function () {
    if (tryPatch()) observer.disconnect();
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
  tryPatch();

  window.setTimeout(function () {
    if (!alreadyPatched) {
      console.error('[LP assurance] formulaire non modifié. Vérifiez le sélecteur, les 10 étapes initiales et le placement du code dans le Head avant Formly.');
    }
  }, 12000);
})();

</script>