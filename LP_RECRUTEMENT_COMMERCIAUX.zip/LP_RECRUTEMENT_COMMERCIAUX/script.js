/**
 * Ubepro — Landing page AGV / AMR
 * Formulaire multi-étapes + tracking URL (UTM, gclid, msclkid, fbclid, ltm)
 * + envoi du lead vers Google Apps Script (onglet "Leads").
 *
 * Points clés de cette version :
 *  1. Le tracking est capturé dès l'exécution du script, en mémoire et dans
 *     sessionStorage si disponible. index.html photographie aussi l'URL dans
 *     le <head>, avant le chargement différé de ce fichier.
 *  2. Les champs cachés sont resynchronisés AVANT FormData à la soumission.
 *     Le payload utilise directement les valeurs de tracking recalculées.
 *  3. L'envoi vérifie la RÉPONSE JSON du script Google (status === 'ok') :
 *     GAS répond toujours HTTP 200, donc response.ok seul ne prouve rien.
 *  4. Timeout (15 s), anti-double-envoi, honeypot anti-spam, fallback UUID
 *     pour les contextes non-HTTPS (crypto.randomUUID y est indisponible).
 *  5. Le POST Google embarque aussi id_lead (UUID) et le contexte de
 *     navigation (page_url, page_referrer, user_agent, langue). page_url
 *     conserve l'URL de capture du tracking, même après nettoyage de l'URL.
 *
 * Diagnostic console : window.ubeproTracking.inspect()
 * Version : 2026-09-22.2 — code.gs et les colonnes du Sheet restent inchangés.
 */

const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec';
const LEAD_API_URL = ''; // Optionnel : API CRM au format { payload: { formId, id, data } }
const DEFAULT_FORM_ID = 'ADW_LP_AGV_AMR';
const TRACKING_STORAGE_KEY = 'ubepro_tracking_v1';
const TRACKING_PAGE_STORAGE_KEY = 'ubepro_tracking_page_url_v1';
const TRACKING_VERSION = '2026-09-22.2';
const REQUEST_TIMEOUT_MS = 15000;
const DEBUG = false;

const TRACKING_KEYS = [
  { key: 'source', aliases: ['source', 'utm_source', 'ltm_source'] },
  { key: 'categorie', aliases: ['categorie', 'utm_category', 'ltm_category', 'category'] },
  { key: 'user', aliases: ['user', 'utm_user', 'ltm_user'] },
  { key: 'utm_source', aliases: ['utm_source', 'ltm_source', 'source'] },
  { key: 'utm_medium', aliases: ['utm_medium', 'medium'] },
  { key: 'utm_campaign', aliases: ['utm_campaign', 'campaign'] },
  { key: 'utm_content', aliases: ['utm_content', 'content'] },
  { key: 'utm_term', aliases: ['utm_term', 'term'] },
  { key: 'utm_id', aliases: ['utm_id', 'campaign_id'] },
  { key: 'utm_category', aliases: ['utm_category', 'ltm_category', 'categorie', 'category'] },
  { key: 'utm_user', aliases: ['utm_user', 'ltm_user', 'user'] },
  { key: 'ltm_source', aliases: ['ltm_source', 'utm_source', 'source'] },
  { key: 'ltm_category', aliases: ['ltm_category', 'utm_category', 'categorie', 'category'] },
  { key: 'ltm_typ', aliases: ['ltm_typ', 'utm_typ', 'typ'] },
  { key: 'ltm_user', aliases: ['ltm_user', 'utm_user', 'user'] },
  { key: 'gclid', aliases: ['gclid'] },
  { key: 'msclkid', aliases: ['msclkid'] },
  { key: 'fbclid', aliases: ['fbclid'] }
];

/* ------------------------------------------------------------------ */
/* Utilitaires                                                         */
/* ------------------------------------------------------------------ */

const safeText = (value, maxLength = 500) => {
  const text = String(value ?? '').replace(/\s+/g, ' ').trim();
  return text.slice(0, maxLength);
};

const normalizePayloadValue = (value) => {
  const sanitized = safeText(value, 500);
  return sanitized.replace(/[<>]/g, '');
};

const debugLog = (...args) => { if (DEBUG) console.debug(...args); };

/** UUID v4 avec repli si crypto.randomUUID est indisponible (contexte non-HTTPS). */
const generateId = () => {
  try {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
  } catch (err) { /* contexte non sécurisé */ }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const value = char === 'x' ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
};

/* ------------------------------------------------------------------ */
/* Tracking URL : capture anticipée + mémoire + sessionStorage          */
/* ------------------------------------------------------------------ */

// Le petit script placé dans le <head> capture l'URL avant les scripts defer.
// Sans lui, le repli est l'URL visible au moment de l'exécution de script.js.
const ENTRY_PAGE_URL = typeof window.__UBEPRO_ENTRY_URL__ === 'string'
  ? window.__UBEPRO_ENTRY_URL__
  : window.location.href;

const parseParamsFromString = (searchString) => {
  const params = Object.create(null);
  new URLSearchParams(searchString || '').forEach((value, key) => {
    const cleanKey = String(key).trim().toLowerCase();
    const cleanValue = normalizePayloadValue(value);
    if (cleanKey && cleanValue) params[cleanKey] = cleanValue;
  });
  return params;
};

/** Query classique, #/page?source=... et #source=... ; la query est prioritaire. */
const getUrlParams = (href = window.location.href) => {
  try {
    const url = new URL(href, window.location.href);
    const hash = url.hash.slice(1);
    const queryIndex = hash.indexOf('?');
    const hashQuery = queryIndex !== -1
      ? hash.slice(queryIndex + 1)
      : (hash.includes('=') && !hash.startsWith('/') ? hash : '');
    return {
      ...parseParamsFromString(hashQuery),
      ...parseParamsFromString(url.search)
    };
  } catch (err) {
    return {};
  }
};

/** Ne relire que les clés connues, jamais un objet de stockage arbitraire. */
const readStoredParams = () => {
  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(TRACKING_STORAGE_KEY) || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    const stored = {};
    TRACKING_KEYS.forEach(({ key }) => {
      if (Object.prototype.hasOwnProperty.call(parsed, key) && typeof parsed[key] === 'string') {
        const value = normalizePayloadValue(parsed[key]);
        if (value) stored[key] = value;
      }
    });
    return stored;
  } catch (err) {
    return {};
  }
};

// Indispensable si sessionStorage est bloqué : ne pas dépendre de sa relecture.
let trackingMemory = readStoredParams();
let trackingPageUrl = ENTRY_PAGE_URL;
try {
  const storedUrl = window.sessionStorage.getItem(TRACKING_PAGE_STORAGE_KEY);
  if (storedUrl && Object.keys(trackingMemory).length > 0) trackingPageUrl = storedUrl;
} catch (err) { /* Mémoire seule, pour cette page. */ }

const storeParams = (params) => {
  trackingMemory = { ...trackingMemory, ...params };
  try {
    window.sessionStorage.setItem(TRACKING_STORAGE_KEY, JSON.stringify(trackingMemory));
  } catch (err) { /* Les valeurs restent disponibles en mémoire. */ }
  return { ...trackingMemory };
};

/**
 * La dernière valeur non vide de chaque clé gagne (comme dans la version
 * d'origine). Sans paramètres dans l'URL, on garde les valeurs mémorisées.
 * Pas de source/campagne inventée : une visite directe peut rester vide.
 */
const captureTrackingParams = (href = window.location.href) => {
  const urlParams = getUrlParams(href);
  const relevant = {};
  TRACKING_KEYS.forEach(({ key, aliases }) => {
    const foundAlias = aliases.find((alias) => urlParams[alias]);
    if (foundAlias) relevant[key] = urlParams[foundAlias];
  });
  if (Object.keys(relevant).length > 0) {
    storeParams(relevant);
    trackingPageUrl = safeText(href, 1000);
    try {
      window.sessionStorage.setItem(TRACKING_PAGE_STORAGE_KEY, trackingPageUrl);
    } catch (err) { /* L'URL de capture reste elle aussi en mémoire. */ }
  }
  return { ...trackingMemory };
};

/** URL courante > valeurs capturées/mémorisées ; aucune dépendance au DOM. */
const getTrackingValues = () => {
  captureTrackingParams();
  return Object.fromEntries(TRACKING_KEYS.map(({ key }) => [
    key, normalizePayloadValue(trackingMemory[key])
  ]));
};

// Ne pas attendre DOMContentLoaded pour conserver les paramètres d'entrée.
captureTrackingParams(ENTRY_PAGE_URL);
captureTrackingParams();

// Diagnostic local : n'envoie rien, ne lit aucun champ d'identité du formulaire.
window.ubeproTracking = Object.freeze({
  version: TRACKING_VERSION,
  inspect: () => {
    const values = getTrackingValues();
    return {
      version: TRACKING_VERSION,
      current_url: window.location.href,
      page_url: safeText(trackingPageUrl, 1000),
      values
    };
  }
});

/* ------------------------------------------------------------------ */
/* Téléphone / code postal                                             */
/* ------------------------------------------------------------------ */

const normalizePhone = (value) => {
  let text = String(value || '').replace(/[^\d+]/g, '');
  if (/^\+?00/.test(text)) text = `+${text.replace(/^\+?00/, '')}`; // 0033... -> +33...
  if (text.startsWith('+33')) text = `0${text.slice(3)}`;            // +336... -> 06...
  if (text.startsWith('33') && text.length === 11) text = `0${text.slice(2)}`;
  return text;
};

const validatePhone = (value) => {
  const normalized = normalizePhone(value);
  if (/^0[1-9]\d{8}$/.test(normalized)) return true;   // France : 10 chiffres (01..09)
  return /^\+[1-9]\d{7,14}$/.test(normalized);          // International : +indicatif
};

const validatePostal = (value) => /^\d{5}$/.test(String(value || '').replace(/\s+/g, ''));

const formatPhoneInput = (value) => {
  // Formatage "06 12 34 56 78" uniquement pour les saisies françaises.
  return /^0\d+$/.test(value) ? value.replace(/(\d{2})(?=\d)/g, '$1 ').trim() : value;
};

/* ------------------------------------------------------------------ */
/* Initialisation                                                      */
/* ------------------------------------------------------------------ */

document.addEventListener('DOMContentLoaded', () => {
  /* ---- Menu mobile ---- */
  const menuToggle = document.querySelector('.menu-toggle');
  const mobileNav = document.querySelector('#mobile-nav');
  menuToggle?.addEventListener('click', () => {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!isOpen));
    if (mobileNav) mobileNav.hidden = isOpen;
  });
  mobileNav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    menuToggle?.setAttribute('aria-expanded', 'false');
    if (mobileNav) mobileNav.hidden = true;
  }));

  /* ---- Onglets solutions ---- */
  const tabs = document.querySelectorAll('[data-tab]');
  const panels = document.querySelectorAll('[data-panel]');
  tabs.forEach((tab) => tab.addEventListener('click', () => {
    const target = tab.dataset.tab;
    tabs.forEach((item) => {
      const active = item === tab;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-selected', String(active));
    });
    panels.forEach((panel) => {
      const active = panel.dataset.panel === target;
      panel.classList.toggle('is-active', active);
      panel.hidden = !active;
    });
  }));

  /* ---- Relire l'URL au cas où elle aurait changé pendant le chargement ---- */
  captureTrackingParams();

  const form = document.querySelector('#study-form');
  if (!form) return;

  const steps = [...document.querySelectorAll('.form-step')];
  const progress = document.querySelector('.form-progress');
  const error = document.querySelector('.form-error');
  const successBox = form.querySelector('.form-success');
  const phoneField = form.querySelector('input[name="telephone"]');
  const postalField = form.querySelector('input[name="code_postal"]');
  const honeypotField = form.querySelector('input[name="website"]');
  const nextButton = form.querySelector('.form-next');
  const backButton = form.querySelector('.form-back');

  /* ---- Champs cachés de tracking (alimentés depuis URL + sessionStorage) ---- */
  const trackingFields = Object.fromEntries(TRACKING_KEYS.map(({ key }) => {
    let field = form.querySelector(`[name="${key}"]`);
    if (!field) {
      field = document.createElement('input');
      field.type = 'hidden';
      field.name = key;
      form.prepend(field);
    }
    return [key, field];
  }));

  const fillTrackingFields = () => {
    const values = getTrackingValues();
    Object.entries(values).forEach(([name, value]) => {
      if (trackingFields[name]) trackingFields[name].value = value;
    });
    return values;
  };
  fillTrackingFields();
  // pageshow ne couvre pas hashchange ni le retour sur un onglet masqué.
  ['pageshow', 'hashchange', 'popstate'].forEach((eventName) => {
    window.addEventListener(eventName, fillTrackingFields);
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') fillTrackingFields();
  });

  /* ---- Formatage / validation à la saisie ---- */
  const setFieldAlert = (field, message) => {
    field.setCustomValidity(message || '');
  };

  phoneField?.addEventListener('input', () => {
    const value = normalizePhone(phoneField.value);
    const formatted = formatPhoneInput(value);
    if (phoneField.value !== formatted) phoneField.value = formatted;
    const digitsOnly = value.replace(/\D/g, '');
    if (digitsOnly.length > 15) {
      setFieldAlert(phoneField, 'Le téléphone semble trop long.');
    } else if (value.length > 0 && !validatePhone(value)) {
      setFieldAlert(phoneField, 'Saisissez un numéro valide (ex. 06 12 34 56 78 ou +32 470 12 34 56).');
    } else {
      setFieldAlert(phoneField, '');
    }
  });

  postalField?.addEventListener('input', () => {
    const value = String(postalField.value || '').replace(/\D/g, '');
    postalField.value = value.slice(0, 5);
    if (postalField.value.length > 0 && !validatePostal(postalField.value)) {
      setFieldAlert(postalField, 'Le code postal doit contenir exactement 5 chiffres.');
    } else {
      setFieldAlert(postalField, '');
    }
  });

  /* ---- Navigation multi-étapes ---- */
  let currentStep = 0;
  const showStep = (index) => {
    currentStep = index;
    steps.forEach((step, stepIndex) => {
      step.hidden = stepIndex !== index;
      step.classList.toggle('is-active', stepIndex === index);
    });
    // <i> = étape atteinte (bleu dans la CSS), <b> = étape à venir.
    if (progress) {
      progress.innerHTML = steps.map((_, index) => (index <= currentStep ? '<i></i>' : '<b></b>')).join('');
    }
  };

  const validateStep1 = () => {
    const required = [...steps[0].querySelectorAll('[required]')];
    const invalidField = required.find((field) => !field.checkValidity());
    if (invalidField) {
      error.textContent = 'Vérifiez les champs obligatoires avant de continuer.';
      error.hidden = false;
      invalidField.reportValidity?.();
      invalidField.focus();
      return false;
    }
    error.hidden = true;
    return true;
  };

  const validateStep2 = () => {
    if (phoneField && !validatePhone(normalizePhone(phoneField.value))) {
      error.textContent = 'Le téléphone doit contenir un numéro valide.';
      error.hidden = false;
      phoneField.focus();
      return false;
    }
    const postalValue = String(postalField?.value || '').replace(/\s+/g, '');
    if (postalValue !== '' && !validatePostal(postalValue)) {
      error.textContent = 'Le code postal doit contenir exactement 5 chiffres.';
      error.hidden = false;
      postalField?.focus();
      return false;
    }
    const required = [...steps[1].querySelectorAll('[required]')];
    const invalidField = required.find((field) => !field.checkValidity());
    if (invalidField) {
      error.textContent = 'Vérifiez les champs obligatoires avant de continuer.';
      error.hidden = false;
      invalidField.reportValidity?.();
      invalidField.focus();
      return false;
    }
    error.hidden = true;
    return true;
  };

  nextButton?.addEventListener('click', () => {
    if (validateStep1()) showStep(1);
  });
  backButton?.addEventListener('click', () => { error.hidden = true; showStep(0); });

  const showFormSuccess = () => {
    steps.forEach((step) => { step.hidden = true; });
    if (successBox) successBox.hidden = false;
    if (progress) progress.innerHTML = steps.map(() => '<i></i>').join('');
    const privacyNote = form.closest('.form-wrap')?.querySelector('.privacy-note');
    if (privacyNote) {
      privacyNote.textContent = 'Merci pour votre demande. Nous revenons vers vous avec un premier regard sur votre contexte.';
    }
  };

  /* ---- Soumission ---- */
  let isSubmitting = false;

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (isSubmitting) return;

    // Entrée validée sur l'étape 1 : on avance au lieu d'envoyer.
    if (currentStep === 0) {
      if (validateStep1()) showStep(1);
      return;
    }
    if (!validateStep2()) return;

    // Honeypot anti-spam : champ invisible rempli = robot.
    // On affiche le succès sans rien envoyer.
    if (honeypotField && honeypotField.value.trim() !== '') {
      debugLog('Honeypot rempli, envoi ignoré.');
      showFormSuccess();
      return;
    }

    isSubmitting = true;
    const submitButton = form.querySelector('button[type="submit"]');
    const originalLabel = submitButton ? submitButton.innerHTML : '';
    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'Envoi en cours...';
    }

    /* ---- Construction du payload ---- */
    // Toujours synchroniser AVANT FormData. Les anciens champs cachés ne
    // doivent jamais écraser une valeur plus récente dans l'URL.
    const tracking = fillTrackingFields();
    const formData = Object.fromEntries(new FormData(form));
    const formId = normalizePayloadValue(formData.form_id || DEFAULT_FORM_ID) || DEFAULT_FORM_ID;

    const payloadData = {
      nom: normalizePayloadValue(formData.nom),
      prenom: normalizePayloadValue(formData.prenom),
      mail: normalizePayloadValue(formData.mail || formData.email).toLowerCase(),
      telephone: normalizePayloadValue(formData.telephone),
      societe: normalizePayloadValue(formData.societe),
      code_postal: normalizePayloadValue(formData.code_postal),
      civilite: normalizePayloadValue(formData.civilite),
      ville: normalizePayloadValue(formData.ville),
      // Une seule source de vérité pour toutes les clés source/UTM/LTM/click IDs.
      ...tracking,
      site: normalizePayloadValue(formData.site),
      solution: normalizePayloadValue(formData.solution),
      enjeu: normalizePayloadValue(formData.enjeu),
      question_1: 'Type de site',
      reponse_1: normalizePayloadValue(formData.site),
      question_2: 'Solution envisagée',
      reponse_2: normalizePayloadValue(formData.solution),
      question_3: 'Enjeu principal',
      reponse_3: normalizePayloadValue(formData.enjeu)
    };

    const leadId = generateId();
    const leadPayload = { payload: { formId, id: leadId, data: payloadData } };

    // Corps urlencoded : type "simple" CORS => pas de pré-requête OPTIONS.
    const googleFormData = new URLSearchParams();
    Object.entries(payloadData).forEach(([key, value]) => googleFormData.set(key, value));
    googleFormData.set('form_id', formId);
    // Identifiant unique du lead (aligné avec leadPayload.payload.id).
    googleFormData.set('id_lead', leadId);
    // URL ayant servi à la capture, même si l'adresse courante a été nettoyée.
    googleFormData.set('page_url', safeText(trackingPageUrl, 1000));
    googleFormData.set('page_referrer', safeText(document.referrer, 1000));
    googleFormData.set('user_agent', safeText(navigator.userAgent, 300));
    googleFormData.set('langue', safeText(navigator.language || '', 20));

    debugLog('Lead payload ready', leadPayload);
    debugLog('Google payload ready', Object.fromEntries(googleFormData.entries()));

    /* ---- Envoi ---- */
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timeoutId = controller ? setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS) : null;

    const sendToGoogle = fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      mode: 'cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: googleFormData,
      signal: controller ? controller.signal : undefined
    }).then(async (response) => {
      // GAS répond HTTP 200 même en cas d'erreur métier : il FAUT lire le JSON.
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      let parsed = null;
      try { parsed = JSON.parse(text); } catch (err) { parsed = null; }
      if (!parsed || parsed.status !== 'ok') {
        throw new Error((parsed && parsed.message) || 'Réponse inattendue du script Google.');
      }
      return parsed;
    });

    const requests = [sendToGoogle];
    if (LEAD_API_URL) {
      requests.push(fetch(LEAD_API_URL, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(leadPayload)
      }).then((response) => {
        if (!response.ok) throw new Error(`API lead : HTTP ${response.status}`);
        return response;
      }));
    }

    Promise.all(requests).then(() => {
      showFormSuccess();
      // Conversion GA4 / GTM si un conteneur est présent sur la page.
      try {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({ event: 'generate_lead', form_id: formId });
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'generate_lead', { form_id: formId });
        }
      } catch (err) { /* le tracking ne doit jamais casser le succès */ }
    }).catch((sendError) => {
      console.error('Échec de l\'envoi du lead :', sendError);
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.innerHTML = originalLabel;
      }
      error.textContent = 'L\u2019envoi n\u2019a pas abouti. Vérifiez votre connexion puis réessayez (déploiement du script Google : accès « Tout le monde » + nouvelle version).';
      error.hidden = false;
    }).finally(() => {
      if (timeoutId) clearTimeout(timeoutId);
      isSubmitting = false;
    });
  });

  /* ---- Animations d'apparition ---- */
  const revealItems = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    }), { threshold: .12 });
    revealItems.forEach((item) => {
      item.style.animationPlayState = 'paused';
      observer.observe(item);
    });
  }
});
