# Recrutement de commerciaux — adaptation HTML/CSS, JS inchangé

## Fichiers et installation

**Remplacez uniquement `index.html` et `style.css`.** Gardez votre `script.js` et votre dossier `img/`, puis rechargez avec **Ctrl + F5**.

L’archive inclut une copie de `script.js` strictement identique au fichier joint : comparaison octet pour octet et SHA-256 vérifiées.

```text
e6ae6897669eed0083358435f1494d7dbaef112ce2be81c3512a399982afcdcb
```

Aucun JavaScript supplémentaire n’est ajouté : pas de script inline, pas de `onclick` / `onsubmit`, un seul chargement de `script.js` avec `defer`. Les quelques styles dans `<noscript>` sont du CSS de repli, pas du JavaScript.

```text
votre-site/
├── index.html
├── style.css
├── script.js   ← inchangé
└── img/       ← vos photos, fond et favicon existants
```

**Le dossier `img/` n’était pas joint.** Il n’est pas inclus dans l’archive ; ses chemins sont conservés, y compris le fond `img/cta.webp` utilisé par la CSS.

## 1. Formulaire adapté aux deux étapes du JS

Le HTML initial avait un formulaire `#besoin-form` en trois étapes. Le JS sélectionne exclusivement `#study-form` et gère deux étapes.

L’adaptation comporte maintenant :

1. **Votre besoin** : profil recherché obligatoire et secteur facultatif.
2. **Vous rappeler** : société, code postal, prénom, nom, téléphone, email et case d’accord obligatoire.

Les anciens écrans « Votre contexte » et « Vous rappeler » ont été regroupés, sans supprimer leurs champs.

Les sélecteurs attendus sont présents : `#study-form`, `.form-step`, `.form-next`, `.form-back`, `.form-error`, `.form-success`, `.form-progress`, `.form-wrap` et `.privacy-note`.

- La progression utilise les éléments `<i>` et `<b>` générés par le JS.
- Le message de succès est placé **à l’intérieur du formulaire**, pour être trouvé par le script.
- La note de confidentialité reste hors des étapes, donc visible après le succès.
- Le honeypot `website` et les 18 champs cachés de tracking sont présents.
- Les erreurs utilisent le message global que le JS sait actualiser, au lieu des anciens messages par champ non gérés.
- La règle téléphonique repose sur le JS existant ; un ancien `pattern` HTML redondant a été retiré pour ne pas entrer en conflit avec sa validation internationale.

### Correspondance des champs envoyés

| Information visible | Clé transmise |
|---|---|
| Identifiant de cette landing | `form_id = ADW_LP_RECRUTEMENT_COMMERCIAUX` |
| Profil recherché | **`solution`**, également recopié dans `reponse_2` |
| Secteur d’activité | **`site`**, également recopié dans `reponse_1` |
| Société | `societe` |
| Prénom / nom | `prenom` / `nom` |
| Téléphone | `telephone` |
| Email | `mail` |
| Code postal | `code_postal` |
| Attribution marketing | `source`, `categorie`, `user`, UTM, LTM et identifiants publicitaires |

Le JS ignore les clés `profil` et `secteur`. Les IDs visuels `f-profil` et `f-secteur` sont conservés, mais leurs attributs `name` deviennent respectivement `solution` et `site`. Les listes de choix sont inchangées.

L’identifiant de formulaire explicite évite d’utiliser le `DEFAULT_FORM_ID` AGV du JS. Les champs non proposés, comme `enjeu`, `civilite` et `ville`, restent vides.

### Consentement : validation, pas archivage

La case « J’accepte d’être recontacté·e » reste **obligatoire**. Le script contrôle sa validité parmi les champs requis : l’absence de coche bloque l’envoi dans l’interface.

**En revanche, le JS fourni ne copie pas `consent` dans son payload.** La case n’est donc pas enregistrée dans le Sheet et ne constitue pas une preuve de consentement archivée côté serveur. Ce point n’a pas été contourné en détournant un autre champ. Un enregistrement dédié nécessiterait une évolution du traitement JavaScript et du schéma serveur, non réalisée dans cette adaptation.

### Intitulés techniques conservés

Les libellés codés en dur dans le JS restent inchangés :

```text
question_1 = Type de site
question_2 = Solution envisagée
question_3 = Enjeu principal
```

Le secteur se retrouve donc sous `site` / `reponse_1`, et le profil sous `solution` / `reponse_2`, avec ces libellés techniques d’origine. Un champ HTML supplémentaire ne pourrait pas remplacer ces libellés reconstruits explicitement par le script.

## 2. Accordéons sans ajout de JS

Le JS joint ne gère ni `.acc-btn`, ni `.profile-head`. Les accordéons reposaient auparavant sur des gestionnaires absents.

Les **6 rubriques du constat et les 8 fiches profils** utilisent désormais des éléments HTML natifs `<details>` / `<summary>` :

- clic, Entrée et Espace fonctionnent sans code additionnel ;
- le premier constat reste ouvert au chargement ;
- plusieurs rubriques peuvent rester ouvertes ;
- les contenus restent accessibles avec JavaScript désactivé ;
- les flèches suivent l’attribut natif `open` en CSS.

### Fiches profils : pas de présélection automatique

Le JS fourni ne traite pas `data-choose-profile`. Les anciens boutons sont donc remplacés par des **liens vers le formulaire**.

La phrase promettant un préremplissage automatique a été remplacée. Après consultation d’une fiche, le visiteur choisit le profil dans le sélecteur du formulaire. Si le formulaire est déjà à la deuxième étape, le bouton Retour permet de modifier ce choix.

## 3. Navigation et affichage

- Le menu desktop est conservé ; le bouton mobile porte `.menu-toggle` et commande `#mobile-nav`, comme attendu par le JS.
- Le menu mobile se ferme après un clic sur un lien.
- Les CTA de rappel ciblent directement `#form-card` plutôt que le début de toute la section hero.
- Le CTA fixe mobile devient un lien natif, visible par CSS sur petit écran. Il n’attend plus une classe `.show` que le JS n’ajoute pas ; sa visibilité n’est pas conditionnée par un seuil de scroll.
- Une marge basse évite que le CTA fixe recouvre la fin de la page.
- Les états `hidden` sont prioritaires sur les règles de mise en page :

```css
[hidden], input[type="hidden"] {
  display: none !important;
}
```

- Les animations `.reveal` utilisent des keyframes pilotées par `animationPlayState`, au lieu d’attendre une classe `.in` absente du script.
- Le contenu reste visible sans `IntersectionObserver` et en mode de mouvement réduit.
- Les images mobiles et les grilles du formulaire ont été corrigées pour éviter les débordements sur petit écran.

Sans JavaScript, le formulaire est masqué avec un message explicatif plutôt que de proposer une soumission non gérée. Le menu mobile devient une navigation statique et les accordéons restent utilisables.

## 4. Confirmation et envoi réel

La personnalisation du prénom dans le message de succès et la promesse d’un SMS ont été retirées : le JS fourni ne réalise pas ces actions.

La mention du footer « formulaire simulé, aucune donnée transmise » a également été supprimée, car elle serait fausse avec votre script : **une soumission valide sur votre site appellera l’endpoint Google Apps Script déjà configuré**.

`code.gs` et l’URL du déploiement n’ont pas été modifiés. Le message de succès continue à dépendre de la réponse JSON `status: "ok"` vérifiée par votre JS.

## 5. Vérifier le tracking chez vous

Dans une nouvelle session privée, ouvrez par exemple :

```text
http://localhost:8000/?source=landing&categorie=recrutement_commerciaux&user=adw&ltm_source=landing&ltm_category=recrutement_commerciaux&ltm_typ=lead&ltm_user=adw
```

Le diagnostic déjà disponible dans votre JS reste utilisable dans la console :

```js
console.table(window.ubeproTracking.inspect().values);
```

Attendu : `source=landing`, `categorie=recrutement_commerciaux`, `user=adw`, `ltm_typ=lead`, et les correspondances UTM/LTM habituelles. Les champs absents de l’URL et de la session restent vides.

Après un envoi manuel de test, inspectez **Réseau → POST vers `/exec` → Payload**, puis le Sheet. Vous devez retrouver `ADW_LP_RECRUTEMENT_COMMERCIAUX`, le profil dans `solution` et le secteur dans `site`.

## 6. Vérifications effectuées

**32 vérifications locales réussies dans Chromium**, notamment :

- identité binaire du JS, absence de JS ajouté, IDs/ancres/labels valides ;
- formulaire en deux étapes, progression, retour, confirmation et conversion ;
- profil, secteur, coordonnées, UTM/LTM et click IDs dans le POST simulé ;
- secteur facultatif, téléphone international, consentement obligatoire ;
- validation du téléphone, du code postal et de l’email ;
- réponse serveur d’erreur, honeypot ;
- les 14 accordéons, clavier et liens des fiches ;
- menu mobile, CTA fixe et soumission mobile ;
- fonctionnement de repli sans JS, sans IntersectionObserver et en mouvement réduit ;
- stockage bloqué, URL nettoyée après chargement et visite directe sans attribution inventée ;
- absence de débordement testée à 320, 390, 768, 940, 1024 et 1365 px.

**Tous les envois des tests ont été interceptés. Aucun appel n’a atteint votre déploiement Google et aucune ligne n’a été ajoutée à votre Sheet.** Les images non jointes ont été remplacées uniquement dans l’environnement de test par une image de contrôle ; aucun remplacement n’est inclus dans les fichiers livrés.
