# Rapport — Parité CRM, analytics et cookies : LP Formation ↔ LP AGV/AMR

**Date** : 5 octobre 2026
**Objet** : porter sur la LP « Formation » l'intégralité du dispositif d'acquisition de la LP principale « AGV/AMR » (envoi CRM, Google Sheet, GTM/analytics, bandeau de consentement), avec vérification instrumentée.
**Livrable** : `LP_FORMATION_V2-optimisee.zip` (19 fichiers de page + ce rapport, 880 Ko compressés)
**Verdict** : parité fonctionnelle atteinte — **157 points de contrôle, 0 échec**, dont la validation faite sur l'archive extraite dans un dossier propre.

---

## 0. Synthèse en une page

| Volet demandé | Ce qui a été livré | État |
|---|---|---|
| **1. Analyse du JS `agv_amr`** | Cartographie complète du script (1 652 lignes beautifiées) : configuration, cycle de vie, table de suivi 18 clés, contrat de données, double envoi, gating par consentement | Fait — §1 |
| **2. CRM + *tous* les analytics reçus par AGV/AMR fonctionnels sur la formation** | `script.js` de la formation réécrit : capture UTM/gclid/msclkid/fbclid, `sessionStorage`, payloads Feuille + CRM complets, `dataLayer`/`gtag`, anti-spam, API de debug | Fait — §2 |
| **3. Cookies (consentement) d'AGV/AMR copiés dans la formation** | `cookie-consent.js` copié à l'identique + bandeau + modale + lien « Gérer les cookies » + Consent Mode v2 + CSS adapté | Fait — §3 |

**Trois défauts réels trouvés et corrigés au passage** (dont un bloquant) : le bandeau de cookies recouvrait physiquement le bouton d'envoi du formulaire ; `page_url` n'était jamais renseigné pour un visiteur arrivé sans paramètre UTM ; une règle CSS du bandeau écrasait la grille mobile du bandeau lui-même (colonne de texte réduite à 6 px). Détail en §4.

**Ce qui reste à faire avant la mise en ligne** est une checklist fermée de 8 points, §6 — dont la bascule du CRM de préproduction vers la production, qui n'est volontairement pas faite.

---

## 1. Volet 1 — Analyse du script de la LP AGV/AMR

Source analysée : `AGV_AMR/agv_amr/script.js` (minifié), copie lisible : `audit/agv-script-beautifie.js` (652 lignes, jsbeautifier).
Build en production côté AGV/AMR : `20261002-mobileform`.

### 1.1 Anatomie

Le fichier est une **IIFE unique**, sans dépendance externe, non modulaire, écrite pour tourner aussi bien en `<head>` qu'en fin de `<body>`. Six blocs fonctionnels :

1. **Configuration** — un `Object.assign` fusionne des valeurs par défaut avec `window.UBEPRO_CONFIG`.
2. **État de suivi** — mémoire en RAM + `sessionStorage`.
3. **Utilitaires** — normalisation de texte, parsing d'URL, normalisation de téléphone, UUID.
4. **Envoi** — deux fonctions distinctes, Feuille Google et CRM.
5. **Soumission** — `preventDefault`, honeypot, validation, `Promise.all` plafonné à 2,5 s.
6. **Analytics** — `dataLayer.push` + `gtag`, conditionnés au consentement.

### 1.2 Configuration : les clés qui comptent

Configuration effective relevée dans le fichier AGV/AMR :

```
googleScriptUrl      : https://script.google.com/macros/s/AKfycbwrbyCb9-…/exec
leadApiUrl           : https://mc.helloleadpreprod.fr/mon_compte/api/webflow/get_information.php
leadApiMode          : 'nocors'      // cors | nocors | off
leadApiCredentials   : 'omit'
formId               : 'ADW_LP_AGV_AMR'
crmStrictContract    : false
debug                : false
```

L'ordre du `Object.assign` est **structurant** : la configuration du client écrase les valeurs par défaut, donc tout `UBEPRO_CONFIG` déclaré **après** ce script serait ignoré. C'est la raison pour laquelle, dans les deux LP, le bloc de configuration est placé en `<head>` avant les scripts.

### 1.3 Cycle de vie, dans l'ordre réel d'exécution

1. **Lecture du consentement** à chaque appel, jamais figé au chargement : `analyticsGranted()` lit `window.__UBEPRO_COOKIE_PREFERENCES__.analytics`, `marketingGranted()` lit `.marketing`.
2. **Capture des paramètres** de l'URL au chargement, si et seulement si le consentement est déjà donné, sinon on ne stocke rien (pas de mesure avant consentement).
3. **Persistance** dans `sessionStorage` sous `ubepro_tracking_v1` (paramètres) et `ubepro_tracking_page_url_v1` (URL de capture).
4. **Soumission** : `preventDefault()`, contrôle du honeypot `input[name="website"]` (rempli ⇒ abandon silencieux, les bots ne reçoivent aucune erreur).
5. **Construction des deux payloads** : `sheetData` (complet) et `crmData` (contrat minimal + enrichissement consenti).
6. **Double envoi** en parallèle, chaque envoi étant indépendant : l'échec de l'un ne bloque jamais l'autre.
7. **Analytics** après envoi, sous condition de consentement.
8. **Résolution** via `Promise.all` plafonné à 2,5 s : l'utilisateur voit l'écran de succès au plus tard au bout de 2,5 s, même si un service distant est lent ou muet.

### 1.4 Le contrat de données

**Table de suivi — 18 clés**, chacune avec des alias multi-sources (les mêmes valeurs peuvent arriver sous `utm_*`, `ltm_*` ou nom court) :

```
source · categorie · user
utm_source · utm_medium · utm_campaign · utm_content · utm_term · utm_id
utm_category · utm_user
ltm_source · ltm_category · ltm_typ · ltm_user
gclid · msclkid · fbclid
```

Règles d'assainissement : toute valeur est tronquée à **500 caractères** (1 000 pour `page_url`, 300 pour `user_agent`, 20 pour `langue`) et les caractères `<` et `>` sont retirés — protection contre l'injection de balises dans la Feuille Google, qui est un tableur.

**Répartition par consentement** — c'est le point le plus important du script, et celui qui est le plus souvent mal recopié :

| Donnée | Condition | Destination |
|---|---|---|
| Coordonnées (`nom`, `prenom`, `mail`, `telephone`, `societe`, `code_postal`, `civilite`, `ville`) | aucune (base légale : exécution du contrat) | Feuille + CRM |
| `source`, `categorie`, `user` + questionnaires (`question_1..3` / `reponse_1..3`) | aucune | Feuille + CRM |
| `gclid`, `msclkid`, `fbclid` | **marketing** | Feuille + CRM |
| `utm_*`, `ltm_*`, `page_url`, `page_referrer`, `user_agent`, `langue` | **analytics** | Feuille + CRM (CRM sauf contrat strict) |

`crmStrictContract: true` réduit le payload CRM au strict contrat, sans les 16 champs de mesure : à n'activer que si le backend refuse des clés non déclarées.

**Les questionnaires sont déduits du formulaire, pas codés en dur** : le script remonte au `<label>` voisin du champ pour écrire la question, et non une chaîne figée. Conséquence pratique : modifier un libellé dans le HTML met à jour le CRM sans toucher au JS.

**Enveloppes réseau**

- Feuille Google : `POST` en `application/x-www-form-urlencoded`, réponse JSON devant contenir `{status:'ok'}` pour être considérée comme réussie.
- CRM : `POST` avec l'enveloppe **`{payload: {formId, id, data}}`**.
  - mode `cors` : `Content-Type: application/json`, validation du `status:'ok'` en retour, état `ok` / `error` ;
  - mode `nocors` : `sendBeacon` en premier (le plus fiable à la sortie de page), repli `fetch` `no-cors` + `keepalive`, `Content-Type: text/plain` — **l'en-tête JSON ne peut pas être posé en `no-cors`, il serait silencieusement supprimé** ; état `unverified`, ce qui est le comportement attendu et non une erreur.

### 1.5 Défauts latents du script principal, non reproduits

Relevés pendant l'analyse, sans correction puisque la consigne était « ne pas modifier la LP principale » :

- **`crmStrictContract` est lu une seule fois au chargement** ; un basculement dynamique n'est pas pris en compte. Sans effet en pratique.
- **Les clés de suivi personnalisées (`ltm_*`) ne sont pas documentées** et leur alias `ltm_typ` n'a pas d'équivalent `utm_typ` côté tableau ; à garder en tête si le media buying en ajoute.
- **Pas de paramètre de source `source` en priorité sur `utm_source`** : en cas de présence simultanée, l'ordre du tableau tranche (`source` gagne). Comportement reproduit à l'identique pour garantir des rapports comparables entre les deux LP.

---

## 2. Volet 2 — Le CRM et *tous* les analytics d'AGV/AMR, à l'identique sur la formation

### 2.1 Ce qui a été fait

`lp-optimisee/script.js` a été **entièrement réécrit** (23 Ko → 33 Ko) sur le modèle d'AGV/AMR, mais en **conservant tous les sélecteurs du markup de la formation** — un copier-coller du script principal aurait cassé le formulaire, les deux pages n'ayant pas la même structure.

Ajouté dans `index.html` : bloc de configuration `UBEPRO_CONFIG` en `<head>`, appel de `script.js?v=20261005-crm`, et les 13 identifiants du bandeau.

### 2.2 Tableau de parité

| Élément | AGV/AMR | Formation | Statut |
|---|---|---|---|
| Enveloppe CRM | `{payload:{formId,id,data}}` | identique | **conforme** |
| Mode d'envoi CRM | `nocors` (beacon → fetch) | `nocors` | **conforme** |
| `Content-Type` beacon | `text/plain;charset=UTF-8` | identique | **conforme** |
| `credentials` | `omit` | `omit` | **conforme** |
| Feuille Google | `x-www-form-urlencoded` + `{status:'ok'}` | identique, même URL | **conforme** |
| Table de suivi | 18 clés + alias | 18 clés + alias | **conforme** |
| Persistance | `ubepro_tracking_v1`, `ubepro_tracking_page_url_v1` | identiques | **conforme** |
| Gating marketing | clic-ids seulement | identique | **conforme** |
| Gating analytics | `utm_*`, `ltm_*`, `page_url`, `page_referrer`, `user_agent`, `langue` | identique | **conforme** |
| `crmStrictContract` | supporté | supporté | **conforme** |
| Envoi parallèle + plafond 2,5 s | oui | identique | **conforme** |
| Honeypot `website` | oui | identique | **conforme** |
| `normaliserTelephone` | à la soumission | identique | **conforme** |
| `dataLayer` : `generate_lead` | `{form_id, site_type, solution, enjeu}` | identique | **conforme** |
| `dataLayer` : `formulaire_lead` | oui | identique | **conforme** |
| `gtag` conversion | oui | identique | **conforme** |
| Événement de resynchronisation | `ubepro:consent-changed` | identique | **conforme** |
| API de debug `window.ubeproLead` | oui | identique (avec `introspect()`) | **conforme** |
| Identifiant de formulaire | `ADW_LP_AGV_AMR` | `ADW_LP_FORMATION` | **volontaire** |
| `form_id` injecté dans la Feuille | valeur de config | identique | **conforme** |

### 2.3 Différences assumées

1. **`formId: 'ADW_LP_FORMATION'`** — les deux LP doivent rester distinguables dans le CRM et la Feuille. Un fallback est prévu si la config n'est pas chargée : `config.formId || valeur du champ caché || 'ADW_LP_FORMATION'` (l'original de la formation n'avait aucun fallback, un `UBEPRO_CONFIG` manquant aurait envoyé un `form_id` vide).
2. **`civilite` et `ville`** : présents dans le formulaire AGV/AMR, absents du formulaire formation. Les clés restent envoyées **vides** plutôt qu'omises, pour que les colonnes du CRM et de la Feuille restent alignées entre les deux LP — un import CSV qui « décale » les colonnes est un défaut classique et coûteux.
3. **Le contenu des questionnaires** est nécessairement différent (les libellés diffèrent) mais la **structure est identique** : `question_1..3` / `reponse_1..3`, donc mêmes colonnes, même traitement côté back-office.

---

## 3. Volet 3 — Cookies et consentement copiés d'AGV/AMR

### 3.1 Copie à l'identique

`cookie-consent.js` a été **copié tel quel** (280 lignes, aucune modification) — la seule dépendance étant les identifiants présents dans le HTML, reproduits à l'identique :

```
content-cookie · content-cookie-modal · accept-all-banner-btn · manage-preferences-banner-btn
continue-without-accepting-btn · accept-all-modal-btn · refuse-all-modal-btn
save-preferences-modal-btn · modal-close-btn · essentials-toggle · analytics-toggle
marketing-toggle · open-cookie-preferences-btn
```

Cookie `user_cookie_preferences`, **durée 180 jours**, classe `cookie-modal-open` sur le `<body>` quand la modale est ouverte (verrouillage du défilement).

### 3.2 Consent Mode v2

Bloc placé en `<head>`, **avant** GTM (`GTM-53SH7D7F`), comme sur AGV/AMR :

- lecture du cookie avant tout appel réseau : une préférence enregistrée est réappliquée sans repasser par le bandeau ;
- `consent default` avec les 7 signaux en `denied` (sauf `functionality_storage` et `security_storage`), `wait_for_update: 500` ;
- `consent update` immédiat si une préférence existe déjà ;
- mise à jour envoyée depuis `cookie-consent.js` à chaque choix de l'utilisateur.

Absent du bloc par défaut mais aligné côté code : `ad_user_data` et `ad_personalization`, les deux signaux exigés par Google depuis 2024 pour l'EEE. Ils sont présents dans la mise à jour, donc un consentement marketing les passe bien à `granted`.

### 3.3 Effets sur la page

- **Purge** des clés `sessionStorage` de suivi tant que rien n'est consenti : aucun identifiant de campagne n'est conservé avant l'accord.
- **Restauration** immédiate après acceptation, puis nouvel appel de capture — l'utilisateur qui accepte après coup n'est pas perdu.
- **Resynchronisation** par l'événement `ubepro:consent-changed` : le script de suivi recharge ses valeurs sans rechargement de page.
- **« Gérer les cookies »** ajouté au pied de page, qui rouvre la modale — obligation pratique de la CNIL (le retrait du consentement doit être aussi simple que l'octroi).

### 3.4 Adaptations nécessaires (et pourquoi)

Le CSS du bandeau d'AGV/AMR ne pouvait pas être collé brut : la formation utilise une autre palette et une autre échelle typographique. Remplacements mécaniques : `--blue` → `--accent`, `--blue-deep` → `--accent-dark`, `--white` → `--card`, `--ink-soft` → `--ink`, `--body`/`--display` → `--font`. Aucune structure de règle modifiée. Les corrections de collision décrites en §4.1 ont été ajoutées **à la fin** du fichier, chacune dans une media query (la raison est expliquée en §4.3).

---

## 4. Défauts détectés et corrigés

### 4.1 BLOQUANT — le bandeau recouvrait le formulaire

C'est le défaut le plus grave trouvé, et il ne pouvait être détecté ni à l'œil sur une capture, ni par une suite de tests qui clique à l'aveugle.

- **Laptop 1280×800** : bandeau haut de 506 px, le bouton d'envoi passait dessous.
- **Mobile 390×844** : le bouton « Continuer » (étape 1) était **intégralement masqué**. `document.elementFromPoint()` au centre du bouton renvoyait le titre du bandeau puis « Tout refuser » — Playwright, lui, échouait sur un délai d'attente de clic de 30 s.

**Correction** — deux règles CSS pures, sans JavaScript :

```css
body:has(.cookie-banner:not([hidden])) { padding-bottom: 200px; }

@media (min-width: 1000px) {
  body:has(.cookie-banner:not([hidden])) .hero-aside {
    position: static; max-height: none; overflow: visible;
  }
}
```

**Impasse documentée** : une première tentative en `max-height: calc(100vh - …)` sur la carte du formulaire a été **pire** que le défaut — elle créait une barre de défilement interne qui masquait le bouton d'envoi. Ne pas réessayer. La solution retenue réserve de la place en bas de page et libère l'épinglage le temps du choix ; l'épinglage (`position: sticky`) est **rétabli automatiquement** une fois le bandeau fermé, ce que vérifie le test `edge.py`.

**Effet de bord assumé** : bandeau ouvert, la colonne du formulaire n'est plus épinglée au défilement. C'est le prix de la lisibilité du formulaire pendant la phase de consentement, et cela ne dure que le temps du choix.

### 4.2 FONCTIONNEL — `page_url` restait vide sans UTM

Le script de la formation ne renseignait `page_url` que dans la branche « l'URL contient des paramètres UTM ». Un visiteur arrivant **en direct** (référencement naturel, lien partagé, e-mail sans marquage) puis acceptant les cookies partait donc avec un `page_url` vide dans le CRM. Le script d'AGV/AMR l'initialise dès que la mesure d'audience est accordée. Corrigé, avec un test de non-régression.

À noter : cette donnée n'entre **jamais** dans le payload CRM sans consentement analytics, et elle n'est jamais ajoutée sans clé de stockage correspondante (côté back-end, une clé inconnue peut provoquer une erreur 500 ; en ajoutant `page_url` au seul payload CRM sans déclaration serveur, on casserait l'envoi).

### 4.3 CSS — la grille du bandeau écrasait sa propre grille mobile

`dbg-bandeau.py` a mesuré, sur mobile, une colonne de texte de **6 px** et une description de 470 px : la règle de grille du portage, déclarée sans condition et placée après le CSS d'origine, écrasait la règle `grid-template-columns: 1fr` du média mobile. **Toute nouvelle règle sur `.cookie-banner__inner` doit être enfermée dans une media query.** Version desktop scopée en `@media (min-width: 901px)`.

Résultat sur la hauteur du bandeau :

| Viewport | Avant | Après |
|---|---|---|
| mobile 390×844 | 506 px | **201 px** |
| petit 320×568 / 360×640 | — | **144 px** |
| tablette 768×1024 | — | **213 px** |
| desktop 1366×768 / 1280×800 | — | **147 / 146 px** |

### 4.4 Accessibilité — cible tactile du lien de politique

Le lien « politique de confidentialité » dans le bandeau mesurait **12 px** de haut, sous le minimum de 24 px (WCAG 2.5.8 / 44 px confortable). Corrigé par `padding-block: .4rem`. Les boutons du bandeau sont portés à `min-height: 44px`.

### 4.5 Deux artefacts de test, documentés pour éviter de chasser des fantômes

Ils ont produit de faux échecs ; ils ne traduisent aucun défaut de la page :

1. **`page.add_init_script` ne peut pas injecter `UBEPRO_CONFIG`** dans ces pages : le bloc `<script>` en ligne du `<head>` fait une **assignation** complète et écrase la valeur injectée. Deux « bugs » précédemment signalés venaient de là. La méthode correcte, désormais utilisée par le harnais, consiste à réécrire le document servi (`route.fulfill`) : `prepare(pg, config_patch={...})`.
2. **`scroll-behavior: smooth` fausse les mesures de position** : un `scrollIntoView` mesuré immédiatement après renvoie la position **avant** l'animation (`scrollY: 0` alors que la page peut défiler de 7 538 px). Les tests doivent utiliser `behavior: 'instant'`.

---

## 5. Validation — preuves

Toutes les suites tournent avec Chromium (Playwright). Les appels sortants (Feuille Google, CRM, GTM) sont **interceptés**, donc aucun lead de test n'a été envoyé à la production.

| Suite | Rôle | Résultat |
|---|---|---|
| `audit.py` | Rendu, débordement, cibles tactiles, erreurs console, images | **16/16 viewports** — 0 débordement, 0 erreur console |
| `verify.py` | SEO/GEO, structure, formulaire, accessibilité | **55 OK / 0 KO** |
| `edge.py` | Cas limites : paysage mobile, no-JS, clavier, validation, reduced-motion | **17 OK / 0 KO** |
| `test-crm-consent.py` | CRM, analytics, consentement : A → E | **62 OK / 0 KO** |
| `test-recouvrement2.py` | Collision bandeau / bouton, 7 viewports | **7/7** |

**157 points de contrôle, 0 échec.**

Détail de `test-crm-consent.py` :

- **A1–A14 — sans consentement** : le lead part quand même (base légale : exécution du contrat) ; en revanche `page_url`, `user_agent`, UTM et clic-ids sont **absents**, et **aucun** événement de conversion n'est poussé. C'est le comportement attendu, pas une régression.
- **B1–B29 — consentement accordé** : cookie écrit, `consent update` envoyé, `cookie_preferences_updated`, événement `ubepro:consent-changed` qui resynchronise, `POST` CRM avec `formId` et UUID valides, `generate_lead` + `formulaire_lead` poussés, 0 erreur JavaScript.
- **C1–C4 — refus** : aucun suivi, aucun événement, aucune fuite de donnée de mesure.
- **D1–D8 — modale** : réouverture par le pied de page, préférences persistées après rechargement.
- **E1–E5** : mode `cors`, contrat strict `crmStrictContract`, et vérification que la configuration de test est bien appliquée (E0 / E3b).

Détail de `test-recouvrement2.py` — les deux étapes du formulaire sont cliquables **bandeau ouvert**, sur les 7 viewports :

| Viewport | Hauteur bandeau | Étape 1 | Étape 2 |
|---|---|---|---|
| desktop 1366×768 | 147 px | OK | OK |
| laptop 1280×800 | 146 px | OK | OK |
| laptop court 1366×600 | 147 px | OK | OK |
| tablette 768×1024 | 213 px | OK | OK |
| mobile 390×844 | 201 px | OK | OK |
| mobile court 360×640 | 144 px | OK | OK |
| petit 320×568 | 144 px | OK | OK |

### Validation de l'archive livrée

L'archive a été **extraite dans un dossier propre** (`/tmp/verif-final`), servie sur un port distinct, et les cinq suites y ont été rejouées : **55/0, 62/0, 17/0, 16/16, 7/7**. L'archive contient bien les 19 fichiers de la page, `cookie-consent.js` inclus, et `index.html` le référence deux fois (script + bloc de préférences).

Empreintes SHA-256 (préfixe) des fichiers de code de l'archive :

```
index.html        0da9b2ec0228bfc1    style.css        59322fb8459586c6
script.js         da131a35134eb908    cookie-consent.js 798ea11a44cbff30
```

---

## 6. Avant mise en ligne — checklist

1. **Bascule CRM** : `leadApiUrl` pointe sur `mc.helloleadpreprod.fr` (préproduction). À remplacer par l'URL de production. **Bloquant pour la mise en ligne.**
2. **`formId`** : `ADW_LP_FORMATION` doit être déclaré côté CRM, sinon les leads arrivent avec un identifiant inconnu.
3. **GTM** : conteneur `GTM-53SH7D7F` repris d'AGV/AMR. Si la LP formation doit avoir son propre conteneur, ne changer que cet identifiant.
4. **Domaine de publication** : `canonical` et `og:url` portent encore un domaine d'exemple. À figer avant indexation.
5. **Bandeau** : vérifier l'URL de la politique de confidentialité et le libellé du responsable de traitement.
6. **`robots.txt` / `sitemap.xml` / `llms.txt`** : recommandés pour le GEO (visibilité dans les moteurs de réponse). Non livrés dans cette itération, l'effort est de quelques minutes une fois le domaine connu.
7. **`preconnect`** vers `script.google.com` : gain de latence à la soumission, une ligne. Non livré ici.
8. **Back-end** : confirmer la réception d'un lead de recette de bout en bout, une fois les points 1 et 2 faits. Les tests actuels valident l'émission, pas l'acceptation par le serveur.
9. **Vigilance documentaire** : `https://www.ubepro.fr/contact` renvoie une erreur 404 — ce lien ne doit être utilisé ni en appel à l'action, ni en repli `noscript`.

---

## 7. Rejouer les tests

```bash
# Serveur local
cd /home/user/lp-optimisee && python3 -m http.server 8090 --bind 0.0.0.0 &

cd /home/user/audit
python3 audit.py  http://127.0.0.1:8090/ screens/     # 16/16 viewports
python3 verify.py http://127.0.0.1:8090/             # 55 OK / 0 KO
python3 edge.py   http://127.0.0.1:8090/             # 17 OK / 0 KO
python3 test-crm-consent.py http://127.0.0.1:8090/   # 62 OK / 0 KO
python3 test-recouvrement2.py http://127.0.0.1:8090/ # 7/7
```

Dépendances non persistées, à réinstaller au besoin : `python3 -m playwright install chromium` et `pip install jsbeautifier`.

Rappel utile pour de futures campagnes de test : le consentement se lit dans `window.__UBEPRO_COOKIE_PREFERENCES__` (défini avant le chargement du script) ou s'obtient par le vrai parcours utilisateur en cliquant `#accept-all-banner-btn`.

---

## 8. Livrables

| Fichier | Contenu |
|---|---|
| `LP_FORMATION_V2-optimisee.zip` | **Livrable principal** — LP formation complète (19 fichiers) avec CRM, analytics et cookies en parité, + les deux rapports |
| `audit/RAPPORT-CRM-ANALYTICS-COOKIES.md` | Ce rapport |
| `audit/agv-script-beautifie.js` | Script AGV/AMR lisible (652 lignes), référence de l'analyse |
| `audit/cookie-css-complet.css`, `audit/cookie-markup.html` | Bloc cookies d'AGV/AMR extrait, source du portage |
| `audit/audit.py`, `verify.py`, `edge.py`, `test-crm-consent.py`, `test-recouvrement2.py` | Les cinq suites, réutilisables telles quelles |
