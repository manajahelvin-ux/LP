# LP Formation Management PME & ETI — Rapport d'optimisation

**Version** : 2026-10-05 · **Source** : `github.com/manajahelvin-ux/hello.git` → `LP_FORMATION_V2.zip`
**Livrable** : dossier `lp-optimisee/` (index.html, style.css, script.js, img/)
**Vérification** : 86 contrôles automatisés (Chromium 153) — **86 OK / 0 échec**

---

## 1. SEO / GEO

### Ce qui manquait (audit initial)
Aucune donnée structurée, aucune image Open Graph, aucun canonical, `title` à 84 caractères
(tronqué en SERP), pas de directive robots, pas de `hreflang`, pas de `preconnect`.

### Ce qui a été mis en place

| Élément | État |
|---|---|
| `title` | 84 → **61 caractères** (le mot-clé « Formation Management PME & ETI » en tête) |
| `meta description` | réécrite, 163 car., avec le bénéfice + le CTA |
| `canonical` + `hreflang` fr-FR / x-default | ajoutés |
| `robots` | `index, follow, max-snippet:-1, max-image-preview:large` |
| Open Graph + Twitter Card | complets, **image 1200×630 générée** (`img/og-ubepro-formation-management.jpg`) |
| JSON-LD `@graph` | `Organization`, `WebSite`, `WebPage`, `Service` + `OfferCatalog` (3 parcours), `FAQPage` (6 Q/R), `BreadcrumbList`, `EducationalOrganization` |
| FAQ structurée | **synchronisée 1:1** avec la FAQ visible (vérifié automatiquement) |
| Hiérarchie sémantique | 1 seul `H1`, 8 `H2` numérotés, `H2` sur le titre du formulaire |
| Accessibilité machine | `alt` descriptifs enrichis (contexte métier), `aria-label` sur les 5 étoiles |

### Logique GEO (moteurs génératifs)
- **Contenu citable** : chaque section répond à une question autonome (pour qui / enjeux /
  solutions / méthode / financement / avis / FAQ) — format que les moteurs génératifs reprennent.
- **Chiffres exploitables** : +2000, 90 %, 100 %, 90 jours, 48 h, France — présents en texte
  (pas en image), donc extractibles.
- **Entités reliées** : `Organization` ↔ `WebSite` ↔ `Service` ↔ `FAQPage` ↔
  `EducationalOrganization` via `@id`, ce qui évite les entités orphelines.
- **Autorisation de citation explicite** : `max-snippet:-1` et `max-image-preview:large`
  (la consigne `nosnippet` est volontairement absente).
- Aucun `AggregateRating` déclaré : Google exige des avis rattachés à une entité vérifiable.
  Mieux vaut zéro balisage qu'un balisage non conforme (risque d'action manuelle).

> **Capital sémantique conservé à l'identique** : seul le premier mot du `H1` a changé
> (« Transformez » → « Former »), les 5 `H2`, les 3 `H3` de parcours et tous les `H4` sont
> les textes d'origine, auxquels s'ajoutent le mot-clé de la page et 2 `H3` de financement.

---

## 2. Formulaire en haut à droite

**Avant** : formulaire unique en bas de page (~7 000 px de scroll), dupliqué dans les liens
d'ancrage. **Après** : une seule instance, placée en haut à droite dans le hero.

- Desktop ≥ 1000 px : grille `1fr / 420px`, la carte est **sticky** et reste épinglée sous le
  header pendant toute la traversée du hero, puis libère la place (aucun chevauchement).
- Mobile / tablette : flux normal, **juste après le titre et le sous-titre** — visible dès la
  2ᵉ section d'écran, avant les pastilles et les CTA.
- **Tous les liens « Recevoir mon offre » mènent désormais à ce formulaire** : plus aucune
  duplication, donc plus aucun risque de désynchronisation.
- CTA de secours permanent dans le header collant (`header-cta`), masqué sous 1000 px au profit
  de la barre fixe bas de page.

---

## 3. Soumission rapide

### Optimisations

| Action | Effet |
|---|---|
| `<link rel="preconnect">` + `dns-prefetch` vers `script.google.com` | poignée de main TLS établie **pendant** le chargement |
| Champ de décision placés en **étape 1** (formation / effectif / enjeu) | l'utilisateur s'engage avant de donner ses coordonnées |
| Étape 2 sur **2 colonnes** (desktop) | 9 champs sans scroll, libellés sur une ligne |
| Toutes les valeurs `autocomplete` | remplissage automatique navigateur / gestionnaire de mots de passe |
| `inputmode` + `enterkeyhint` sur les 6 champs | claviers adaptés sur mobile, touche « suivant / terminé » |
| Focus automatique du premier champ à chaque étape | moins de gestes |
| Étape 1 : 3 `select` (aucun clavier) | rapide au pouce |
| Validation : le message natif du navigateur est relayé | l'utilisateur sait exactement quoi corriger |
| `aria-busy` + libellé « Envoi en cours… » | feedback immédiat, anti double-envoi |
| Anti-double-envoi (`isSubmitting`) + timeout 15 s | pas de lead en double ni de blocage |

### Mesuré en 4G lente (1,6 Mb/s, 150 ms RTT, CPU ÷4, mobile 390 px)

| | Avant | Après |
|---|---|---|
| Poids réseau | 190 Ko | **146 Ko** (−23 %) |
| Image hero | 142 Ko · 1087 ms | **95 Ko · 916 ms** (−171 ms) |
| Load complet | 1293 ms | **1107 ms** (−14 %) |

> Le poids des images passe de 754 Ko à 285 Ko (**−62 %**) grâce au WebP + JPEG progressif
> redimensionné. Le gain est proportionnellement plus fort en 3G.

---

## 4. Responsive — téléphone, tablette, mobile, ordinateur, navigateurs

**16 viewports testés** de 320×568 à 1920×1080 : **0 débordement horizontal, 0 cible tactile
sous le seuil, 0 erreur console, 0 image cassée.**

| Correctif | Détail |
|---|---|
| **Police des champs** | 13,3 px → **16 px** (en dessous de 16 px, iOS zoome automatiquement au focus) |
| **Menu mobile** | le burger était **invisible** (16 × 6 px) : les règles `.menu-toggle` / `.menu-bars` avaient été perdues. Restauré à **46 × 46 px** avec animation d'ouverture |
| **Cibles tactiles** | liens de pied de page 16 px de haut → padding en pointeur grossier (**seuil WCAG 2.5.8 = 24 px**) |
| **Bug CSS** | `padding: .7rem max(...) 1.1rem;` = 3 valeurs, déclaration **invalide** rejetée par le navigateur → `padding` réel erroné. Corrigé en 4 valeurs |
| **Images sans dimensions** | 4/4 → **0/4** (plus de décalage de mise en page pendant le chargement) |
| **Sticky cassé** | `overflow: clip` sur `.hero` neutralisait `position: sticky` → remplacé par `overflow-x: clip` sur `body`, sans conteneur de défilement |
| **Desktop court** | `max-height: calc(100vh − 9.5rem)` sur la colonne : le bouton d'envoi reste joignable à 600 px de haut |
| **Paysage mobile** (667×375) | vérifié, sans débordement, CTA principal visible |
| **Écrans 320 px** | paddings réduits, titres adaptés, boutons empilés, `form-actions` en colonne |
| **Zones sûres iOS** | `env(safe-area-inset-bottom)` + `viewport-fit=cover` |
| **`prefers-reduced-motion`** | respecté (animations et défilement doux désactivés) |
| **Impression** | feuille `@media print` (header, barre fixe et formulaire masqués) |

---

## 5. Bugs corrigés (hors demande initiale)

| # | Bug | Impact |
|---|---|---|
| 1 | `DEFAULT_FORM_ID = 'ADW_LP_AGV_AMR'` dans le JS | ID de formulaire **erroné** pour cette page : si le champ caché venait à manquer, les leads auraient été rattachés au mauvais formulaire. Corrigé en `ADW_LP_FORMATION` |
| 2 | Message d'erreur affiché aux visiteurs | Exposait l'implémentation interne (« redéployez le script Apps Script », « accès Tout le monde »). Message client générique en façade, détail technique en console |
| 3 | Champ invalide signalé sans message | La validation d'étape bloquait sans indiquer quoi corriger |
| 4 | Menu mobile inopérant visuellement | Voir §4 |
| 5 | Mention « Version de travail : branchement du formulaire à finaliser » en pied de page | Visible par les visiteurs en production → **retirée** |
| 6 | Focus non géré entre les étapes | Ajouté |
| 7 | 3 règles CSS mortes, 1 lookup JS mort | Nettoyés |

---

## 6. Ce qui reste à faire **avant mise en ligne** (à fournir par le client)

1. **Domaines / URLs** : la `canonical`, les `og:url` et les URL https://www.ubepro.fr/... sont
   à confirmer selon le domaine réel de publication. L'URL `/contact` a été **testée et renvoie
   404** : elle n'est donc utilisée nulle part (le message « sans JavaScript » pointe vers la page
   programme, vérifiée en 200).
2. **Qualifications légales — bloquant** :
   - SIRET et numéro de déclaration d'activité sont **obligatoires** sur toute communication
     d'un organisme de formation (art. L.6352-4 et R.6351-7-1 du Code du travail) ;
   - la mention **Qualiopi** doit être exacte (le bloc JSON-LD `hasCredential` l'attend, et un
     faux balisage de certification crée un risque juridique et SEO).
3. **Branchement du formulaire** : le endpoint Google Apps Script reste inchangé. `LEAD_API_URL`
   est prêt pour un CRM.
4. **Témoignages** : 4 avis anonymisés (Marie L., Thomas C., Sophie R., Pierre A.). Ils doivent
   être authentiques et vérifiables (allégations commerciales) — à documenter.
5. **Visuels** : images d'ambiance générées par IA, à remplacer par de vraies photos.
6. **Chiffres** : +2000, 90 %, 100 % proviennent de l'ancienne page — à pouvoir justifier.

---

## 7. Comment tester

```bash
# serveur local
cd lp-optimisee && python3 -m http.server 8090

# les 3 suites de contrôle
python3 audit/audit.py  http://127.0.0.1:8090/   # responsive 16 viewports
python3 audit/verify.py http://127.0.0.1:8090/   # 55 contrôles SEO / formulaire / a11y
python3 audit/edge.py                            # 15 cas limites
```

Dans la console du navigateur :
```js
window.ubeproTracking.inspect()   // paramètres UTM/gclid capturés, URL de capture
```

---

## 8. Ce qui a été volontairement **préservé**

- `script.js` : aucune colonne du Google Sheet n'est modifiée, le contrat de nommage des clés
  (`solution`, `site`, `enjeu`, `nom`, `prenom`, `societe`, `mail`, `telephone`, `code_postal`)
  est intact, le honeypot `website` et les 20 champs de tracking sont conservés.
- Le mécanisme anti-spam, le timeout, l'UUID de lead, l'interception de secours anti-double-envoi.
- Tous les textes client, les 5 piliers, les 3 parcours, la liste des OPCO, les témoignages,
  la FAQ, les liens légaux.
- L'accessibilité existante : lien d'évitement, `role="tablist"` sur les profils, `role="alert"`
  sur l'erreur, `role="status"` sur le succès, lecture correcte **sans JavaScript**.
