/**
 * UBEPRO — Landing page Formation Management PME & ETI
 * Formulaire multi-étapes · tracking URL (UTM, gclid, msclkid, fbclid, ltm)
 * · envoi vers Google Sheets (Apps Script) ET vers le CRM Hellolead
 * · analytics GTM/GA4 conditionnés au consentement.
 *
 * Porté depuis la LP principale AGV/AMR (build 20261002-mobileform) :
 *   A. Configuration injectable via window.UBEPRO_CONFIG (formId, CRM, mode...)
 *   B. Connecteur CRM multi-mode : cors | nocors (sendBeacon → fetch) | off
 *   C. Envoi parallèle Sheets + CRM, avec détection de succès partiel
 *   D. Consentement Google Mode v2 : capture du tracking et données de
 *      navigation conditionnées à l'accord analytics / marketing
 *   E. Analytics GA4/GTM : generate_lead (form_id, site_type, solution, enjeu)
 *      puis formulaire_lead
 *
 * Conservé de la version précédente de cette LP (déjà validé par tests) :
 *   - synchronisation des champs cachés AVANT FormData
 *   - vérification de la réponse JSON du script Google (status === 'ok')
 *   - honeypot anti-spam, anti-double-envoi, timeout, fallback UUID
 *   - message d'erreur utilisateur générique (détail technique en console)
 *   - validation par étape avec message natif du navigateur
 *
 * Diagnostic console : window.ubeproTracking.inspect() · window.ubeproLead.preview()
 * Version : 2026-10-05.4-form-lead
 */

/* ------------------------------------------------------------------ */
/* Configuration                                                       */
/* ------------------------------------------------------------------ */

const CONFIG = Object.assign({
  googleScriptUrl: 'https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec',
  leadApiUrl: '',                                   // CRM désactivé par défaut
  leadApiMode: 'nocors',                            // cors | nocors | off
  leadApiCredentials: 'omit',                       // omit | include
  formId: 'ADW_LP_FORMATION',
  crmStrictContract: false,
  debug: false
}, window.UBEPRO_CONFIG || {});

const GOOGLE_SCRIPT_URL = CONFIG.googleScriptUrl;
const LEAD_API_URL = CONFIG.leadApiUrl;
const LEAD_API_MODE = CONFIG.leadApiMode;
const LEAD_API_CREDENTIALS = CONFIG.leadApiCredentials === 'include' ? 'include' : 'omit';
const FORM_ID = CONFIG.formId || 'ADW_LP_FORMATION';
const CRM_STRICT_CONTRACT = CONFIG.crmStrictContract === true;
const DEBUG = CONFIG.debug === true;

// Domaine statique transmis au CRM et mappé sur page_referrer dans Google Sheets.
const domaine = 'ubepro.com';

const TRACKING_STORAGE_KEY = 'ubepro_tracking_v1';
const TRACKING_PAGE_STORAGE_KEY = 'ubepro_tracking_page_url_v1';
const TRACKING_VERSION = '2026-10-05.4-form-lead';
const SHEET_TIMEOUT_MS = 15000;
const CRM_TIMEOUT_MS = 5000;
const SLOW_NOTICE_MS = 2500;

/* Message unique affiché à l'utilisateur : jamais de détail technique.
   Cette LP n'affiche aucun numéro de téléphone (choix client). */
const MESSAGE_SEND_FAILED = 'Votre demande n\u2019a pas pu \u00eatre envoy\u00e9e. V\u00e9rifiez votre connexion puis r\u00e9essayez.';

const TRACKING_KEYS = [
  { key: 'source', aliases: ['source', 'utm_source', 'ltm_source'] },
  { key: 'categorie', aliases: ['categorie', 'utm_category', 'ltm_category', 'category'] },
  { key: 'user', aliases: ['user', 'utm_user', 'ltm_user'] },
  { key: 'utm_source', aliases: ['utm_source', 'ltm_source', 'source'] },
  { key: 'utm_medium', aliases: ['utm_medium', 'medium'] },
  { key: 'utm_campaign', aliases: ['utm_campaign', 'campaign'] },
  { key: 'utm_content', aliases: ['utm_content', 'content'] },
  { key: 'utm_term', aliases: ['utm_term', 'term'] },
  { key: 'utm_id', aliases: ['utm_id', 'campaign_id'] },
  { key: 'utm_category', aliases: ['utm_category', 'ltm_category', 'categorie', 'category'] },
  { key: 'utm_user', aliases: ['utm_user', 'ltm_user', 'user'] },
  { key: 'ltm_source', aliases: ['ltm_source', 'utm_source', 'source'] },
  { key: 'ltm_category', aliases: ['ltm_category', 'utm_category', 'categorie', 'category'] },
  { key: 'ltm_typ', aliases: ['ltm_typ', 'utm_typ', 'typ'] },
  { key: 'ltm_user', aliases: ['ltm_user', 'utm_user', 'user'] },
  { key: 'gclid', aliases: ['gclid'] },
  { key: 'msclkid', aliases: ['msclkid'] },
  { key: 'fbclid', aliases: ['fbclid'] }
];

/* ------------------------------------------------------------------ */
/* Consentement — lu à chaque appel, jamais figé au chargement          */
/* ------------------------------------------------------------------ */

const analyticsGranted = () => window.__UBEPRO_COOKIE_PREFERENCES__?.analytics === true;
const marketingGranted = () => window.__UBEPRO_COOKIE_PREFERENCES__?.marketing === true;
const trackingGranted = () => analyticsGranted() || marketingGranted();
/** Les identifiants de clic relèvent du marketing, le reste de la mesure d'audience. */
const trackingKeyGranted = (key) =>
  ['gclid', 'msclkid', 'fbclid'].includes(key) ? marketingGranted() : analyticsGranted();

/* ------------------------------------------------------------------ */
/* Utilitaires                                                         */
/* ------------------------------------------------------------------ */

const safeText = (value, maxLength = 500) => {
  const text = String(value ?? '').replace(/\s+/g, ' ').trim();
  return text.slice(0, maxLength);
};

const normalizePayloadValue = (value) => {
  const sanitized = safeText(value, 500);
  return sanitized.replace(/[<>]/g, '');
};

const debugLog = (...args) => { if (DEBUG) console.log('[ubepro]', ...args); };

/** UUID v4 avec repli si crypto.randomUUID est indisponible (contexte non-HTTPS). */
const generateId = () => {
  try {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
  } catch (err) { /* contexte non sécurisé */ }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const value = char === 'x' ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
};

/* ------------------------------------------------------------------ */
/* Tracking URL : capture conditionnée au consentement                 */
/* ------------------------------------------------------------------ */

const ENTRY_PAGE_URL = typeof window.__UBEPRO_ENTRY_URL__ === 'string'
  ? window.__UBEPRO_ENTRY_URL__
  : window.location.href;

const parseParamsFromString = (searchString) => {
  const params = Object.create(null);
  new URLSearchParams(searchString || '').forEach((value, key) => {
    const cleanKey = String(key).trim().toLowerCase();
    const cleanValue = normalizePayloadValue(value);
    if (cleanKey && cleanValue) params[cleanKey] = cleanValue;
  });
  return params;
};

/** Query classique, #/page?source=... et #source=... ; la query est prioritaire. */
const getUrlParams = (href = window.location.href) => {
  try {
    const url = new URL(href, window.location.href);
    const hash = url.hash.slice(1);
    const queryIndex = hash.indexOf('?');
    const hashQuery = queryIndex !== -1
      ? hash.slice(queryIndex + 1)
      : (hash.includes('=') && !hash.startsWith('/') ? hash : '');
    return {
      ...parseParamsFromString(hashQuery),
      ...parseParamsFromString(url.search)
    };
  } catch (err) {
    return {};
  }
};

/** Ne relire que les clés connues ET autorisées par le consentement. */
const readStoredParams = () => {
  if (!trackingGranted()) return {};
  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(TRACKING_STORAGE_KEY) || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    const stored = {};
    TRACKING_KEYS.forEach(({ key }) => {
      if (!trackingKeyGranted(key)) return;
      if (Object.prototype.hasOwnProperty.call(parsed, key) && typeof parsed[key] === 'string') {
        const value = normalizePayloadValue(parsed[key]);
        if (value) stored[key] = value;
      }
    });
    return stored;
  } catch (err) {
    return {};
  }
};

let trackingMemory = readStoredParams();
let trackingPageUrl = analyticsGranted() ? ENTRY_PAGE_URL : '';
try {
  if (trackingGranted()) {
    const storedUrl = window.sessionStorage.getItem(TRACKING_PAGE_STORAGE_KEY);
    if (storedUrl && Object.keys(trackingMemory).length > 0) trackingPageUrl = storedUrl;
  }
} catch (err) { /* Mémoire seule, pour cette page. */ }

const storeParams = (params) => {
  trackingMemory = { ...trackingMemory, ...params };
  try {
    window.sessionStorage.setItem(TRACKING_STORAGE_KEY, JSON.stringify(trackingMemory));
  } catch (err) { /* Les valeurs restent disponibles en mémoire. */ }
  return { ...trackingMemory };
};

/**
 * Capture pare-balles : garde-fou de consentement ÉVALUÉ À CHAQUE APPEL.
 * Un visiteur qui refuse puis accepte voit donc sa campagne capturée après
 * l'accord, sans rechargement de page.
 */
const captureTrackingParams = (href = window.location.href) => {
  if (!trackingGranted()) return { ...trackingMemory };

  // BUG CORRIGÉ : sans paramètre UTM dans l'URL, cette fonction ne renseignait
  // jamais page_url. Un visiteur arrivé en direct puis acceptant les cookies
  // partait donc avec un page_url vide, alors que le script AGV/AMR l'initialise
  // dès que la mesure d'audience est accordée. On rattrape le cas ici.
  if (analyticsGranted() && !trackingPageUrl) {
    trackingPageUrl = safeText(href, 1000);
    try {
      window.sessionStorage.setItem(TRACKING_PAGE_STORAGE_KEY, trackingPageUrl);
    } catch (err) { /* L'URL de capture reste en mémoire. */ }
  }

  const urlParams = getUrlParams(href);
  const relevant = {};
  TRACKING_KEYS.forEach(({ key, aliases }) => {
    if (!trackingKeyGranted(key)) return;
    const foundAlias = aliases.find((alias) => urlParams[alias]);
    if (foundAlias) relevant[key] = urlParams[foundAlias];
  });
  if (Object.keys(relevant).length > 0) {
    storeParams(relevant);
    if (analyticsGranted()) {
      trackingPageUrl = safeText(href, 1000);
      try {
        window.sessionStorage.setItem(TRACKING_PAGE_STORAGE_KEY, trackingPageUrl);
      } catch (err) { /* L'URL de capture reste elle aussi en mémoire. */ }
    }
  }
  return { ...trackingMemory };
};

/** URL courante > valeurs capturées ; aucune clé non consentie ne sort. */
const getTrackingValues = () => {
  captureTrackingParams();
  return Object.fromEntries(TRACKING_KEYS.map(({ key }) => [
    key, trackingKeyGranted(key) ? normalizePayloadValue(trackingMemory[key]) : ''
  ]));
};

captureTrackingParams(ENTRY_PAGE_URL);
captureTrackingParams();

window.ubeproTracking = Object.freeze({
  version: TRACKING_VERSION,
  inspect: () => ({
    version: TRACKING_VERSION,
    current_url: window.location.href,
    page_url: safeText(trackingPageUrl, 1000),
    consent: {
      analytics: analyticsGranted(),
      marketing: marketingGranted()
    },
    values: getTrackingValues()
  })
});

/* ------------------------------------------------------------------ */
/* Téléphone / code postal                                             */
/* ------------------------------------------------------------------ */

const normalizePhone = (value) => {
  let text = String(value || '').replace(/[^\d+]/g, '');
  if (/^\+?00/.test(text)) text = `+${text.replace(/^\+?00/, '')}`;
  if (text.startsWith('+33')) text = `0${text.slice(3)}`;
  if (text.startsWith('33') && text.length === 11) text = `0${text.slice(2)}`;
  return text;
};

const validatePhone = (value) => {
  const normalized = normalizePhone(value);
  if (/^0[1-9]\d{8}$/.test(normalized)) return true;
  return /^\+[1-9]\d{7,14}$/.test(normalized);
};

const validatePostal = (value) => /^\d{5}$/.test(String(value || '').replace(/\s+/g, ''));

const formatPhoneInput = (value) => {
  return /^0\d+$/.test(value) ? value.replace(/(\d{2})(?=\d)/g, '$1 ').trim() : value;
};

/* ------------------------------------------------------------------ */
/* Initialisation                                                      */
/* ------------------------------------------------------------------ */

document.addEventListener('DOMContentLoaded', () => {
  /* ---- Menu mobile ---- */
  const menuToggle = document.querySelector('.menu-toggle');
  const mobileNav = document.querySelector('#mobile-nav');
  menuToggle?.addEventListener('click', () => {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!isOpen));
    if (mobileNav) mobileNav.hidden = isOpen;
  });
  mobileNav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    menuToggle?.setAttribute('aria-expanded', 'false');
    if (mobileNav) mobileNav.hidden = true;
  }));

  /* ---- Onglets profil ---- */
  const tabs = document.querySelectorAll('[data-tab]');
  const panels = document.querySelectorAll('[data-panel]');
  tabs.forEach((tab) => tab.addEventListener('click', () => {
    const target = tab.dataset.tab;
    tabs.forEach((item) => {
      const active = item === tab;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-selected', String(active));
    });
    panels.forEach((panel) => {
      const active = panel.dataset.panel === target;
      panel.classList.toggle('is-active', active);
      panel.hidden = !active;
    });
  }));

  captureTrackingParams();

  const form = document.querySelector('#study-form');
  if (!form) return;

  const steps = [...document.querySelectorAll('.form-step')];
  const progress = document.querySelector('.form-progress');
  const error = document.querySelector('.form-error');
  const successBox = form.querySelector('.form-success');
  const phoneField = form.querySelector('input[name="telephone"]');
  const postalField = form.querySelector('input[name="code_postal"]');
  const honeypotField = form.querySelector('input[name="website"]');
  const nextButton = form.querySelector('.form-next');
  const backButton = form.querySelector('.form-back');

  /* ---- Champs cachés de tracking (URL + sessionStorage) ---- */
  const trackingFields = Object.fromEntries(TRACKING_KEYS.map(({ key }) => {
    let field = form.querySelector(`[name="${key}"]`);
    if (!field) {
      field = document.createElement('input');
      field.type = 'hidden';
      field.name = key;
      form.prepend(field);
    }
    return [key, field];
  }));

  const fillTrackingFields = () => {
    const values = getTrackingValues();
    Object.entries(values).forEach(([name, value]) => {
      if (trackingFields[name]) trackingFields[name].value = value;
    });
    return values;
  };
  fillTrackingFields();
  ['pageshow', 'hashchange', 'popstate'].forEach((eventName) => {
    window.addEventListener(eventName, fillTrackingFields);
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') fillTrackingFields();
  });
  // Le consentement peut changer à tout moment : on resynchronise juste après.
  document.addEventListener('ubepro:consent-changed', fillTrackingFields);

  /* ---- Libellé de question déduit du formulaire (comme sur AGV/AMR) ---- */
  const questionLabel = (name, fallback) => {
    const field = form.querySelector(`[name="${name}"]`);
    const label = field?.closest('label') || form.querySelector(`label[for="${field?.id}"]`);
    let text = '';
    if (label) {
      const node = [...label.childNodes].find((n) => n.nodeType === 3 && n.textContent.trim());
      if (node) text = node.textContent;
    }
    return safeText(text || fallback, 120).replace(/\s*\?$/, '');
  };

  /* ---- Formatage / validation à la saisie ---- */
  const setFieldAlert = (field, message) => {
    field.setCustomValidity(message || '');
  };

  phoneField?.addEventListener('input', () => {
    const value = normalizePhone(phoneField.value);
    const formatted = formatPhoneInput(value);
    if (phoneField.value !== formatted) phoneField.value = formatted;
    const digitsOnly = value.replace(/\D/g, '');
    if (digitsOnly.length > 15) {
      setFieldAlert(phoneField, 'Le téléphone semble trop long.');
    } else if (value.length > 0 && !validatePhone(value)) {
      setFieldAlert(phoneField, 'Saisissez un numéro valide (ex. 06 12 34 56 78 ou +32 470 12 34 56).');
    } else {
      setFieldAlert(phoneField, '');
    }
  });

  postalField?.addEventListener('input', () => {
    const value = String(postalField.value || '').replace(/\D/g, '');
    postalField.value = value.slice(0, 5);
    if (postalField.value.length > 0 && !validatePostal(postalField.value)) {
      setFieldAlert(postalField, 'Le code postal doit contenir exactement 5 chiffres.');
    } else {
      setFieldAlert(postalField, '');
    }
  });

  /* ---- Navigation multi-étapes ---- */
  let currentStep = 0;
  const showStep = (index) => {
    currentStep = index;
    steps.forEach((step, stepIndex) => {
      step.hidden = stepIndex !== index;
      step.classList.toggle('is-active', stepIndex === index);
    });
    if (progress) {
      progress.innerHTML = steps.map((_, i) => (i <= currentStep ? '<i></i>' : '<b></b>')).join('');
    }
    const firstField = steps[index]?.querySelector('select, input:not([type="hidden"]):not([tabindex="-1"])');
    firstField?.focus({ preventScroll: true });
  };

  /** Affiche le message natif du navigateur, sinon un message générique. */
  const reportInvalid = (invalidField) => {
    const nativeMessage = invalidField?.validationMessage || '';
    error.textContent = nativeMessage || 'Vérifiez les champs obligatoires avant de continuer.';
    error.hidden = false;
    invalidField?.reportValidity?.();
    invalidField?.focus();
  };

  const validateStep1 = () => {
    const required = [...steps[0].querySelectorAll('[required]')];
    const invalidField = required.find((field) => !field.checkValidity());
    if (invalidField) { reportInvalid(invalidField); return false; }
    error.hidden = true;
    return true;
  };

  const validateStep2 = () => {
    if (phoneField && !validatePhone(normalizePhone(phoneField.value))) {
      error.textContent = 'Le téléphone doit contenir un numéro valide.';
      error.hidden = false;
      phoneField.focus();
      return false;
    }
    const postalValue = String(postalField?.value || '').replace(/\s+/g, '');
    if (postalValue !== '' && !validatePostal(postalValue)) {
      error.textContent = 'Le code postal doit contenir exactement 5 chiffres.';
      error.hidden = false;
      postalField?.focus();
      return false;
    }
    const required = [...steps[1].querySelectorAll('[required]')];
    const invalidField = required.find((field) => !field.checkValidity());
    if (invalidField) { reportInvalid(invalidField); return false; }
    error.hidden = true;
    return true;
  };

  nextButton?.addEventListener('click', () => {
    if (validateStep1()) showStep(1);
  });
  backButton?.addEventListener('click', () => { error.hidden = true; showStep(0); });

  const showFormSuccess = () => {
    steps.forEach((step) => { step.hidden = true; });
    if (successBox) successBox.hidden = false;
    if (progress) progress.innerHTML = steps.map(() => '<i></i>').join('');
    successBox?.closest('.form-wrap')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  };

  /* ---------------------------------------------------------------- */
  /* Construction du payload                                          */
  /* ---------------------------------------------------------------- */

  const buildPayloads = () => {
    const tracking = fillTrackingFields();
    const formData = Object.fromEntries(new FormData(form));

    // Coordonnées : mêmes clés que la LP principale, donc mêmes colonnes du
    // CRM et de la feuille « Leads ». Les champs absents d'ici restent vides.
    const coordonnees = {
      nom: normalizePayloadValue(formData.nom),
      prenom: normalizePayloadValue(formData.prenom),
      mail: normalizePayloadValue(formData.mail || formData.email).toLowerCase(),
      telephone: normalizePayloadValue(formData.telephone),
      societe: normalizePayloadValue(formData.societe),
      code_postal: normalizePayloadValue(formData.code_postal),
      civilite: normalizePayloadValue(formData.civilite),
      ville: normalizePayloadValue(formData.ville)
    };

    // Questions déduites des libellés du formulaire, pas codées en dur :
    // modifier un libellé dans le HTML suffit à mettre à jour le CRM.
    const questionnaires = {
      question_1: questionLabel('site', 'Effectif de la société'),
      reponse_1: normalizePayloadValue(formData.site),
      question_2: questionLabel('solution', 'Formation envisagée'),
      reponse_2: normalizePayloadValue(formData.solution),
      question_3: questionLabel('enjeu', 'Besoin principal'),
      reponse_3: normalizePayloadValue(formData.enjeu)
    };

    // Feuille « Leads » : payload complet.
    const sheetData = {
      ...coordonnees,
      ...tracking,
      site: normalizePayloadValue(formData.site),
      solution: normalizePayloadValue(formData.solution),
      enjeu: normalizePayloadValue(formData.enjeu),
      ...questionnaires
    };

    // CRM : contrat minimal, puis enrichissement UNIQUEMENT consenti.
    const crmData = {
      ...coordonnees,
      domaine: domaine,
      source: tracking.source,
      categorie: tracking.categorie,
      user: tracking.user,
      gclid: tracking.gclid,
      msclkid: tracking.msclkid,
      site: normalizePayloadValue(formData.site),
      solution: normalizePayloadValue(formData.solution),
      enjeu: normalizePayloadValue(formData.enjeu),
      ...questionnaires
    };
    if (!CRM_STRICT_CONTRACT) {
      Object.assign(crmData, analyticsGranted() ? {
        utm_source: tracking.utm_source,
        utm_medium: tracking.utm_medium,
        utm_campaign: tracking.utm_campaign,
        utm_content: tracking.utm_content,
        utm_term: tracking.utm_term,
        utm_id: tracking.utm_id,
        utm_category: tracking.utm_category,
        utm_user: tracking.utm_user,
        ltm_source: tracking.ltm_source,
        ltm_category: tracking.ltm_category,
        ltm_typ: tracking.ltm_typ,
        ltm_user: tracking.ltm_user,
        page_url: safeText(trackingPageUrl, 1000),
        page_referrer: safeText(document.referrer, 1000),
        user_agent: safeText(navigator.userAgent, 300),
        langue: safeText(navigator.language || '', 20)
      } : {});
      if (marketingGranted()) {
        Object.assign(crmData, {
          gclid: tracking.gclid,
          msclkid: tracking.msclkid,
          fbclid: tracking.fbclid
        });
      }
    }

    return { formData, tracking, coordonnees, questionnaires, sheetData, crmData };
  };

  /* ---------------------------------------------------------------- */
  /* Envoi 1/2 — Google Sheets (Apps Script)                          */
  /* ---------------------------------------------------------------- */

  const buildSheetBody = (sheetData, leadId) => {
    const body = new URLSearchParams();
    Object.entries(sheetData).forEach(([key, value]) => body.set(key, value));
    body.set('form_id', FORM_ID);
    body.set('id_lead', leadId);
    // La colonne page_referrer reçoit le domaine statique, jamais le référent navigateur.
    body.set('page_referrer', domaine);
    // Autres données de navigation : uniquement si la mesure d'audience est acceptée.
    if (analyticsGranted()) {
      body.set('page_url', safeText(trackingPageUrl, 1000));
      body.set('user_agent', safeText(navigator.userAgent, 300));
      body.set('langue', safeText(navigator.language || '', 20));
    }
    return body;
  };

  const sendToSheet = async (body) => {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timeoutId = controller ? setTimeout(() => controller.abort(), SHEET_TIMEOUT_MS) : null;
    try {
      const response = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        mode: 'cors',
        cache: 'no-store',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
        body,
        keepalive: true,
        signal: controller ? controller.signal : undefined
      });
      // GAS répond HTTP 200 même en cas d'erreur métier : il FAUT lire le JSON.
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      let parsed = null;
      try { parsed = JSON.parse(text); } catch (err) { parsed = null; }
      if (!parsed || parsed.status !== 'ok') {
        throw new Error((parsed && parsed.message) || 'Réponse inattendue du script Google.');
      }
      return { target: 'sheet', state: 'ok', response: parsed };
    } catch (sendError) {
      console.error('[ubepro] Google Sheet en échec :', sendError);
      return { target: 'sheet', state: 'error', error: sendError };
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  };

  /* ---------------------------------------------------------------- */
  /* Envoi 2/2 — CRM Hellolead                                        */
  /* ---------------------------------------------------------------- */

  const sendToCrm = async (crmData, leadId) => {
    if (LEAD_API_MODE === 'off' || !LEAD_API_URL) return { target: 'crm', state: 'off' };

    const body = JSON.stringify({ payload: { formId: FORM_ID, id: leadId, data: crmData } });

    /* Mode cors : réponse lisible, donc succès vérifiable et erreurs remontées. */
    if (LEAD_API_MODE === 'cors') {
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const timeoutId = controller ? setTimeout(() => controller.abort(), CRM_TIMEOUT_MS) : null;
      try {
        const response = await fetch(LEAD_API_URL, {
          method: 'POST',
          mode: 'cors',
          headers: { 'Content-Type': 'application/json; charset=UTF-8' },
          body,
          credentials: LEAD_API_CREDENTIALS,
          signal: controller ? controller.signal : undefined
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        let parsed = null;
        try { parsed = JSON.parse(await response.text()); } catch (err) { parsed = null; }
        if (!parsed || parsed.status !== 'ok') {
          throw new Error((parsed && parsed.message) || 'Réponse inattendue du CRM.');
        }
        return { target: 'crm', state: 'ok', response: parsed };
      } catch (crmError) {
        console.error('[ubepro] CRM en échec (mode cors) :', crmError);
        return { target: 'crm', state: 'error', error: crmError };
      } finally {
        if (timeoutId) clearTimeout(timeoutId);
      }
    }

    /* Mode nocors : sendBeacon d'abord (le plus fiable en sortie de page),
       repli sur fetch no-cors. Réponse illisible -> succès non vérifiable. */
    try {
      if (typeof navigator.sendBeacon === 'function'
          && navigator.sendBeacon(LEAD_API_URL, new Blob([body], { type: 'text/plain;charset=UTF-8' }))) {
        return { target: 'crm', state: 'unverified', via: 'beacon' };
      }
    } catch (beaconError) {
      console.warn('[ubepro] sendBeacon CRM échoué, repli fetch :', beaconError);
    }

    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timeoutId = controller ? setTimeout(() => controller.abort(), CRM_TIMEOUT_MS) : null;
    try {
      await fetch(LEAD_API_URL, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body,
        keepalive: true,
        credentials: LEAD_API_CREDENTIALS,
        signal: controller ? controller.signal : undefined
      });
      return { target: 'crm', state: 'unverified', via: 'fetch' };
    } catch (crmError) {
      console.error('[ubepro] CRM : fetch no-cors en échec :', crmError);
      return { target: 'crm', state: 'error', error: crmError };
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  };

  /* ---------------------------------------------------------------- */
  /* API de diagnostic                                                */
  /* ---------------------------------------------------------------- */

  window.ubeproLead = {
    version: TRACKING_VERSION,
    config: {
      googleScriptUrl: GOOGLE_SCRIPT_URL,
      leadApiUrl: LEAD_API_URL,
      leadApiMode: LEAD_API_MODE,
      formId: FORM_ID,
      crmStrictContract: CRM_STRICT_CONTRACT
    },
    preview: () => {
      const { crmData, sheetData } = buildPayloads();
      return {
        crm: { payload: { formId: FORM_ID, id: '(généré à la soumission)', data: crmData } },
        sheet: Object.fromEntries(buildSheetBody(sheetData, '(généré à la soumission)').entries())
      };
    },
    lastResults: null,
    last: () => window.ubeproLead.lastResults,
    tracking: getTrackingValues
  };

  /* ---------------------------------------------------------------- */
  /* Soumission                                                       */
  /* ---------------------------------------------------------------- */

  let isSubmitting = false;

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (isSubmitting) return;

    if (currentStep === 0) {
      if (validateStep1()) showStep(1);
      return;
    }
    if (!validateStep2()) return;

    // Honeypot anti-spam : champ invisible rempli = robot.
    if (honeypotField && honeypotField.value.trim() !== '') {
      debugLog('Honeypot rempli, envoi ignoré.');
      showFormSuccess();
      return;
    }

    isSubmitting = true;
    error.hidden = true;
    const submitButton = form.querySelector('button[type="submit"]');
    const originalLabel = submitButton ? submitButton.innerHTML : '';
    let busyLabel = '';
    if (submitButton) {
      busyLabel = submitButton.textContent;
      submitButton.disabled = true;
      submitButton.setAttribute('aria-busy', 'true');
      submitButton.textContent = 'Envoi en cours…';
    }

    try {
      const { sheetData, crmData } = buildPayloads();
      const leadId = generateId();
      const sheetBody = buildSheetBody(sheetData, leadId);

      debugLog('Google Sheet payload :', Object.fromEntries(sheetBody.entries()));
      debugLog('CRM payload :', { payload: { formId: FORM_ID, id: leadId, data: crmData } });

      const results = [];
      let confirmed = false;
      const record = (result) => {
        results.push(result);
        window.ubeproLead.lastResults = [...results];
        debugLog('Résultat :', result);
        if (!confirmed && (result.state === 'ok' || result.state === 'unverified')) {
          confirmed = true;
          showFormSuccess();
        }
      };

      const slowNotice = setTimeout(() => {
        if (!confirmed && submitButton) submitButton.textContent = 'Enregistrement en cours…';
      }, SLOW_NOTICE_MS);

      const both = Promise.all([
        sendToSheet(sheetBody).then(record),
        sendToCrm(crmData, leadId).then(record)
      ]).then(() => true);

      // Affichage plus rapide : on n'attend pas la seconde destination si la
      // première a déjà confirmé, sans interrompre l'envoi en cours.
      const settled = await Promise.race([
        both,
        new Promise((resolve) => setTimeout(() => resolve(false), SLOW_NOTICE_MS))
      ]);
      const allDone = settled || await both;
      clearTimeout(slowNotice);

      if (!confirmed) {
        const sheetFailed = results.some((r) => r.target === 'sheet' && r.state === 'error');
        const crmFailed = results.some((r) => r.target === 'crm' && r.state === 'error');
        console.warn('[ubepro] Aucune destination confirmée — Sheet en échec :', sheetFailed, '| CRM en échec :', crmFailed);
        error.textContent = MESSAGE_SEND_FAILED;
        error.hidden = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.removeAttribute('aria-busy');
          submitButton.innerHTML = originalLabel;
        }
        return;
      }

      /* ---- Conversion formulaire vers GTM après enregistrement confirmé ---- */
      try {
        window.dataLayer = window.dataLayer || [];
        // Événement demandé : envoyé à chaque lead confirmé, quel que soit le consentement.
        window.dataLayer.push({ event: 'formulaire_lead' });

        // Les autres événements analytiques restent soumis au consentement.
        if (trackingGranted()) {
          window.dataLayer.push({
            event: 'generate_lead',
            form_id: FORM_ID,
            site_type: sheetData.site,
            solution: sheetData.solution,
            enjeu: sheetData.enjeu
          });
          if (typeof window.gtag === 'function') {
            window.gtag('event', 'generate_lead', { form_id: FORM_ID });
          }
        }
      } catch (analyticsError) { /* le tracking ne doit jamais casser le succès */ }

      if (submitButton) {
        submitButton.disabled = false;
        submitButton.removeAttribute('aria-busy');
        submitButton.innerHTML = originalLabel;
      }
      void busyLabel; void allDone;

    } catch (submitError) {
      console.error('[ubepro] Échec de l\u2019envoi du lead :', submitError);
      error.textContent = MESSAGE_SEND_FAILED;
      error.hidden = false;
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.removeAttribute('aria-busy');
        submitButton.innerHTML = originalLabel;
      }
    } finally {
      isSubmitting = false;
    }
  });
});
