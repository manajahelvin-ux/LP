# Véhicule professionnel — landing page

Landing page statique en HTML/CSS/JavaScript natifs pour recueillir des demandes de devis professionnels. Aucun framework ni build n’est nécessaire pour servir le site. Les fichiers WebP responsives sont servis en priorité ; les JPEG restent des solutions de repli.

## Fichiers

| Fichier | Rôle |
|---|---|
| `index.html` | Page, formulaire progressif, métadonnées SEO et données structurées Service/FAQ |
| `style.css` | Styles responsive, palette et états d’accessibilité |
| `script.js` | Parcours du formulaire, tracking et envoi vers les destinations configurées |
| `img/` | Images locales, icônes SVG, JPEG de repli et variantes WebP responsives |
| `tools/build_responsive_images.py` | Génération des variantes WebP à partir des JPEG |
| `tools/requirements.txt` | Dépendance optionnelle du script d’images (Pillow) |

## Hébergement

1. Héberger **tout le contenu de ce dossier** (`index.html`, `style.css`, `script.js` et `img/`) sur un hébergement HTTPS.
2. Vérifier que les fichiers `.webp` et `.jpg` sont servis avec les bons types MIME (`image/webp` et `image/jpeg`). Les navigateurs qui acceptent WebP utilisent les variantes responsives ; les autres retombent sur le JPEG.
3. Configurer et tester les destinations backend. L’URL CRM actuellement inscrite contient `helloleadpreprod.fr` ; l’endpoint Google Apps Script n’a pas été vérifié de bout en bout. **Ne pas utiliser la configuration actuelle pour de vrais leads avant validation des endpoints de production.**
4. Renseigner les vraies coordonnées et URL des pages légales/confidentialité dans `BRAND_CONFIG`.

## Images responsives

Les sept photos ajoutées aux cartes de catégories sont générées par IA avec un rendu photoréaliste. Elles sont volontairement distinctes des miniatures du formulaire et n’affichent ni logo de constructeur ni texte. Elles illustrent des catégories génériques : ne pas les présenter comme la photo d’un véhicule précis réellement disponible.

Pour régénérer les tailles WebP après remplacement d’un JPEG :

```bash
python3 -m pip install -r tools/requirements.txt
python3 tools/build_responsive_images.py
```

Le script conserve les JPEG et crée des variantes de 480, 960 et 1400 px. Les nouvelles images du dossier `img/` doivent aussi être ajoutées à `index.html` avec un `alt`, `width`/`height`, un `loading` approprié et un `srcset` cohérent.

## SEO et GEO

- Le titre, la description, les cartes sociales, le résumé direct du service et les données structurées `Service`/`FAQPage` sont en place.
- Garder les questions/réponses JSON-LD strictement alignées sur le contenu visible de la FAQ.
- Ajouter **après confirmation du domaine** une URL canonique, `og:url`, une image Open Graph absolue et les données `Organization` correspondant à l’entreprise réelle. Ces éléments ne sont volontairement pas inventés dans cette version.
- Les pages locales doivent correspondre à de vraies zones desservies et contenir une information utile et vérifiable ; ne pas créer de pages artificielles par ville.
- Vérifier les chiffres, témoignages, délai annoncé et affirmations fiscales avant publication. Les données structurées ne remplacent pas des preuves vérifiables.

## Configuration de marque

La configuration `BRAND_CONFIG` de `script.js` remplace certains textes, liens et couleurs. Fournir au minimum le nom légal/commercial exact, l’adresse e-mail, les URL de mentions légales et confidentialité et une palette validée pour le contraste. Ne pas injecter de secrets dans le JavaScript public.

## Formulaire et intégrations — points de production

- Le formulaire recueille des données personnelles et les transmet à des services tiers. Publier une notice de confidentialité réelle et limiter les données envoyées.
- La réponse d’un appel `no-cors` vers le CRM reste opaque : le navigateur ne peut pas confirmer son code HTTP ou son acceptation métier. Le front-end ne traite donc plus cet état comme une preuve de livraison. Utiliser un endpoint serveur vérifiable et une procédure de reprise pour la mise en production.
- L’Apps Script peut être publiquement appelable selon son déploiement. Validation serveur, limitation de débit, déduplication et protection contre les soumissions abusives doivent être vérifiées côté serveur ; le honeypot du navigateur ne suffit pas.
- Le fichier Apps Script `code.gs` et le code du CRM doivent être conservés/documentés séparément : ils ne sont pas inclus dans ce dossier.

## Vérifications rapides

- Syntaxe JavaScript : `node --check script.js`
- Les formulaires, liens légaux, couleurs, URLs, réponses côté CRM/Sheet et la version mobile doivent être testés en staging avant déploiement.
