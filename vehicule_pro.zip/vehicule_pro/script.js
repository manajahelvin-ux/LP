/* ============================================================
   UBEPRO — Landing page Véhicule professionnel
   Fusion de la LP véhicule (script.js) et de la mécanique
   d'envoi Google Sheets / CRM Hellopro / tracking URL.

   VERSION 2026-09-24.2 — CORRECTIF ENVOI CRM
   ------------------------------------------------------------
   CE QUI A CHANGÉ (et pourquoi) :

   1. ENVOI CRM (le bug bloquant)
      Avant : fetch(LEAD_API_URL, { Content-Type: application/json })
              => requête NON simple => pré-vol OPTIONS => le PHP ne
                 renvoie aucun en-tête CORS => le navigateur bloque et
                 n'envoie JAMAIS le POST => "L'envoi a échoué".
      Maintenant : POST en mode "no-cors" avec Content-Type text/plain
              (requête simple, donc ZÉRO pré-vol) et corps = le même
              JSON. Le PHP lit php://input + json_decode : il reçoit
              exactement le payload attendu, sans pré-vol.
              -> Le PHP n'a PAS besoin d'être modifié.
              -> Contrepartie : la réponse est "opaque", on ne peut pas
                 la lire (donc pas de vérification depuis le navigateur).
      Un repli navigator.sendBeacon() est tenté si le fetch échoue.

   2. Deux payloads distincts au lieu d'un objet ambigu
      - sheetData : IDENTIQUE à avant (Google Sheet ne change pas).
      - crmData   : contrat strict attendu par get_information.php.

   3. Collision corrigée : la clé "categorie" servait à la fois à la
      réponse du formulaire ET au paramètre de tracking (utm_category /
      ltm_category). Le spread "...tracking" écrasait la catégorie du
      formulaire. C'est désormais explicite : "categorie" = valeur de
      tracking (celle que lit le PHP pour categorie_fj + SMS PEC),
      la réponse du formulaire reste dans reponse_1 / site.

   4. Champs cachés de tracking supprimés : le JS injectait un
      <input hidden name="categorie"> qui, via form.querySelector,
      tombait en fait sur le RADIO "Citadine" et écrasait son value
      (cliquer Citadine envoyait alors "160" comme réponse).

   5. Libellés de questions lus dans le <legend> réellement affiché :
      question_2 valait toujours "Combien de véhicules" alors que la
      branche Utilitaire affiche "Quelle taille d'utilitaire ?".

   6. Robustesse : aucune destination ne fait plus échouer l'écran de
      succès (un seul canal suffit), timeout + anti-double-envoi,
      GAS toujours vérifié via sa réponse JSON.

   Diagnostic : window.ubeproLead                        (config + état)
                window.ubeproLead.preview()              (payloads)
                window.ubeproLead.last()                 (dernier envoi)
   ============================================================ */

/* === 1. CONFIG MARQUE BLANCHE ================================= */
const BRAND_CONFIG = Object.assign({
  name: 'Véhicule professionnel',
  logoUrl: '',
  primary: '#0f3d5c',
  primaryDark: '#0a2b42',
  primaryTint: '#e6eef4',
  accent: '#f2a413',
  accentDark: '#805400',
  accentTint: '#fff4dc',
  email: 'contact@exemple.fr',
  legalUrl: '#',
  privacyUrl: '#',
  legalLine: 'le service qui met les professionnels en relation avec les concessionnaires de leur secteur.',
  endpoint: '',                 // Optionnel : 2e destination CRM (même payload JSON que le CRM)
  showSampleTestimonials: true
}, window.BRAND_CONFIG || {});

(function applyBrand() {
  const root = document.documentElement.style;
  root.setProperty('--primary', BRAND_CONFIG.primary);
  root.setProperty('--primary-dark', BRAND_CONFIG.primaryDark);
  root.setProperty('--primary-tint', BRAND_CONFIG.primaryTint);
  root.setProperty('--accent', BRAND_CONFIG.accent);
  root.setProperty('--accent-dark', BRAND_CONFIG.accentDark);
  root.setProperty('--accent-tint', BRAND_CONFIG.accentTint);
  if (!BRAND_CONFIG.showSampleTestimonials) document.querySelectorAll('[data-sample], .testi__note').forEach(el => el.remove());

  document.querySelectorAll('[data-brand-name]').forEach(el => { el.textContent = BRAND_CONFIG.name; });
  document.querySelectorAll('[data-brand-email]').forEach(el => { el.textContent = BRAND_CONFIG.email; el.href = 'mailto:' + BRAND_CONFIG.email; });
  document.querySelectorAll('[data-brand-legal]').forEach(el => { el.href = BRAND_CONFIG.legalUrl; });
  document.querySelectorAll('[data-brand-privacy]').forEach(el => { el.href = BRAND_CONFIG.privacyUrl; });
  document.querySelectorAll('[data-brand-legal-line]').forEach(el => { el.textContent = BRAND_CONFIG.legalLine; });

  const logo = document.querySelector('[data-brand-logo]');
  if (logo && BRAND_CONFIG.logoUrl) {
    const img = document.createElement('img');
    img.src = BRAND_CONFIG.logoUrl; img.alt = BRAND_CONFIG.name; img.height = 34;
    logo.appendChild(img);
  }
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();

/* === 2. CONFIG ENVOI (surchargeable sans toucher au fichier) ===
   Dans index.html, AVANT script.js :
   <script>
     window.UBEPRO_CONFIG = {
       leadApiUrl: 'http://localhost:8801/api/webflow/get_information.php',
       leadApiMode: 'cors',   // test local avec mock_crm.py
       debug: true
     };
   </script>
   -------------------------------------------------------------- */
const APP_CONFIG = Object.assign({
  googleScriptUrl: 'https://script.google.com/macros/s/AKfycbwrbyCb9-cAmIRPGNvnb-aM-CkhQAerrkfP3_HSw-ewmThxsn4vbZt5daaq2aOnL01a1w/exec',
  leadApiUrl: 'https://mc.helloleadpreprod.fr/mon_compte/api/webflow/get_information.php',
  /* 'nocors' : POST simple + text/plain, aucun pré-vol — fonctionne
                avec le PHP actuel, réponse non lisible (défaut).
     'cors'   : POST JSON vérifiable — NÉCESSITE que le PHP renvoie
                Access-Control-Allow-Origin + gère OPTIONS.
     'off'    : désactive l'envoi CRM (diagnostic). */
  leadApiMode: 'nocors',
  /* 'omit' par défaut : pas de cookie envoyé (endpoint public de LP).
     'include' : à utiliser si get_information.php exige une session
                 existante (same-site) — autorisé même en no-cors. */
  leadApiCredentials: 'omit',
  formId: 'ADW_LP_VEHICULE_PRO',
  debug: false
}, window.UBEPRO_CONFIG || {});

const GOOGLE_SCRIPT_URL = APP_CONFIG.googleScriptUrl;
const LEAD_API_URL = APP_CONFIG.leadApiUrl;
const LEAD_API_MODE = APP_CONFIG.leadApiMode;
const LEAD_API_CREDENTIALS = APP_CONFIG.leadApiCredentials === 'include' ? 'include' : 'omit';
const DEFAULT_FORM_ID = APP_CONFIG.formId;
const DEBUG = APP_CONFIG.debug;

const TRACKING_STORAGE_KEY = 'ubepro_tracking_v1';
const TRACKING_PAGE_STORAGE_KEY = 'ubepro_tracking_page_url_v1';
const TRACKING_VERSION = '2026-09-24.2';
const REQUEST_TIMEOUT_MS = 6000;        // Google Apps Script : max 6s (froid ~2-5s)
const CRM_TIMEOUT_MS = 5000;            // CRM no-cors : max 5s
const BRAND_TIMEOUT_MS = 4000;          // Endpoint marque : max 4s
const FAST_SUCCESS_DEADLINE_MS = 2500;  // Délai max avant succès visuel même sans confirmation

const TRACKING_KEYS = [
  { key: 'source', aliases: ['source', 'utm_source', 'ltm_source'] },
  { key: 'categorie', aliases: ['categorie', 'utm_category', 'ltm_category', 'category'] },
  { key: 'user', aliases: ['user', 'utm_user', 'ltm_user'] },
  { key: 'utm_source', aliases: ['utm_source', 'ltm_source', 'source'] },
  { key: 'utm_medium', aliases: ['utm_medium', 'medium'] },
  { key: 'utm_campaign', aliases: ['utm_campaign', 'campaign'] },
  { key: 'utm_content', aliases: ['utm_content', 'content'] },
  { key: 'utm_term', aliases: ['utm_term', 'term'] },
  { key: 'utm_id', aliases: ['utm_id', 'campaign_id'] },
  { key: 'utm_category', aliases: ['utm_category', 'ltm_category', 'categorie', 'category'] },
  { key: 'utm_user', aliases: ['utm_user', 'ltm_user', 'user'] },
  { key: 'ltm_source', aliases: ['ltm_source', 'utm_source', 'source'] },
  { key: 'ltm_category', aliases: ['ltm_category', 'utm_category', 'categorie', 'category'] },
  { key: 'ltm_typ', aliases: ['ltm_typ', 'utm_typ', 'typ'] },
  { key: 'ltm_user', aliases: ['ltm_user', 'utm_user', 'user'] },
  { key: 'gclid', aliases: ['gclid'] },
  { key: 'msclkid', aliases: ['msclkid'] },
  { key: 'fbclid', aliases: ['fbclid'] }
];

/* --- Utilitaires de normalisation --- */
const safeText = (value, maxLength = 500) => {
  const text = String(value ?? '').replace(/\s+/g, ' ').trim();
  return text.slice(0, maxLength);
};

const normalizePayloadValue = (value) => {
  const sanitized = safeText(value, 500);
  return sanitized.replace(/[<>]/g, '');
};

const debugLog = (...args) => { if (DEBUG) console.log('[ubepro]', ...args); };

/** UUID v4 avec repli si crypto.randomUUID est indisponible (contexte non-HTTPS). */
const generateId = () => {
  try {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
  } catch (err) { /* contexte non sécurisé */ }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const value = char === 'x' ? random : (random & 0x3) | 0x8;
    return value.toString(16);
  });
};

/* --- Capture anticipée de l'URL (avant tout deferred) --- */
const ENTRY_PAGE_URL = typeof window.__UBEPRO_ENTRY_URL__ === 'string'
  ? window.__UBEPRO_ENTRY_URL__
  : window.location.href;

const parseParamsFromString = (searchString) => {
  const params = Object.create(null);
  new URLSearchParams(searchString || '').forEach((value, key) => {
    const cleanKey = String(key).trim().toLowerCase();
    const cleanValue = normalizePayloadValue(value);
    if (cleanKey && cleanValue) params[cleanKey] = cleanValue;
  });
  return params;
};

/** Query classique, #/page?source=... et #source=... ; la query est prioritaire. */
const getUrlParams = (href = window.location.href) => {
  try {
    const url = new URL(href, window.location.href);
    const hash = url.hash.slice(1);
    const queryIndex = hash.indexOf('?');
    const hashQuery = queryIndex !== -1
      ? hash.slice(queryIndex + 1)
      : (hash.includes('=') && !hash.startsWith('/') ? hash : '');
    return {
      ...parseParamsFromString(hashQuery),
      ...parseParamsFromString(url.search)
    };
  } catch (err) {
    return {};
  }
};

/** Ne relire que les clés connues, jamais un objet de stockage arbitraire. */
const readStoredParams = () => {
  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(TRACKING_STORAGE_KEY) || '{}');
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    const stored = {};
    TRACKING_KEYS.forEach(({ key }) => {
      if (Object.prototype.hasOwnProperty.call(parsed, key) && typeof parsed[key] === 'string') {
        const value = normalizePayloadValue(parsed[key]);
        if (value) stored[key] = value;
      }
    });
    return stored;
  } catch (err) {
    return {};
  }
};

let trackingMemory = readStoredParams();
let trackingPageUrl = ENTRY_PAGE_URL;
try {
  const storedUrl = window.sessionStorage.getItem(TRACKING_PAGE_STORAGE_KEY);
  if (storedUrl && Object.keys(trackingMemory).length > 0) trackingPageUrl = storedUrl;
} catch (err) { /* Mémoire seule, pour cette page. */ }

const storeParams = (params) => {
  trackingMemory = { ...trackingMemory, ...params };
  try {
    window.sessionStorage.setItem(TRACKING_STORAGE_KEY, JSON.stringify(trackingMemory));
  } catch (err) { /* Les valeurs restent disponibles en mémoire. */ }
  return { ...trackingMemory };
};

/** Dernière valeur non vide de chaque clé gagne ; visite directe peut rester vide. */
const captureTrackingParams = (href = window.location.href) => {
  const urlParams = getUrlParams(href);
  const relevant = {};
  TRACKING_KEYS.forEach(({ key, aliases }) => {
    const foundAlias = aliases.find((alias) => urlParams[alias]);
    if (foundAlias) relevant[key] = urlParams[foundAlias];
  });
  if (Object.keys(relevant).length > 0) {
    storeParams(relevant);
    trackingPageUrl = safeText(href, 1000);
    try {
      window.sessionStorage.setItem(TRACKING_PAGE_STORAGE_KEY, trackingPageUrl);
    } catch (err) { /* L'URL de capture reste en mémoire. */ }
  }
  return { ...trackingMemory };
};

/** URL courante > valeurs capturées/mémorisées ; aucune dépendance au DOM. */
const getTrackingValues = () => {
  captureTrackingParams();
  return Object.fromEntries(TRACKING_KEYS.map(({ key }) => [
    key, normalizePayloadValue(trackingMemory[key])
  ]));
};

// Ne pas attendre DOMContentLoaded pour conserver les paramètres d'entrée.
captureTrackingParams(ENTRY_PAGE_URL);
captureTrackingParams();

/* === 3. TÉLÉPHONE / VALIDATION =============================== */
const normalizePhone = (value) => {
  let text = String(value || '').replace(/[^\d+]/g, '');
  if (/^\+?00/.test(text)) text = `+${text.replace(/^\+?00/, '')}`;
  if (text.startsWith('+33')) text = `0${text.slice(3)}`;
  if (text.startsWith('33') && text.length === 11) text = `0${text.slice(2)}`;
  return text;
};

const validatePhone = (value) => {
  const normalized = normalizePhone(value);
  if (/^0[1-9]\d{8}$/.test(normalized)) return true;
  return /^\+[1-9]\d{7,14}$/.test(normalized);
};

const formatPhoneInput = (value) => {
  return /^0\d+$/.test(value) ? value.replace(/(\d{2})(?=\d)/g, '$1 ').trim() : value;
};

/* === 4. ENVOI : GOOGLE SHEET (vérifié) + CRM HELLOPRO (opaque) === */

/** Réponse GAS : HTTP 200 même en erreur métier -> il FAUT lire le JSON. */
async function sendToGoogleSheet(googleFormData) {
  const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS) : null;
  try {
    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: 'POST',
      mode: 'cors',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: googleFormData,
      keepalive: true,
      signal: controller ? controller.signal : undefined
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const text = await response.text();
    let parsed = null;
    try { parsed = JSON.parse(text); } catch (err) { parsed = null; }
    if (!parsed || parsed.status !== 'ok') {
      throw new Error((parsed && parsed.message) || 'Réponse inattendue du script Google.');
    }
    return { target: 'sheet', state: 'ok', response: parsed };
  } catch (err) {
    console.error('[ubepro] Google Sheet en échec :', err);
    return { target: 'sheet', state: 'error', error: err };
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

/**
 * Envoi vers get_information.php.
 * Le PHP lit le corps brut (file_get_contents('php://input') + json_decode),
 * il se moque donc du Content-Type : envoyer le JSON en text/plain permet
 * une requête "simple" (POST + Content-Type safelisté) => AUCUN pré-vol
 * OPTIONS => plus de blocage CORS, sans modifier le PHP.
 */
async function sendToCrm(crmPayload, formId, leadId) {
  if (LEAD_API_MODE === 'off' || !LEAD_API_URL) {
    return { target: 'crm', state: 'off' };
  }

  const body = JSON.stringify({ payload: { formId, id: leadId, data: crmPayload } });

  /* Mode vérifiable : exige les en-têtes CORS côté PHP. */
  if (LEAD_API_MODE === 'cors') {
    const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    const timeoutId = controller ? setTimeout(() => controller.abort(), CRM_TIMEOUT_MS) : null;
    try {
      const response = await fetch(LEAD_API_URL, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body,
        signal: controller ? controller.signal : undefined
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      let parsed = null;
      try { parsed = JSON.parse(text); } catch (err) { parsed = null; }
      if (!parsed || parsed.status !== 'ok') {
        throw new Error((parsed && parsed.message) || 'Réponse inattendue du CRM.');
      }
      return { target: 'crm', state: 'ok', response: parsed };
    } catch (err) {
      console.error('[ubepro] CRM en échec (mode cors) :', err);
      return { target: 'crm', state: 'error', error: err };
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }

  /* Mode par défaut : sendBeacon d'abord (non bloquant, instantané).
     sendBeacon met la requête en file d'attente du navigateur qui
     l'envoie en arrière-plan MÊME si l'utilisateur change de page.
     La promesse se résout immédiatement — on n'attend pas le serveur. */
  try {
    if (typeof navigator.sendBeacon === 'function') {
      const queued = navigator.sendBeacon(
        LEAD_API_URL,
        new Blob([body], { type: 'text/plain;charset=UTF-8' })
      );
      if (queued) {
        return { target: 'crm', state: 'unverified', via: 'beacon' };
      }
    }
  } catch (beaconErr) {
    console.warn('[ubepro] sendBeacon CRM échoué, repli fetch :', beaconErr);
  }

  /* Repli : fetch no-cors avec timeout court. */
  const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), CRM_TIMEOUT_MS) : null;
  try {
    await fetch(LEAD_API_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body,
      keepalive: true,
      credentials: LEAD_API_CREDENTIALS,
      signal: controller ? controller.signal : undefined
    });
    return { target: 'crm', state: 'unverified', via: 'fetch' };
  } catch (err) {
    console.error('[ubepro] CRM : fetch no-cors en échec :', err);
    return { target: 'crm', state: 'error', error: err };
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

/* === 5. FORMULAIRE PROGRESSIF + CONSTRUCTION DES PAYLOADS ===== */
(function progressiveForm() {
  const form = document.getElementById('devisForm');
  if (!form) return;

  const steps = Array.from(form.querySelectorAll('.qstep'));
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const submitBtn = document.getElementById('submitBtn');
  const stepLabel = document.getElementById('stepLabel');
  const stepperItems = Array.from(document.querySelectorAll('#stepper li'));
  const status = document.getElementById('formStatus');
  const successMessageEl = document.getElementById('successMessage');
  const successHeading = form.querySelector('.qstep--success h3');
  const formulaireEl = document.getElementById('formulaire');
  const TOTAL = 4;
  let current = 1;
  let isSubmitting = false;
  let autoAdvanceTimer = null;

  /* --- Honeypot anti-spam (injecté à la volée, HTML non modifié) --- */
  let honeypot = form.querySelector('input[name="website"]');
  if (!honeypot) {
    honeypot = document.createElement('input');
    honeypot.type = 'text';
    honeypot.name = 'website';
    honeypot.tabIndex = -1;
    honeypot.autocomplete = 'off';
    honeypot.setAttribute('aria-hidden', 'true');
    honeypot.setAttribute('aria-label', 'Ne pas remplir');
    honeypot.style.position = 'absolute';
    honeypot.style.left = '-9999px';
    honeypot.style.width = '1px';
    honeypot.style.height = '1px';
    honeypot.style.opacity = '0';
    honeypot.style.pointerEvents = 'none';
    form.appendChild(honeypot);
  }

  /* NOTE : plus aucun <input hidden name="categorie"> injecté dans le form.
     L'ancien code en créait un, mais form.querySelector('[name="categorie"]')
     tombait sur le radio "Citadine" et écrasait son value avec le paramètre
     de tracking (ltm_category). Les valeurs de tracking viennent désormais
     uniquement de getTrackingValues(), jamais du DOM. */

  /* --- Navigation multi-étapes (branches) --- */
  const branch = () => (form.querySelector('input[name="categorie"]:checked') || {}).value || '';
  const branchSteps = steps.filter(s => s.dataset.branch && s.dataset.branch !== '*').map(s => s.dataset.branch);

  function clearAutoAdvance() {
    if (autoAdvanceTimer !== null) {
      clearTimeout(autoAdvanceTimer);
      autoAdvanceTimer = null;
    }
  }

  function resetBranchAnswers() {
    form.querySelectorAll('input[name="precision_vu"], input[name="quantite"]').forEach(input => {
      input.checked = false;
    });
    const precisionAutre = form.querySelector('input[name="precision_autre"]');
    if (precisionAutre) precisionAutre.value = '';
    steps.filter(step => Number(step.dataset.step) === 2).forEach(step => {
      step.querySelectorAll('.field-error').forEach(error => { error.hidden = true; });
      step.querySelectorAll('[aria-invalid]').forEach(input => input.removeAttribute('aria-invalid'));
    });
  }

  function activeStepEl(n) {
    const b = branch();
    return steps.find(s => Number(s.dataset.step) === n && (
      !s.dataset.branch ||
      s.dataset.branch === b ||
      (s.dataset.branch === '*' && !branchSteps.includes(b))
    ));
  }

  /** Libellé réel de la question, lu dans le <legend> affiché. */
  function questionLabel(n) {
    const el = activeStepEl(n);
    const legend = el ? el.querySelector('legend') : null;
    return safeText((legend ? legend.textContent : '') || '', 200).replace(/\s*\?$/, '');
  }

  function render() {
    steps.forEach(s => s.classList.remove('is-active'));
    const el = activeStepEl(current);
    if (el) { el.hidden = false; el.classList.add('is-active'); }
    const done = current > TOTAL;
    prevBtn.hidden = current === 1 || done;
    nextBtn.hidden = current >= TOTAL || done;
    submitBtn.hidden = current !== TOTAL;
    form.querySelector('.qform__nav').hidden = done;
    form.querySelector('.qform__reassure').hidden = done;
    const shown = Math.min(current, TOTAL);
    stepLabel.textContent = done ? 'Terminé' : `Étape ${shown} sur ${TOTAL}`;
    stepperItems.forEach((li, i) => {
      li.classList.toggle('is-done', done || i + 1 < current);
      li.classList.toggle('is-current', !done && i + 1 === current);
    });
    form.querySelector('.stepper').hidden = done;
    if (!done && el) {
      const first = el.querySelector('input');
      if (first && current > 1) first.focus({ preventScroll: true });
    }
  }

  function showError(container, show) {
    const err = container.querySelector(':scope > .field-error');
    if (err) err.hidden = !show;
  }

  function validateStep(n) {
    const el = activeStepEl(n);
    if (!el) return true;
    let ok = true;

    const radios = el.querySelectorAll('input[type="radio"]');
    if (radios.length) {
      ok = Array.from(radios).some(r => r.checked);
      showError(el, !ok);
      return ok;
    }

    el.querySelectorAll('.field').forEach(field => {
      const input = field.querySelector('input');
      let valid = true;
      const v = (input.value || '').trim();
      if (input.type === 'checkbox') valid = input.checked;
      else if (input.type === 'email') valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
      else if (input.type === 'tel') valid = validatePhone(normalizePhone(v)) || /^(\+33|0)\s?[1-9](?:[\s.-]?\d{2}){4}$/.test(v);
      else if (input.name === 'code_postal') valid = /^\d{5}$/.test(v);
      else valid = v.length >= 2;
      input.setAttribute('aria-invalid', String(!valid));
      const err = field.querySelector('.field-error');
      if (err) err.hidden = valid;
      if (!valid && ok) { ok = false; input.focus({ preventScroll: true }); }
    });
    return ok;
  }

  /* --- Auto-avance sur les étapes radio (1 clic = 1 étape) --- */
  form.addEventListener('change', e => {
    if (e.target.type === 'radio') {
      const el = e.target.closest('.qstep');
      if (!el) return;
      showError(el, false);
      // Une nouvelle catégorie invalide les réponses de l'ancienne branche.
      if (e.target.name === 'categorie') resetBranchAnswers();

      clearAutoAdvance();
      const selectedStep = Number(el.dataset.step);
      if (selectedStep < TOTAL) {
        autoAdvanceTimer = setTimeout(() => {
          autoAdvanceTimer = null;
          // Avancer d'une étape au plus, même si plusieurs changements arrivent vite.
          if (current <= selectedStep) {
            current = selectedStep + 1;
            render();
          }
        }, 180);
      }
    }
    if (e.target.type !== 'radio') {
      const field = e.target.closest('.field');
      if (field && e.target.getAttribute('aria-invalid') === 'true') validateStep(TOTAL);
    }
  });

  nextBtn.addEventListener('click', () => {
    clearAutoAdvance();
    if (validateStep(current)) { current += 1; render(); }
  });
  prevBtn.addEventListener('click', () => {
    clearAutoAdvance();
    current = Math.max(1, current - 1);
    render();
  });

  // Formatage téléphone à la saisie (FR uniquement)
  const telField = form.querySelector('input[name="tel"]');
  telField?.addEventListener('input', () => {
    const value = normalizePhone(telField.value);
    const formatted = formatPhoneInput(value);
    if (telField.value !== formatted) telField.value = formatted;
  });

  // Code postal : chiffres uniquement, 5 caractères max
  const cpField = form.querySelector('input[name="code_postal"]');
  cpField?.addEventListener('input', () => {
    const digits = cpField.value.replace(/\D/g, '').slice(0, 5);
    if (cpField.value !== digits) cpField.value = digits;
  });

  /* --- Affichage du succès --- */
  function showSuccess() {
    if (successMessageEl) {
      successMessageEl.textContent = "Merci, votre demande est bien reçue. Nos équipes analysent votre situation et reviendront vers vous dans les meilleurs délais.";
    }
    current = TOTAL + 1;
    render();
    if (successHeading) {
      successHeading.textContent = "Demande envoyée";
      successHeading.focus({ preventScroll: true });
    }
    // Ne jamais laisser un souci d'affichage faire échouer la confirmation.
    try {
      if (formulaireEl && typeof formulaireEl.scrollIntoView === 'function') {
        formulaireEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    } catch (err) { /* ignoré */ }
  }

  /* --- Construction des deux payloads (testable via ubeproLead.preview()) --- */
  function buildPayloads() {
    const formData = Object.fromEntries(new FormData(form));
    const tracking = getTrackingValues();

    const categorie = normalizePayloadValue(formData.categorie);        // réponse formulaire
    // reponse_2 = 2e question affichée : quantité OU taille d'utilitaire OU véhicule libre.
    const precision =
      normalizePayloadValue(formData.precision_vu) ||
      normalizePayloadValue(formData.quantite) ||
      normalizePayloadValue(formData.precision_autre);
    const motorisation = normalizePayloadValue(formData.motorisation);

    const coordonnees = {
      nom: normalizePayloadValue(formData.nom),
      prenom: '',                                   // pas de champ dédié dans le HTML
      mail: normalizePayloadValue(formData.email).toLowerCase(),
      telephone: normalizePayloadValue(formData.tel),
      societe: normalizePayloadValue(formData.societe),
      code_postal: normalizePayloadValue(formData.code_postal),
      civilite: '',
      ville: ''
    };

    const questionnaires = {
      question_1: questionLabel(1), reponse_1: categorie,
      question_2: questionLabel(2), reponse_2: precision,
      question_3: questionLabel(3), reponse_3: motorisation
    };

    /* -- Payload Google Sheet : STRICTEMENT l'ancien format -- */
    const sheetData = {
      ...coordonnees,
      site: categorie,          // colonnes site / solution / enjeu du Sheet
      solution: precision,
      enjeu: motorisation,
      ...questionnaires,
      ...tracking              // spread en dernier : comportement inchangé
    };

    /* -- Payload CRM : contrat exact de get_information.php -- */
    const crmData = {
      ...coordonnees,
      source: tracking.source,
      categorie: tracking.categorie,   // valeur de tracking (categorie_fj + SMS PEC)
      user: tracking.user,             // id_societe_fj / branche SMS / branche TRA
      gclid: tracking.gclid,
      msclkid: tracking.msclkid,
      ...questionnaires
    };

    return { formData, tracking, sheetData, crmData, categorie, precision, motorisation };
  }

  /* --- Soumission + envois --- */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (isSubmitting) return;
    if (!validateStep(TOTAL)) return;

    status.textContent = '';
    status.classList.remove('is-error');
    isSubmitting = true;
    submitBtn.setAttribute('aria-busy', 'true');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Envoi en cours…';

    try {
      // Honeypot anti-spam : champ invisible rempli = robot → succès sans envoi.
      if (honeypot && honeypot.value.trim() !== '') {
        debugLog('Honeypot rempli, envoi ignoré.');
        showSuccess();
        return;
      }

      const { sheetData, crmData } = buildPayloads();
      const formId = normalizePayloadValue(DEFAULT_FORM_ID) || 'ADW_LP_VEHICULE_PRO';
      const leadId = generateId();

      /* --- Corps urlencoded pour Google Apps Script (CORS "simple") --- */
      const googleFormData = new URLSearchParams();
      Object.entries(sheetData).forEach(([key, value]) => googleFormData.set(key, value));
      googleFormData.set('form_id', formId);
      googleFormData.set('id_lead', leadId);
      googleFormData.set('page_url', safeText(trackingPageUrl, 1000));
      googleFormData.set('page_referrer', safeText(document.referrer, 1000));
      googleFormData.set('user_agent', safeText(navigator.userAgent, 300));
      googleFormData.set('langue', safeText(navigator.language || '', 20));

      debugLog('Google Sheet payload :', Object.fromEntries(googleFormData.entries()));
      debugLog('CRM payload :', { payload: { formId, id: leadId, data: crmData } });

      /* --- Envoi parallèle, avec SUCCÈS RAPIDE dès qu'une destination confirme. ---
         On n'attend plus TOUTES les réponses : dès que Google Sheet (vérifiable)
         ou le endpoint marque a répondu OK, on affiche le succès. Le CRM en
         sendBeacon et les autres envois continuent en arrière-plan.
         Un deadline de sécurité évite de bloquer l'utilisateur plus de 2,5s. */
      const results = [];
      let successShown = false;
      let crmBeaconQueued = false;

      const finalizeButton = () => {
        submitBtn.removeAttribute('aria-busy');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Recevoir mes devis gratuits';
        isSubmitting = false;
      };

      const recordResult = (r) => {
        results.push(r);
        window.ubeproLead.lastResults = [...results];
        debugLog('Résultat :', r);

        if (successShown) return;

        // CRM via sendBeacon = parti, on ne peut pas attendre plus.
        if (r.target === 'crm' && r.via === 'beacon') crmBeaconQueued = true;

        const sheetOk = results.some(x => x.target === 'sheet' && x.state === 'ok');
        const crmOk = results.some(x => x.target === 'crm' && x.state === 'ok');
        const brandOk = results.some(x => x.target === 'brand' && x.state === 'ok');

        // Succès visible dès qu'une destination vérifiée répond OU que le CRM beacon est parti.
        if (sheetOk || crmOk || brandOk || crmBeaconQueued) {
          successShown = true;
          showSuccess();
          finalizeButton();
          console.info('[ubepro] Succès affiché.');
        }
      };

      // Lancement parallèle, chaque réponse déclenche recordResult().
      sendToGoogleSheet(googleFormData).then(recordResult);
      sendToCrm(crmData, formId, leadId).then(recordResult);
      if (BRAND_CONFIG.endpoint) {
        const ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        const tid = ctrl ? setTimeout(() => ctrl.abort(), BRAND_TIMEOUT_MS) : null;
        fetch(BRAND_CONFIG.endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ payload: { formId, id: leadId, data: crmData } }),
          signal: ctrl ? ctrl.signal : undefined
        }).then(r => { if (tid) clearTimeout(tid); return { target: 'brand', state: r.ok ? 'ok' : 'error' }; })
          .catch(err => { if (tid) clearTimeout(tid); return { target: 'brand', state: 'error', error: err }; })
          .then(recordResult);
      }

      // Deadline de sécurité : si rien n'a confirmé au bout de FAST_SUCCESS_DEADLINE_MS,
      // on affiche le succès si au moins le CRM a été mis en file d'attente, sinon erreur.
      await new Promise(resolve => {
        const start = Date.now();
        const tick = () => {
          if (successShown) return resolve();
          const elapsed = Date.now() - start;
          const sheetOk = results.some(x => x.target === 'sheet' && x.state === 'ok');
          const crmOk = results.some(x => x.target === 'crm' && x.state === 'ok');
          const anyError = results.length >= (BRAND_CONFIG.endpoint ? 3 : 2)
                         && results.every(x => x.state === 'error');

          if (anyError) {
            status.textContent = 'Nous n’avons pas pu confirmer l’enregistrement de votre demande. Réessayez plus tard.';
            status.classList.add('is-error');
            return resolve();
          }
          if (elapsed >= FAST_SUCCESS_DEADLINE_MS && !successShown) {
            // On a attendu 2,5s : si CRM est parti (beacon), on montre le succès ; sinon on continue d'attendre les timeouts.
            if (crmBeaconQueued) {
              successShown = true;
              showSuccess();
              finalizeButton();
            }
            return resolve();
          }
          setTimeout(tick, 80);
        };
        tick();
      });

      // Attendre la fin de toutes les requêtes pour les logs (en arrière-plan, utilisateur déjà sur l'écran succès).
      debugLog('Résultats à l\'affichage du succès :', results);
      const checkFinalResults = () => {
        const finalSheetOk = results.some(r => r.target === 'sheet' && r.state === 'ok');
        const finalCrmOk = results.some(r => r.target === 'crm' && r.state === 'ok');
        const finalBrandOk = results.some(r => r.target === 'brand' && r.state === 'ok');
        if (!finalSheetOk && results.some(r => r.target === 'sheet' && r.state === 'error')) {
          console.warn('[ubepro] Google Sheet est en échec — vérifiez le script Apps Script.');
        }
        if (successShown && !finalCrmOk && !finalSheetOk && !finalBrandOk && crmBeaconQueued) {
          console.info('[ubepro] Lead transmis au CRM via sendBeacon (pas de confirmation lisible depuis le navigateur, c\'est normal en no-cors).');
        }
      };
      // Vérification finale une fois toutes les promesses résolues (sans re-lancer d'envois).
      const pending = [
        new Promise(res => { const i = setInterval(() => { if (results.length >= (BRAND_CONFIG.endpoint ? 3 : 2)) { clearInterval(i); res(); } }, 100); })
      ];
      Promise.allSettled(pending).then(checkFinalResults).catch(() => {});

      // Conversion GA4 / GTM si un conteneur est présent.
      try {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          event: 'generate_lead',
          form_id: formId,
          vehicle_category: sheetData.site,
          vehicle_precision: sheetData.solution,
          vehicle_energy: sheetData.enjeu
        });
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'generate_lead', { form_id: formId });
        }
      } catch (err) { /* le tracking ne doit jamais casser le succès */ }

    } catch (err) {
      console.error("Échec de l'envoi du lead :", err);
      status.textContent = 'Nous n’avons pas pu confirmer l’enregistrement de votre demande. Réessayez plus tard.';
      status.classList.add('is-error');
    } finally {
      if (!successShown) finalizeButton();
    }
  });

  // Pré-sélection depuis les cartes catégories
  document.querySelectorAll('[data-cat]').forEach(card => {
    card.addEventListener('click', () => {
      const r = form.querySelector(`input[name="categorie"][value="${card.dataset.cat}"]`);
      if (r) {
        clearAutoAdvance();
        r.checked = true;
        resetBranchAnswers();
        showError(r.closest('.qstep'), false);
        current = 2;
        render();
      }
    });
  });

  render();

  /* --- Outil de diagnostic en console --- */
  window.ubeproLead = {
    version: TRACKING_VERSION,
    config: { leadApiUrl: LEAD_API_URL, leadApiMode: LEAD_API_MODE, googleScriptUrl: GOOGLE_SCRIPT_URL, formId: DEFAULT_FORM_ID },
    /** Payloads qui seront postés (à copier dans curl / Postman). */
    preview: () => {
      const { sheetData, crmData } = buildPayloads();
      return {
        crm: { payload: { formId: DEFAULT_FORM_ID, id: '(généré à la soumission)', data: crmData } },
        sheet: sheetData
      };
    },
    lastResults: null,
    last: () => window.ubeproLead.lastResults,
    tracking: getTrackingValues
  };
})();

/* === 6. STICKY CTA MOBILE ==================================== */
(function stickyCta() {
  const bar = document.getElementById('stickyCta');
  const formEl = document.getElementById('formulaire');
  if (!bar || !formEl || !('IntersectionObserver' in window)) return;
  const mq = window.matchMedia('(max-width: 720px)');
  const io = new IntersectionObserver(([entry]) => {
    const show = mq.matches && !entry.isIntersecting && entry.boundingClientRect.top < 0;
    bar.classList.toggle('is-visible', show);
    bar.setAttribute('aria-hidden', String(!show));
    document.body.classList.toggle('has-sticky', show);
  }, { threshold: 0.05 });
  io.observe(formEl);
})();
